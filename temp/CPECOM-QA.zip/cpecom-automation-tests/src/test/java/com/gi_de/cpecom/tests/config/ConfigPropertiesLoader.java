package com.gi_de.cpecom.tests.config;

import com.gi_de.cpecom.tests.common.exceptions.ConfigPropertiesNotFoundException;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicReference;

public class ConfigPropertiesLoader {

    private static final AtomicReference<Properties> INSTANCE = new AtomicReference<>();

    private ConfigPropertiesLoader() {
    }

    public static Properties getInstance() throws ConfigPropertiesNotFoundException {
        if (INSTANCE.get() == null) {
            Properties newInstance = loadProperties();
            if (INSTANCE.compareAndSet(null, newInstance)) {
                return newInstance;
            }
        }
        return INSTANCE.get();
    }

    private static Properties loadProperties() throws ConfigPropertiesNotFoundException {
        try {
            Properties configuration = new Properties();
            InputStream inputStream = ConfigPropertiesLoader.class
                    .getClassLoader()
                    .getResourceAsStream(SystemEnvironments.getTargetEnvConfigurationFileName());
            configuration.load(inputStream);
            if (inputStream != null) {
                inputStream.close();
            }
            return configuration;
        } catch (IOException ex) {
            throw new ConfigPropertiesNotFoundException("Config Properties not found :" + ex.getMessage());
        }
    }
}
