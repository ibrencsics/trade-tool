package com.gi_de.cpecom.tests.stepdefs.visa.tokenization;

import com.gi_de.cpecom.tests.model.common.CpecomStatusCodeEnum;
import com.gi_de.cpecom.tests.model.common.DataGenerator;
import com.gi_de.cpecom.tests.model.tokenization.FundingAccountData;
import com.gi_de.cpecom.tests.model.tokenization.TokenRequest;
import com.gi_de.cpecom.tests.model.tokenization.TokenResponse;
import com.gi_de.cpecom.tests.model.tokenization.UserData;
import com.gi_de.cpecom.tests.stepdefs.base.StepDefinitionBase;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.vavr.Tuple2;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class TokenizationSteps extends StepDefinitionBase {

    private Tuple2<Integer, TokenResponse> tokenResponseTuple;

    private TokenRequest tokenRequest;

    @SneakyThrows
    @BeforeAll
    public static void setUpBeforeAllSteps() {
        log.info("Test Start");
    }

    @Given("a valid visa tokenRequest with values {string}, {string}, {string}, {string} and {string}")
    public void aTokenRequestWithValuesAndFor(String cardNumber, String expiryDateStr, String cvvStr, String fadPanSource, String consumerEntryModeStr) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr);

        tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .paymentScheme(PAYMENT_SCHEME_VISA)
                .userData(UserData.builder().accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID).build())
                .fundingAccountData(fundingAccountData)
                .riskData(null)
                .build();
    }

    @Given("a valid visa tokenRequest with values {string}, {string}, {string}, {string} and {string} and User Data email id")
    public void aVisaTokenRequestWithValuesAndWithUserDataEmail(String cardNumber, String expiryDateStr, String cvvStr, String fadPanSource, String consumerEntryModeStr, DataTable dataTable) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr);

        tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .paymentScheme(PAYMENT_SCHEME_VISA)
                .userData(UserData.builder()
                        .accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID)
                        .email(dataTable.asList().get(1))
                        .build())
                .fundingAccountData(fundingAccountData)
                .riskData(null)
                .build();
    }

    @SneakyThrows
    @When("a valid visa tokenization api request is sent to \"Tokenize\" API")
    public void aVisaTokenizationApiRequestIsSentToTokenizeAPI() {
        this.tokenResponseTuple = this.tokenize(tokenRequest, PAYMENT_SCHEME_VISA);
    }

    @Then("visa should respond with active token")
    public void shouldRespondWithActiveToken() {
        assertTokenResponseSuccess(this.tokenResponseTuple._1, this.tokenResponseTuple._2, PAYMENT_SCHEME_VISA);
    }

    public void cleanUpScenario() {
        log.info("Scenario clean up started.");
        if (this.tokenResponseTuple != null) {
            deleteAllCreatedTokens(this.tokenResponseTuple._2.getTokenReference(), PAYMENT_SCHEME_VISA);
        }
        log.info("Scenario clean up finished.");
    }

    @Then("Visa TokenRequest failed with Error message 'Validation error: userData.email: size must be between 0 and 255'")
    public void visaTokenRequestShouldFailedWithErrorResponseWithTspMessageYourRequestDoesNotHaveValidSetOfParametersRequired() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                CpecomStatusCodeEnum.BAD_REQUEST.name(),
                "Validation error: userData.email: size must be between 0 and 255"
        );
    }

    @AfterAll
    public static void setUpAfterAllSteps() {
        log.info("Test Finished");
    }

}
