/*
 * Copyright (c) Giesecke+Devrient Mobile Security GmbH 2020-2023
 */
package com.gi_de.cpecom.tests.common.customer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gi_de.cpecom.tests.model.tokenization.FundingAccountDataPlain;
import lombok.SneakyThrows;

public class CustomerChdBuilder {

    // Customer to test in cloud

    // VISA
    public static final String VISA_TEST_CUSTOMER_PAYMENT_APP_ID = "92bbc5fe-9b03-11ed-a8fc-0242ac120002";
    public static final String VISA_TEST_PSP_001_CUSTOMER_PAYMENT_APP_ID = "6fd8f64c-7ca2-11ee-a8c8-cb676469ea8f";
    public static final String VISA_TEST_PSP_002_CUSTOMER_PAYMENT_APP_ID = "5371dc00-7ca6-11ee-8d2f-2d85482d76a8";

    //MASTERCARD
    public static final String MASTERCARD_TEST_CUSTOMER_PAYMENT_APP_ID = "92bbc5fe-9b03-11ed-a8fc-0242ac120002";
    public static final String MASTERCARD_TEST_PSP_001_CUSTOMER_PAYMENT_APP_ID = "cab96b83-7c93-11ee-8696-0991c6c73323";
    public static final String MASTERCARD_TEST_PSP_002_CUSTOMER_PAYMENT_APP_ID = "f62b70e7-7c94-11ee-8696-0991c6c73323";

    // ELO
    public static final String ELO_TEST_CUSTOMER_PAYMENT_APP_ID = "465a9258-c4de-427d-ab1c-9a9c7b98dd51";
    public static final String ELO_TEST_PSP_001_CUSTOMER_PAYMENT_APP_ID = "";
    public static final String ELO_TEST_PSP_002_CUSTOMER_PAYMENT_APP_ID = "4739d280-f510-48c2-8375-c8190ab1f6d3";

    public final CustomerRequestEncryptor customerRequestEncryptor;
    private final ObjectMapper jsonMapper;

    public CustomerChdBuilder(final CustomerRequestEncryptor customerRequestEncryptor, final ObjectMapper jsonMapper) {
        this.customerRequestEncryptor = customerRequestEncryptor;
        this.jsonMapper = jsonMapper;
    }

    @SneakyThrows
    public String build(
        final String accountNumber,
        final ExpiryDate expiryDate,
        final String securityCode
    ) {
        final var chd = FundingAccountDataPlain.builder()
                .accountNumber(accountNumber)
                .expirationDate(expiryDate != null ? expiryDate.asIsoString() : null)
                .securityCode(securityCode)
                .build();

        return customerRequestEncryptor.encryptRsa(jsonMapper.writeValueAsString(chd));
    }

    @SneakyThrows
    public String build(
        final String accountNumber,
        final String expiryDate,
        final String securityCode
    ) {
        final var chd = FundingAccountDataPlain.builder()
                .accountNumber(accountNumber)
                .expirationDate(expiryDate)
                .securityCode(securityCode)
                .build();

        return customerRequestEncryptor.encryptRsa(jsonMapper.writeValueAsString(chd));
    }
}
