package com.gi_de.cpecom.tests.model.common;

import com.fasterxml.uuid.Generators;
import com.fasterxml.uuid.impl.TimeBasedGenerator;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class CpecomIdGenerator {

    private static final TimeBasedGenerator TIME_BASED_GENERATOR_INSTANCE = Generators.timeBasedGenerator();

    public static UUID generateUuid() {
        return TIME_BASED_GENERATOR_INSTANCE.generate();
    }

    public static UUID generateUuidForRequestId(final String clientRequestId) {
        return StringUtils.isEmpty(clientRequestId) ?
                generateUuid() : UUID.nameUUIDFromBytes(clientRequestId.getBytes(StandardCharsets.UTF_8));
    }

    public static String createRandomCustRequestId(final String prefix) {
        return prefix + "-" + RandomStringUtils.random(20, true, true);
    }

    public static String createRandomDataId() {
        return RandomStringUtils.random(20, true, true);
    }

    public static String generateUniqueId(){
        return UUID.randomUUID().toString();
    }

}
