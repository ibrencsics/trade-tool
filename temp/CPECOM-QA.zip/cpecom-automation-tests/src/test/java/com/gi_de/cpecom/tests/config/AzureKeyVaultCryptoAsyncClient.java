package com.gi_de.cpecom.tests.config;

import com.azure.identity.EnvironmentCredentialBuilder;
import com.azure.security.keyvault.keys.cryptography.CryptographyAsyncClient;
import com.azure.security.keyvault.keys.cryptography.CryptographyClientBuilder;

import java.util.concurrent.atomic.AtomicReference;

public class AzureKeyVaultCryptoAsyncClient {

    private static final String KEY_VAULT_URI = "https://kv-qa-cpecom-dev.vault.azure.net/";
    private static final String KEY_NAME = "CRYPTO-ROOT-WRAPPING-KEY-001";
    private static final String KEY_VERSION = "8906d5aadcd74b99b234ccafd681f14e";
    private static final String KEY_ID_PATTERN = "%s/keys/%s/%s";

    private static final AtomicReference<CryptographyAsyncClient> INSTANCE = new AtomicReference<>();

    private AzureKeyVaultCryptoAsyncClient() {
    }

    public static CryptographyAsyncClient getInstance() {
        if (INSTANCE.get() == null) {
            CryptographyAsyncClient newInstance = new CryptographyClientBuilder()
                    .credential(new EnvironmentCredentialBuilder().build())
                    .keyIdentifier(toKeyId(KEY_VAULT_URI, KEY_NAME, KEY_VERSION))
                    .buildAsyncClient();
            if (INSTANCE.compareAndSet(null, newInstance)) {
                return newInstance;
            }
        }
        return INSTANCE.get();
    }

    private static String toKeyId(final String kvUri, final String keyName, final String keyVersion) {
        return String.format(
                KEY_ID_PATTERN,
                kvUri.endsWith("/") ? kvUri.substring(0, kvUri.length() - 1) : kvUri,
                keyName,
                keyVersion
        );
    }

}
