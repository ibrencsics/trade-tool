package com.gi_de.cpecom.tests.common.exceptions;

public class ConfigPropertiesNotFoundException extends Exception {

    public ConfigPropertiesNotFoundException(String message) {
        super(message);
    }
}
