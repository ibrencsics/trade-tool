package com.gi_de.cpecom.tests.model.common;

public enum BulkStatusCode {
    OK,
    DUPLICATE_JOB_ID,
    JOB_NOT_FOUND_ERROR,
    UNHANDLED,
    BAD_REQUEST,
    SERVICE_ERROR,
    SERVICE_CONFIGURATION_ERROR,
    PAYMENT_APP_NOT_FOUND_ERROR,
    BULK_JOB_PROCESSING_ERROR,
    CRYPTOGRAPHY_ERROR,
    VTS_INVALID_PARAMETER,
    VTS_INVALID_REQUEST,
    VTS_CONFIGURATION_ERROR,
    VTS_AUTHENTICATION_ERROR,
    VTS_CARD_VERIFICATION_ERROR,
    VTS_CARD_NOT_ELIGIBLE,
    VTS_PROVISION_DATA_EXPIRED,
    VTS_CARD_NOT_ALLOWED,
    VTS_DECLINED,
    VTS_NOT_ALLOWED,
    MCSCOF_BAD_REQUEST_ERROR,
    MCSCOF_UNAUTHORIZED,
    MCSCOF_FORBIDDEN,
    MCSCOF_NOT_FOUND,
    MCSCOF_INTERNAL_SERVER_ERROR,
    MCSCOF_TEMPORARY_INTERNAL_SERVER_ERROR,
    MCSCOF_TEMPORARY_FORBIDDEN,
    MCSCOF_TEMPORARY_RATE_LIMIT_EXCEEDED,
    TSP_SERVICE_ERROR,
    TSP_TEMPORARY_SERVICE_ERROR,
    TSP_UNKNOWN_ERROR,
    /** @deprecated */
    @Deprecated
    AUTHORIZE_ERROR,
    /** @deprecated */
    @Deprecated
    CUSTOMER_NOT_FOUND_ERROR,
    /** @deprecated */
    @Deprecated
    MCSCOF_INVALID_ARGUMENT,
    /** @deprecated */
    @Deprecated
    MCSCOF_INVALID_STATE,
    /** @deprecated */
    @Deprecated
    MCSCOF_UNAUTHENTICATED,
    /** @deprecated */
    @Deprecated
    MCSCOF_PERMISSION_DENIED,
    /** @deprecated */
    @Deprecated
    MCSCOF_INTERNAL,
    /** @deprecated */
    @Deprecated
    MCSCOF_UNAVAILABLE,
    /** @deprecated */
    @Deprecated
    PAN_ALREADY_TOKENIZED,
    /** @deprecated */
    @Deprecated
    TSP_JOB_NOT_FOUND_ERROR;

    private BulkStatusCode() {
    }

    public boolean isSuccessEvent() {
        return OK == this;
    }
}
