package com.gi_de.cpecom.tests.common;

import com.gi_de.cpecom.tests.common.customer.ExpiryDate;

import java.time.OffsetDateTime;
import java.time.YearMonth;

public class CucumberTestUtils {

    public static String convertDateStringToExpiryDate(String expiryDate) {
        if (expiryDate == null) {
            return null;
        }
        return switch (expiryDate) {
            case "NOW+1Y" -> new ExpiryDate(YearMonth.now().plusYears(1)).asIsoString();
            case "NOW-1Y" -> new ExpiryDate(YearMonth.now().minusYears(1)).asIsoString();
            case "NOW+100Y" -> new ExpiryDate(YearMonth.now().plusYears(100)).asIsoString();
            case "NOW-3M" -> new ExpiryDate(YearMonth.now().minusMonths(3)).asIsoString();
            case "NULL", "null" -> null;
            default -> expiryDate;
        };
    }

   public static OffsetDateTime convertStringToOffsetDateTime(String date){
       if (date == null) {
           return null;
       }
       return switch (date) {
           case "NOW+1Y" -> OffsetDateTime.now().plusYears(1);
           case "NOW+2Y" -> OffsetDateTime.now().plusYears(2);
           case "NOW+1D" -> OffsetDateTime.now().plusDays(1);
           case "NOW+2D" -> OffsetDateTime.now().plusDays(2);
           default       -> OffsetDateTime.now();
       };
   }
}


