package com.gi_de.cpecom.tests.model.tokenization;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.jackson.Jacksonized;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TokenInfo {

    private String accountPanSuffix;

    private String accountPanExpiry;

    private String paymentAccountReference;

    private String tokenStatus;

    private String tokenPanSuffix;

    private String tokenPanExpiry;

}
