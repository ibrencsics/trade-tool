package com.gi_de.cpecom.tests.common.customer;

import java.time.YearMonth;

public class ExpiryDate {
    final String year;
    final String month;
    final String day;

    public ExpiryDate(YearMonth yearMonth) {
        this.year = String.valueOf(yearMonth.getYear());
        this.month = pad(String.valueOf(yearMonth.getMonthValue()));
        this.day = null;
    }

    public String asIsoString() {
        return this.day != null ? this.year + "-" + this.month + "-" + this.day : this.year + "-" + this.month;
    }

    public String toString() {
        return "ExpiryDate{" + this.year + ", " + this.month + ", " + this.day + "}";
    }

    private static String pad(String s) {
        return s.length() == 1 ? "0" + s : s;
    }

}
