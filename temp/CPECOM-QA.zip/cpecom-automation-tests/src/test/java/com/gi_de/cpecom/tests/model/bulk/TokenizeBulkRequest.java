package com.gi_de.cpecom.tests.model.bulk;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class TokenizeBulkRequest {

    private String gdPaymentAppId;

    private String paymentScheme;

    private String jobId;

    private List<FundingAccountBulk> fundingAccounts;
}


