package com.gi_de.cpecom.tests.model.bulk;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class TokenizeBulkResultsResponse {

    private String statusCode;

    private String errorMessage;

    private String jobStatus;

    private List<TokenizeBulkResult> results;
}
