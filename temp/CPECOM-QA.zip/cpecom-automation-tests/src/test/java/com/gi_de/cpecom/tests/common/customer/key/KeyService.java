/*
 * Copyright (c) Giesecke+Devrient Mobile Security GmbH 2020-2023
 */
package com.gi_de.cpecom.tests.common.customer.key;

import reactor.core.publisher.Mono;

public interface KeyService {
    Mono<String> exportKey(String label);

    void warmUp();
}
