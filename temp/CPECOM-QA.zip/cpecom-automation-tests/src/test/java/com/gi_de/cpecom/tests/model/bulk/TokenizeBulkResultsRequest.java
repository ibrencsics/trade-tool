package com.gi_de.cpecom.tests.model.bulk;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class TokenizeBulkResultsRequest {

    private String jobId;

}
