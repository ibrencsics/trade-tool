package com.gi_de.cpecom.tests.model.transact;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class TransactionData {

    private String transactionType;

    private String cryptogramType;

    private String amount;

    private String currencyCode;

    private String merchantId;

    private String sigDeviceDynamicData;
}
