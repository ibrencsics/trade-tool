package com.gi_de.cpecom.tests.stepdefs.base;

import com.gi_de.cpecom.tests.common.customer.CustomerChdBuilder;
import com.gi_de.cpecom.tests.common.exceptions.ConfigPropertiesNotFoundException;
import com.gi_de.cpecom.tests.common.exceptions.CusterIdNotFoundException;
import com.gi_de.cpecom.tests.common.exceptions.SslCertificateNotFoundException;
import com.gi_de.cpecom.tests.config.ConfigPropertiesLoader;
import com.gi_de.cpecom.tests.config.CpecomApi;
import com.gi_de.cpecom.tests.config.SystemEnvironments;
import com.gi_de.cpecom.tests.model.bulk.TokenizeBulkRequest;
import com.gi_de.cpecom.tests.model.bulk.TokenizeBulkResult;
import com.gi_de.cpecom.tests.model.bulk.TokenizeBulkResultsRequest;
import com.gi_de.cpecom.tests.model.bulk.TokenizeBulkResultsResponse;
import com.gi_de.cpecom.tests.model.common.*;
import com.gi_de.cpecom.tests.model.delete.DeleteRequest;
import com.gi_de.cpecom.tests.model.delete.DeleteResponse;
import com.gi_de.cpecom.tests.model.resume.ResumeRequest;
import com.gi_de.cpecom.tests.model.resume.ResumeResponse;
import com.gi_de.cpecom.tests.model.suspend.SuspendRequest;
import com.gi_de.cpecom.tests.model.suspend.SuspendResponse;
import com.gi_de.cpecom.tests.model.tokenInfo.TokenInfoRequest;
import com.gi_de.cpecom.tests.model.tokenInfo.TokenInfoResponse;
import com.gi_de.cpecom.tests.model.tokenization.TokenRequest;
import com.gi_de.cpecom.tests.model.tokenization.TokenResponse;
import com.gi_de.cpecom.tests.model.transact.TransactRequest;
import com.gi_de.cpecom.tests.model.transact.TransactResponse;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.vavr.Tuple;
import io.vavr.Tuple2;
import lombok.extern.log4j.Log4j2;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Assertions;
import org.junit.platform.commons.util.StringUtils;

import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static io.restassured.RestAssured.given;

@Log4j2
public class StepDefinitionBase {
    private final static String GD_REQUEST_ID = "gd-request-id";
    private final static String GD_CONTEXT_ID = "gd-context-id";
    protected final static String PAYMENT_SCHEME_VISA = "VISA";
    protected final static String PAYMENT_SCHEME_MASTERCARD = "MASTERCARD";
    protected final static String PAYMENT_SCHEME_ELO = "ELO";

    protected static RequestSpecification getRequestSpecification(final String prefix, final String[] optionals) {
        final String gdRequestId = (optionals != null && optionals.length > 0) ? optionals[0] : CpecomIdGenerator.createRandomCustRequestId(prefix);
        final String gdContextId = CpecomIdGenerator.generateUuid().toString();
        log.info("GD Request Id : {}", gdRequestId);
        log.info("GD Context Id : {}", gdContextId);
        //log.info("-----------------------------------------------------------------------------------------------------------------------");
        return given()
                .header(GD_REQUEST_ID, gdRequestId)
                .header(GD_CONTEXT_ID, gdContextId);
    }

    protected String getGdPaymentAppId(final String paymentScheme) {
        try {
            final String customerId = SystemEnvironments.getCustomerIdSystemEnv();
            return switch (paymentScheme + "-" + customerId) {
                case "VISA-test" -> CustomerChdBuilder.VISA_TEST_CUSTOMER_PAYMENT_APP_ID;
                case "VISA-test-psp-001" -> CustomerChdBuilder.VISA_TEST_PSP_001_CUSTOMER_PAYMENT_APP_ID;
                case "VISA-test-psp-002" -> CustomerChdBuilder.VISA_TEST_PSP_002_CUSTOMER_PAYMENT_APP_ID;
                case "MASTERCARD-test" -> CustomerChdBuilder.MASTERCARD_TEST_CUSTOMER_PAYMENT_APP_ID;
                case "MASTERCARD-test-psp-001" -> CustomerChdBuilder.MASTERCARD_TEST_PSP_001_CUSTOMER_PAYMENT_APP_ID;
                case "MASTERCARD-test-psp-002" -> CustomerChdBuilder.MASTERCARD_TEST_PSP_002_CUSTOMER_PAYMENT_APP_ID;
                case "ELO-test" -> CustomerChdBuilder.ELO_TEST_CUSTOMER_PAYMENT_APP_ID;
                case "ELO-test-psp-001" -> CustomerChdBuilder.ELO_TEST_PSP_001_CUSTOMER_PAYMENT_APP_ID;
                case "ELO-test-psp-002" -> CustomerChdBuilder.ELO_TEST_PSP_002_CUSTOMER_PAYMENT_APP_ID;
                default -> null;
            };
        } catch (CusterIdNotFoundException ex) {
            log.info("CusterIdNotFoundException: {}", ex.getMessage());
        }
        return null;
    }

    // Tokenize API httpRequest call
    protected Tuple2<Integer, TokenResponse> tokenize(final TokenRequest tokenRequest, final String paymentScheme, final String... optionals) {
        log.info("======================================================= Tokenize ==========================================================================");
        log.info("Tokenize API Request : {}", tokenRequest.toString());
        var response = httpApiCall(tokenRequest, CpecomApi.PATH_TOKENIZE, paymentScheme + "-TOKEN", TokenResponse.class, optionals);
        log.info("Tokenize API Response: status: {} Response: {}", response._1, response._2.toString());
        log.info("======================================================= Tokenize ==========================================================================");
        return response;
    }

    // DELETE API HttpRequest call
    protected Tuple2<Integer, DeleteResponse> delete(final DeleteRequest deleteRequest, final String paymentScheme) {
        log.info("======================================================= Delete ==========================================================================");
        log.info("Delete API Request : {}", deleteRequest.toString());
        var response = httpApiCall(deleteRequest, CpecomApi.PATH_DELETE, paymentScheme + "-DELETE", DeleteResponse.class);
        log.info("Delete API Response: status: {} Response: {}", response._1, response._2.toString());
        log.info("======================================================= Delete ==========================================================================");
        return response;
    }

    // SUSPEND API HttpRequest call
    protected Tuple2<Integer, SuspendResponse> suspend(final SuspendRequest suspendRequest, final String paymentScheme) {
        log.info("======================================================= Suspend ==========================================================================");
        log.info("Suspend API Request : {}", suspendRequest.toString());
        var response = httpApiCall(suspendRequest, CpecomApi.PATH_SUSPEND, paymentScheme + "-SUSPEND", SuspendResponse.class);
        log.info("Suspend API Response: status: {} Response: {}", response._1, response._2.toString());
        log.info("======================================================= Suspend ==========================================================================");
        return response;
    }

    // RESUME API HttpRequest call
    protected Tuple2<Integer, ResumeResponse> resume(final ResumeRequest resumeRequest, final String paymentScheme) {
        log.info("======================================================= Resume ==========================================================================");
        log.info("Resume API Request : {}", resumeRequest.toString());
        var response = httpApiCall(resumeRequest, CpecomApi.PATH_RESUME, paymentScheme + "-RESUME", ResumeResponse.class);
        log.info("Resume API Response: status: {} Response: {}", response._1, response._2.toString());
        log.info("======================================================= Resume ==========================================================================");
        return response;
    }

    // TRANSACT API HttpRequest call
    protected Tuple2<Integer, TransactResponse> transact(final TransactRequest transactRequest, final String paymentScheme) {
        log.info("======================================================= Transact ==========================================================================");
        log.info("Transact API Request : {}", transactRequest.toString());
        var response = httpApiCall(transactRequest, CpecomApi.PATH_TRANSACT, paymentScheme + "-TRANSACT", TransactResponse.class);
        log.info("Transact API Response: status: {} Response: {}", response._1, response._2.toString());
        log.info("======================================================= Transact ==========================================================================");
        return response;
    }

    // TOKEN-INFO API HttpRequest call
    protected Tuple2<Integer, TokenInfoResponse> tokenInfo(final TokenInfoRequest tokenInfoRequest, final String paymentScheme) {
        log.info("======================================================= TokenInfo ==========================================================================");
        log.info("TokenInfo API Request : {}", tokenInfoRequest.toString());
        var response = httpApiCall(tokenInfoRequest, CpecomApi.PATH_TOKEN_INFO, paymentScheme + "-TOKEN-INFO", TokenInfoResponse.class);
        log.info("TokenInfo API Response: status: {} Response: {}", response._1, response._2.toString());
        log.info("======================================================= TokenInfo ==========================================================================");
        return response;
    }

    // TOKENIZE-BULK API HttpRequest call
    protected Tuple2<Integer, TokenizeBulkResultsResponse> tokenizeBulk(final TokenizeBulkRequest tokenizeBulkRequest, final String paymentScheme) {
        log.info("======================================================= TokenizeBulk ==========================================================================");
        Tuple2<Integer, TokenizeBulkResultsResponse> response = null;
        if(tokenizeBulkRequest != null){
            log.info("Bulk Request JobId : {}", tokenizeBulkRequest.getJobId());
            if (tokenizeBulkRequest.getFundingAccounts() != null && tokenizeBulkRequest.getFundingAccounts().size() < 10) {
                log.info("TokenizeBulk API Request : {}", tokenizeBulkRequest.toString());
            }
            response = httpApiCall(tokenizeBulkRequest, CpecomApi.PATH_BULK_TOKENIZE, paymentScheme + "-TOKENIZE-BULK", TokenizeBulkResultsResponse.class);
            log.info("TokenizeBulk API Response: status: {} Response: {}", response._1, response._2.toString());
        }
        log.info("======================================================= TokenizeBulk ==========================================================================");
        return response;
    }

    // TOKENIZE-BULK-RESULTS API HttpRequest call
    protected Tuple2<Integer, TokenizeBulkResultsResponse> tokenizeBulkResults(final TokenizeBulkResultsRequest tokenizeBulkResultsRequest, final String paymentScheme) {
        log.info("TokenizeBulkResult API Request : {}", tokenizeBulkResultsRequest.toString());
        return httpApiCall(tokenizeBulkResultsRequest, CpecomApi.PATH_BULK_TOKENIZE_RESULTS, paymentScheme + "-TOKENIZE-BULK-RESULTS", TokenizeBulkResultsResponse.class);
    }

    protected Tuple2<Integer, TokenizeBulkResultsResponse> pollTokenizeBulkResults(final TokenizeBulkResultsRequest tokenizeBulkResultsRequest, final String paymentScheme) {
        log.info("====================================== Polling Tokenize bulk Results Started ======================================");
        AtomicReference<Tuple2<Integer, TokenizeBulkResultsResponse>> tokenizeBulkResultsResponse = new AtomicReference<>();
        Awaitility
                .await()
                .atMost(10, TimeUnit.MINUTES)
                .pollInterval(10, TimeUnit.SECONDS)
                .until(() ->
                {
                    log.info("Sending Polling Request to get bulk result...");
                    final Tuple2<Integer, TokenizeBulkResultsResponse> response = tokenizeBulkResults(tokenizeBulkResultsRequest, paymentScheme);
                    log.info("Polling response: {}", response._2);
                    final boolean isAvailable = (response._1 == 200)
                            && ("OK".equals(response._2.getStatusCode()))
                            && (JobStatusEnum.DONE.name().equals(response._2.getJobStatus()));
                    log.info("Check if result available: {}", isAvailable);
                    if (isAvailable) {
                        log.info("Result is now available so EXIT");
                        tokenizeBulkResultsResponse.set(response);
                    }
                    return isAvailable;
                });
        log.info("====================================== Polling Tokenize bulk Results Finished ======================================");
        return tokenizeBulkResultsResponse.get();
    }

    private static <T, R> Tuple2<Integer, R> httpApiCall(
            final T requestModel,
            final String apiPath,
            final String prefix,
            final Class<R> responseModel, final String... optionalParams) {
        //log.info("---------------------------------------------------- {} ----------------------------------------------------", requestModel.getClass().getSimpleName());
        //log.info("HTTP API Request : {}", requestModel.toString());
        final Response response = getRequestSpecification(prefix, optionalParams)
                .body(requestModel)
                .when()
                .post(apiPath)
                .then()
                .extract().response();
        R res = response.as(responseModel);
        //log.info("Response : {} and {}", response.getStatusCode(), res);
        //log.info("-----------------------------------------------------------------------------------------------------------------------");
        return Tuple.of(response.getStatusCode(), res);
    }

    protected void deleteAllCreatedTokens(String tokenReference, String paymentScheme) {
        if (StringUtils.isNotBlank(tokenReference)) {
            log.info("Cleaning up already created tokens with tokenReference {}", tokenReference);
            // Given following delete request
            DeleteRequest deleteRequest = DeleteRequest.builder()
                    .tokenReference(tokenReference)
                    .gdPaymentAppId(getGdPaymentAppId(paymentScheme))
                    .reasonCode("CUSTOMER_CONFIRMED")
                    .reasonDescription("Some description text")
                    .build();
            // Call to delete api
            final var deleteResToken = delete(deleteRequest, paymentScheme);
            log.info("Delete Response : {} and {}", deleteResToken._1, deleteResToken._2);
            //log.info("-----------------------------------------------------------------------------------------------------------------------");
            assertDeleteResponseSuccess(deleteResToken._1, deleteResToken._2);
        } else {
            log.info("No tokenReference exist for deletion {}", tokenReference);
        }
    }

    protected void assertTokenResponseSuccess(final Integer statusCode, final TokenResponse tokenResponse, String paymentScheme) {
        Assertions.assertNotNull(tokenResponse);
        Assertions.assertEquals(200, statusCode);
        if (!("OK".equals(tokenResponse.getStatusCode()))) {
            log.error("Error Message : {}", tokenResponse.getErrorMessage());
        }
        Assertions.assertEquals("OK", tokenResponse.getStatusCode());
        Assertions.assertNull(tokenResponse.getErrorMessage());

        Assertions.assertNotNull(tokenResponse.getTokenReference());
        Assertions.assertFalse(tokenResponse.getTokenReference().isEmpty());

        Assertions.assertNotNull(tokenResponse.getTspTokenReference());
        Assertions.assertFalse(tokenResponse.getTspTokenReference().isEmpty());

        // TokenInfo asserts
        Assertions.assertNotNull(tokenResponse.getTokenInfo());
        Assertions.assertNotNull(tokenResponse.getTokenInfo().getAccountPanSuffix());
        Assertions.assertFalse(tokenResponse.getTokenInfo().getAccountPanSuffix().isEmpty());
        Assertions.assertNotNull(tokenResponse.getTokenInfo().getAccountPanExpiry());
        Assertions.assertFalse(tokenResponse.getTokenInfo().getAccountPanExpiry().isEmpty());
        Assertions.assertNotNull(tokenResponse.getTokenInfo().getPaymentAccountReference());
        Assertions.assertFalse(tokenResponse.getTokenInfo().getPaymentAccountReference().isEmpty());
        Assertions.assertNotNull(tokenResponse.getTokenInfo().getTokenStatus());
        Assertions.assertFalse(tokenResponse.getTokenInfo().getTokenStatus().isEmpty());
        Assertions.assertNotNull(tokenResponse.getTokenInfo().getTokenPanSuffix());
        Assertions.assertFalse(tokenResponse.getTokenInfo().getTokenPanSuffix().isEmpty());
        Assertions.assertNotNull(tokenResponse.getTokenInfo().getTokenPanExpiry());
        Assertions.assertFalse(tokenResponse.getTokenInfo().getTokenPanExpiry().isEmpty());

        Assertions.assertNotNull(tokenResponse.getCardMetadataId());
        Assertions.assertFalse(tokenResponse.getCardMetadataId().isEmpty());
    }

    protected void assertTokenInfoResponseSuccess(final Integer statusCode, final TokenInfoResponse tokenInfoResponse, String paymentScheme) {
        Assertions.assertNotNull(tokenInfoResponse);
        Assertions.assertEquals(200, statusCode);

        Assertions.assertEquals("OK", tokenInfoResponse.getStatusCode());

        Assertions.assertNotNull(tokenInfoResponse.getTokenReference());
        Assertions.assertFalse(tokenInfoResponse.getTokenReference().isEmpty());

        Assertions.assertNotNull(tokenInfoResponse.getTspTokenReference());
        Assertions.assertFalse(tokenInfoResponse.getTspTokenReference().isEmpty());

        // TokenInfo asserts
        Assertions.assertNotNull(tokenInfoResponse.getTokenInfo());
        Assertions.assertNotNull(tokenInfoResponse.getTokenInfo().getAccountPanSuffix());
        Assertions.assertFalse(tokenInfoResponse.getTokenInfo().getAccountPanSuffix().isEmpty());
        Assertions.assertNotNull(tokenInfoResponse.getTokenInfo().getAccountPanExpiry());
        Assertions.assertFalse(tokenInfoResponse.getTokenInfo().getAccountPanExpiry().isEmpty());
        Assertions.assertNotNull(tokenInfoResponse.getTokenInfo().getPaymentAccountReference());
        Assertions.assertFalse(tokenInfoResponse.getTokenInfo().getPaymentAccountReference().isEmpty());
        Assertions.assertNotNull(tokenInfoResponse.getTokenInfo().getTokenStatus());
        Assertions.assertFalse(tokenInfoResponse.getTokenInfo().getTokenStatus().isEmpty());
        Assertions.assertNotNull(tokenInfoResponse.getTokenInfo().getTokenPanSuffix());
        Assertions.assertFalse(tokenInfoResponse.getTokenInfo().getTokenPanSuffix().isEmpty());
        Assertions.assertNotNull(tokenInfoResponse.getTokenInfo().getTokenPanExpiry());
        Assertions.assertFalse(tokenInfoResponse.getTokenInfo().getTokenPanExpiry().isEmpty());

        Assertions.assertNotNull(tokenInfoResponse.getCardMetadataId());
        Assertions.assertFalse(tokenInfoResponse.getCardMetadataId().isEmpty());
    }

    protected void assertDeleteResponseSuccess(final Integer statusCode, final DeleteResponse deleteResponse) {
        Assertions.assertNotNull(deleteResponse);
        Assertions.assertEquals(200, statusCode);
        Assertions.assertEquals("OK", deleteResponse.getStatusCode());
    }

    protected void assertTokenRequestError(
            final Integer actualStatusCode,
            final TokenResponse actualTokenResponse,
            final Integer expectedStatusCode,
            final String expectedErrorResponseStatusCode,
            final String... expectedErrorMessages) {
        Assertions.assertNotNull(actualTokenResponse);
        Assertions.assertEquals(expectedStatusCode, actualStatusCode);

        Assertions.assertEquals(expectedErrorResponseStatusCode, actualTokenResponse.getStatusCode());
        if (actualTokenResponse.getErrorMessage() != null) {
            Assertions.assertTrue(arrayContains(expectedErrorMessages, actualTokenResponse.getErrorMessage()));
        }
        Assertions.assertNull(actualTokenResponse.getTokenReference());
        Assertions.assertNull(actualTokenResponse.getTspTokenReference());
        Assertions.assertNull(actualTokenResponse.getTokenInfo());
        Assertions.assertNull(actualTokenResponse.getCardMetadataId());
    }

    public static boolean arrayContains(String[] array, String value) {
        return Arrays.stream(array).anyMatch(value::contains);
    }

    protected void assertDeleteRequestError(
            final Integer actualStatusCode,
            final DeleteResponse actualDeleteResponse,
            final String statusCode,
            final String expectedErrorMessages) {
        Assertions.assertNotNull(actualDeleteResponse);
        log.info("Delete Error Response : {} and {}", actualStatusCode, actualDeleteResponse.toString());
        Assertions.assertEquals(200, actualStatusCode);

        Assertions.assertEquals(statusCode, actualDeleteResponse.getStatusCode());
        Assertions.assertEquals(expectedErrorMessages, actualDeleteResponse.getErrorMessage());
    }

    protected void assertSuspendResponseSuccess(final Integer statusCode, final SuspendResponse suspendResponse) {
        Assertions.assertNotNull(suspendResponse);
        log.info("Suspend Response : {} and {}", statusCode, suspendResponse.toString());
        Assertions.assertEquals(200, statusCode);
        Assertions.assertEquals("OK", suspendResponse.getStatusCode());
    }

    protected void assertResumeResponseSuccess(final Integer statusCode, final ResumeResponse resumeResponse) {
        Assertions.assertNotNull(resumeResponse);
        log.info("Resume Response : {} and {}", statusCode, resumeResponse.toString());
        Assertions.assertEquals(200, statusCode);
        Assertions.assertEquals("OK", resumeResponse.getStatusCode());
    }

    protected void assertResumeResponseError(final Integer statusCode,
                                             final ResumeResponse resumeResponse,
                                             final String expectedStatusCode,
                                             final String expectedErrorMessages) {
        Assertions.assertNotNull(resumeResponse);
        log.info("Resume Response : {} and {}", statusCode, resumeResponse.toString());
        Assertions.assertEquals(200, statusCode);
        Assertions.assertEquals(expectedStatusCode, resumeResponse.getStatusCode());
        Assertions.assertEquals(expectedErrorMessages, resumeResponse.getErrorMessage());
    }

    protected void assertTokenTransactSuccess(final Integer statusCode, final TransactResponse transactResponse, String paymentScheme) {
        Assertions.assertNotNull(transactResponse);
        log.info("Transact Response : {} and {}", statusCode, transactResponse.toString());
        Assertions.assertEquals(200, statusCode);
        Assertions.assertEquals("OK", transactResponse.getStatusCode());
        Assertions.assertNull(transactResponse.getErrorMessage());
        Assertions.assertNotNull(transactResponse.getTspTransactionId());
        Assertions.assertFalse(transactResponse.getTspTransactionId().isEmpty());

        // TokenInfo asserts
        Assertions.assertNotNull(transactResponse.getTokenInfo());
        Assertions.assertNotNull(transactResponse.getTokenInfo().getAccountPanSuffix());
        Assertions.assertFalse(transactResponse.getTokenInfo().getAccountPanSuffix().isEmpty());
        if (PAYMENT_SCHEME_MASTERCARD.equals(paymentScheme)) {
            Assertions.assertNotNull(transactResponse.getTokenInfo().getAccountPanExpiry());
            Assertions.assertFalse(transactResponse.getTokenInfo().getAccountPanExpiry().isEmpty());
            Assertions.assertNull(transactResponse.getTokenInfo().getPaymentAccountReference());
            Assertions.assertNotNull(transactResponse.getTokenInfo().getTokenPanSuffix());
            Assertions.assertFalse(transactResponse.getTokenInfo().getTokenPanSuffix().isEmpty());
            Assertions.assertNull(transactResponse.getTokenInfo().getTokenPanExpiry());
        } else if (PAYMENT_SCHEME_VISA.equals(paymentScheme)) {
            Assertions.assertNull(transactResponse.getTokenInfo().getAccountPanExpiry());
            Assertions.assertNotNull(transactResponse.getTokenInfo().getPaymentAccountReference());
            Assertions.assertFalse(transactResponse.getTokenInfo().getPaymentAccountReference().isEmpty());
            Assertions.assertNull(transactResponse.getTokenInfo().getTokenPanSuffix());
            Assertions.assertNotNull(transactResponse.getTokenInfo().getTokenPanExpiry());
            Assertions.assertFalse(transactResponse.getTokenInfo().getTokenPanExpiry().isEmpty());
        }
        Assertions.assertNotNull(transactResponse.getTokenInfo().getTokenStatus());
        Assertions.assertFalse(transactResponse.getTokenInfo().getTokenStatus().isEmpty());


        Assertions.assertNotNull(transactResponse.getEncTransactionPayload());
        Assertions.assertFalse(transactResponse.getEncTransactionPayload().isEmpty());
    }

    protected void assertTokenTransactError(
            final Integer statusCode,
            final TransactResponse transactResponse,
            final String expectedStatusCode,
            final String expectedErrorMessages) {
        Assertions.assertNotNull(transactResponse);
        log.info("Transact Error Response : {} and {}", statusCode, transactResponse.toString());
        Assertions.assertEquals(200, statusCode);

        Assertions.assertEquals(expectedStatusCode, transactResponse.getStatusCode());
        Assertions.assertEquals(expectedErrorMessages, transactResponse.getErrorMessage());
        Assertions.assertNull(transactResponse.getTspTransactionId());
        Assertions.assertNull(transactResponse.getTokenInfo());
        Assertions.assertNull(transactResponse.getEncTransactionPayload());
    }

    protected void assertTokenInfoError(
            final Integer actualStatusCode,
            final TokenInfoResponse actualTokenInfoResponse,
            final Integer expectedStatusCode,
            final String statusCode,
            final String expectedErrorMessages) {
        Assertions.assertNotNull(actualTokenInfoResponse);
        log.info("Token Info Response : {} and {}", actualStatusCode, actualTokenInfoResponse.toString());
        Assertions.assertEquals(expectedStatusCode, actualStatusCode);

        Assertions.assertEquals(statusCode, actualTokenInfoResponse.getStatusCode());
        Assertions.assertEquals(expectedErrorMessages, actualTokenInfoResponse.getErrorMessage());
        Assertions.assertNull(actualTokenInfoResponse.getTokenReference());
        Assertions.assertNull(actualTokenInfoResponse.getTspTokenReference());
        Assertions.assertNull(actualTokenInfoResponse.getTokenInfo());
        Assertions.assertNull(actualTokenInfoResponse.getCardMetadataId());
    }

    protected void assertTokenizeBulkResponseSuccess(
            final Integer actualStatusCode,
            final TokenizeBulkResultsResponse tokenizeBulkResultsResponse) {
        Assertions.assertNotNull(tokenizeBulkResultsResponse);
        Assertions.assertEquals(200, actualStatusCode);
        Assertions.assertNull(tokenizeBulkResultsResponse.getErrorMessage());
        Assertions.assertEquals(JobStatusEnum.INPROGRESS.name(), tokenizeBulkResultsResponse.getJobStatus());
    }

    protected void assertTokenizeBulkResultsResponseSuccess(
            final Integer actualStatusCode,
            final TokenizeBulkResultsResponse tokenizeBulkResultsResponse) {
        Assertions.assertNotNull(tokenizeBulkResultsResponse);
        log.info("Tokenize Bulk Results Response : {} and {}", actualStatusCode, tokenizeBulkResultsResponse.toString());
        Assertions.assertEquals(200, actualStatusCode);
        Assertions.assertNull(tokenizeBulkResultsResponse.getErrorMessage());
        Assertions.assertEquals(JobStatusEnum.DONE.name(), tokenizeBulkResultsResponse.getJobStatus());
        Assertions.assertNotNull(tokenizeBulkResultsResponse.getResults());
        Assertions.assertTrue(tokenizeBulkResultsResponse.getResults().size() > 0);

        tokenizeBulkResultsResponse.getResults().forEach(tokenizeBulkResult -> {
            Assertions.assertEquals(BulkStatusCode.OK.name(), tokenizeBulkResult.getStatusCode());
            Assertions.assertNull(tokenizeBulkResult.getErrorMessage());
            Assertions.assertNotNull(tokenizeBulkResult.getRowId());
            Assertions.assertNotNull(tokenizeBulkResult.getTokenReference());
            Assertions.assertNotNull(tokenizeBulkResult.getTspTokenReference());
        });
    }

    protected void assertTokenizeBulkResultsResponseSuccessAndError(
            final Integer actualStatusCode,
            final TokenizeBulkResultsResponse tokenizeBulkResultsResponse,
            String validationErrorMessage) {
        Assertions.assertNotNull(tokenizeBulkResultsResponse);
        log.info("Tokenize Bulk Results Response : {} and {}", actualStatusCode, tokenizeBulkResultsResponse.toString());
        Assertions.assertEquals(200, actualStatusCode);
        Assertions.assertNull(tokenizeBulkResultsResponse.getErrorMessage());
        Assertions.assertEquals(JobStatusEnum.DONE.name(), tokenizeBulkResultsResponse.getJobStatus());
        Assertions.assertNotNull(tokenizeBulkResultsResponse.getResults());
        Assertions.assertTrue(tokenizeBulkResultsResponse.getResults().size() > 0);

        tokenizeBulkResultsResponse.getResults().forEach(tokenizeBulkResult -> {
            Assertions.assertNotNull(tokenizeBulkResult.getRowId());
            if ("row-1".equals(tokenizeBulkResult.getRowId())) {
                Assertions.assertEquals(BulkStatusCode.OK.name(), tokenizeBulkResult.getStatusCode());
                Assertions.assertNull(tokenizeBulkResult.getErrorMessage());
                Assertions.assertNotNull(tokenizeBulkResult.getTokenReference());
                Assertions.assertNotNull(tokenizeBulkResult.getTspTokenReference());
            } else {
                Assertions.assertEquals(BulkStatusCode.BAD_REQUEST.name(), tokenizeBulkResult.getStatusCode());
                Assertions.assertNotNull(tokenizeBulkResult.getErrorMessage());
                Assertions.assertTrue(tokenizeBulkResult.getErrorMessage().contains(validationErrorMessage));
                Assertions.assertNull(tokenizeBulkResult.getTokenReference());
                Assertions.assertNull(tokenizeBulkResult.getTspTokenReference());
            }
        });
    }

    protected void assertTokenizeBulkResultsAtLeastOneSuccessResponse(
            final Integer actualStatusCode,
            final TokenizeBulkResultsResponse tokenizeBulkResultsResponse,
            final String validationErrorMessage) {
        Assertions.assertNotNull(tokenizeBulkResultsResponse);
        log.info("Tokenize Bulk Results Response : {} and {}", actualStatusCode, tokenizeBulkResultsResponse.toString());
        Assertions.assertEquals(200, actualStatusCode);
        Assertions.assertNull(tokenizeBulkResultsResponse.getErrorMessage());
        Assertions.assertEquals(JobStatusEnum.DONE.name(), tokenizeBulkResultsResponse.getJobStatus());
        Assertions.assertNotNull(tokenizeBulkResultsResponse.getResults());
        Assertions.assertTrue(tokenizeBulkResultsResponse.getResults().size() > 0);

        tokenizeBulkResultsResponse.getResults().forEach(tokenizeBulkResult -> {
            Assertions.assertNotNull(tokenizeBulkResult.getRowId());
            if (BulkStatusCode.OK.name().equals(tokenizeBulkResult.getStatusCode())) {
                Assertions.assertEquals(BulkStatusCode.OK.name(), tokenizeBulkResult.getStatusCode());
                Assertions.assertNull(tokenizeBulkResult.getErrorMessage());
                Assertions.assertNotNull(tokenizeBulkResult.getTokenReference());
                Assertions.assertNotNull(tokenizeBulkResult.getTspTokenReference());
            } else {
                Assertions.assertDoesNotThrow(() -> {
                    Assertions.assertEquals(TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_TEMPORARY_INTERNAL_SERVER_ERROR_TSP_TEMPORARY_SERVICE_ERROR), tokenizeBulkResult.getStatusCode());
                    Assertions.assertNotNull(tokenizeBulkResult.getErrorMessage());
                    Assertions.assertTrue(tokenizeBulkResult.getErrorMessage().contains(validationErrorMessage));
                    Assertions.assertNull(tokenizeBulkResult.getTokenReference());
                    Assertions.assertNull(tokenizeBulkResult.getTspTokenReference());
                });
            }
        });
    }

    protected void assertTokenizeBulkResultsResponseError(
            final Integer actualStatusCode,
            final TokenizeBulkResultsResponse tokenizeBulkResultsResponse,
            String bulkStatusCode,
            String validationErrorMessage) {
        Assertions.assertNotNull(tokenizeBulkResultsResponse);
        log.info("Tokenize Bulk Results Response : {} and {}", actualStatusCode, tokenizeBulkResultsResponse.toString());
        Assertions.assertEquals(200, actualStatusCode);
        Assertions.assertNull(tokenizeBulkResultsResponse.getErrorMessage());
        Assertions.assertEquals(JobStatusEnum.DONE.name(), tokenizeBulkResultsResponse.getJobStatus());
        Assertions.assertNotNull(tokenizeBulkResultsResponse.getResults());
        Assertions.assertFalse(tokenizeBulkResultsResponse.getResults().isEmpty());

        tokenizeBulkResultsResponse.getResults().forEach(tokenizeBulkResult -> {
            Assertions.assertEquals(bulkStatusCode, tokenizeBulkResult.getStatusCode());
            Assertions.assertNotNull(tokenizeBulkResult.getErrorMessage());
            Assertions.assertTrue(tokenizeBulkResult.getErrorMessage().contains(validationErrorMessage));
            Assertions.assertNotNull(tokenizeBulkResult.getRowId());
            Assertions.assertNull(tokenizeBulkResult.getTokenReference());
            Assertions.assertNull(tokenizeBulkResult.getTspTokenReference());
        });
    }

    protected void assertTokenizeBulkResponseError(
            final Integer actualStatusCode,
            final TokenizeBulkResultsResponse tokenizeBulkResultsResponse,
            final String... validateMessage) {
        Assertions.assertNotNull(tokenizeBulkResultsResponse);
        log.info("Tokenize Bulk Response : {} and {}", actualStatusCode, tokenizeBulkResultsResponse.toString());
        Assertions.assertEquals(200, actualStatusCode);
        Assertions.assertEquals(validateMessage[0], tokenizeBulkResultsResponse.getJobStatus());
        Assertions.assertNull(tokenizeBulkResultsResponse.getErrorMessage());
        Assertions.assertNotNull(tokenizeBulkResultsResponse.getResults());
        Assertions.assertFalse(tokenizeBulkResultsResponse.getResults().isEmpty());

        for (TokenizeBulkResult tokenizeBulkResult : tokenizeBulkResultsResponse.getResults()) {
            log.info("Actual Error Message from Results: {}", tokenizeBulkResult.getErrorMessage());
            Assertions.assertEquals(validateMessage[1], tokenizeBulkResult.getStatusCode());
            Assertions.assertNotNull(tokenizeBulkResult.getRowId());
            Assertions.assertFalse(tokenizeBulkResult.getRowId().isEmpty());
            Assertions.assertNotNull(tokenizeBulkResult.getErrorMessage());
            Assertions.assertTrue(tokenizeBulkResult.getErrorMessage().contains(validateMessage[2]));
            Assertions.assertNull(tokenizeBulkResult.getTokenReference());
            Assertions.assertNull(tokenizeBulkResult.getTspTokenReference());
        }
    }
}
