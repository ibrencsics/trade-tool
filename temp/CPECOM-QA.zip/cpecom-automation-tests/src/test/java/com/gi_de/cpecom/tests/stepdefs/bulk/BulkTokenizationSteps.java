package com.gi_de.cpecom.tests.stepdefs.bulk;

import com.gi_de.cpecom.tests.model.bulk.*;
import com.gi_de.cpecom.tests.model.common.*;
import com.gi_de.cpecom.tests.model.tokenization.RiskData;
import com.gi_de.cpecom.tests.model.tokenization.UserData;
import com.gi_de.cpecom.tests.stepdefs.base.StepDefinitionBase;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.vavr.Tuple2;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.junit.platform.commons.util.StringUtils;

import java.io.IOException;
import java.io.Reader;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Log4j2
public class BulkTokenizationSteps extends StepDefinitionBase {

    private TokenizeBulkRequest tokenizeBulkRequest;
    private Tuple2<Integer, TokenizeBulkResultsResponse> tokenizeBulkResultsResponseTuple;
    private Tuple2<Integer, TokenizeBulkResultsResponse> tokenizeBulkResultsResponseTuple2;

    @DataTableType(replaceWithEmptyString = "[blank]")
    public BulkRequestDataTable bulkRequestDataTableEntryTransformer(Map<String, String> entry) {
        return BulkRequestDataTable.builder()
                .rowId(entry.get("rowId"))
                .cardNumber(entry.get("cardNumber"))
                .expiryDate(entry.get("expiryDate"))
                .cvvStr(entry.get("cvvStr"))
                .accountId(entry.get("accountId"))
                .email(entry.get("email"))
                .firstName(entry.get("firstName"))
                .lastName(entry.get("lastName"))
                .phoneCountry(entry.get("phoneCountry"))
                .phoneNumber(entry.get("phoneNumber"))
                .consumerCountry(entry.get("consumerCountry"))
                .consumerLanguage(entry.get("consumerLanguage"))
                .ip4address(entry.get("ip4address"))
                .locationLatitude(entry.get("locationLatitude"))
                .locationLongitude(entry.get("locationLongitude"))
                .accountScore(entry.get("accountScore"))
                .deviceScore(entry.get("deviceScore"))
                .build();
    }

    @Given("a mastercard bulk tokenize request with following tokenize bulk request data with mandatory only fields")
    public void aMastercardBulkTokenizeRequestWithFollowingTokenizeBulkRequestDataWithMandatoryOnlyFields(List<BulkRequestDataTable> bulkRequestDataTableList) {
        List<FundingAccountBulk> fundingAccountBulkList = createFundingAccountBulk(
                bulkRequestDataTableList,
                DataGenerator.getUserDataWithMandatoryOnly(),
                null);
        this.tokenizeBulkRequest = createTokenizeBulkRequestData(PAYMENT_SCHEME_MASTERCARD, fundingAccountBulkList);
    }

    @Given("a mastercard bulk tokenize request with following tokenize bulk request data")
    public void aMastercardBulkTokenizeRequestWithFollowingTokenizeBulkRequestData(List<BulkRequestDataTable> bulkRequestDataTableList) {
        List<FundingAccountBulk> fundingAccountBulkList = createFundingAccountBulk(
                bulkRequestDataTableList,
                null,
                null);
        this.tokenizeBulkRequest = createTokenizeBulkRequestData(PAYMENT_SCHEME_MASTERCARD, fundingAccountBulkList);
    }

    @Given("a valid visa bulk tokenize request with following tokenize bulk request data with mandatory only fields")
    public void aValidVisaBulkTokenizeRequestWithFollowingTokenizeBulkRequestDataWithMandatoryOnlyFields(List<BulkRequestDataTable> bulkRequestDataTableList) {
        List<FundingAccountBulk> fundingAccountBulkList = createFundingAccountBulk(
                bulkRequestDataTableList,
                DataGenerator.getUserDataWithMandatoryOnly(),
                null);
        this.tokenizeBulkRequest = createTokenizeBulkRequestData(PAYMENT_SCHEME_VISA, fundingAccountBulkList);
    }

    @Given("a valid visa bulk tokenize request with following tokenize bulk request data")
    public void aValidVisaBulkTokenizeRequestWithFollowingTokenizeBulkRequestData(List<BulkRequestDataTable> bulkRequestDataTableList) {
        List<FundingAccountBulk> fundingAccountBulkList = createFundingAccountBulk(
                bulkRequestDataTableList,
                null,
                null);
        this.tokenizeBulkRequest = createTokenizeBulkRequestData(PAYMENT_SCHEME_VISA, fundingAccountBulkList);
    }

    private TokenizeBulkRequest createTokenizeBulkRequestData(String paymentScheme, List<FundingAccountBulk> fundingAccountBulkList) {
        final String jobId = CpecomIdGenerator.generateUniqueId();
        return TokenizeBulkRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(paymentScheme))
                .paymentScheme(paymentScheme)
                .jobId(jobId)
                .fundingAccounts(fundingAccountBulkList)
                .build();
    }

    private List<FundingAccountBulk> createFundingAccountBulk(List<BulkRequestDataTable> bulkRequestDataTableList, UserData userData, RiskData riskData) {
        return DataGenerator.getFundingAccountBulkList(bulkRequestDataTableList, userData, riskData);
    }

    @When("a {string} api request is sent to \"tokenize-bulk\" API")
    public void anApiRequestIsSentToTokenizeBulkAPI(String paymentScheme) {
        this.tokenizeBulkResultsResponseTuple = tokenizeBulk(this.tokenizeBulkRequest, paymentScheme);
    }

    @Then("it should successfully respond with tokenize bulk response and JobStatus should be \"INPROGRESS\"")
    public void itShouldSuccessfullyRespondWithTokenizeBulkResponseAndJobStatusShouldBe() {
        assertTokenizeBulkResponseSuccess(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2);
    }

    @And("it should also successfully fetch or poll {string} bulk results from \"tokenize-bulk-results\" api as soon as JobStatus is \"DONE\"")
    public void itShouldAlsoSuccessfullyFetchOrPollBulkResultsFromApiAsSoonAsJobStatusIs(String paymentScheme) {
        if (tokenizeBulkRequest != null && StringUtils.isNotBlank(tokenizeBulkRequest.getJobId())) {
            sendPollTokenizeBulkResultsApiRequest(paymentScheme);
            assertTokenizeBulkResultsResponseSuccess(tokenizeBulkResultsResponseTuple2._1, tokenizeBulkResultsResponseTuple2._2);
        }
    }

    public void cleanUpScenario() {
        if (this.tokenizeBulkResultsResponseTuple2 != null && this.tokenizeBulkResultsResponseTuple2._2 != null) {
            log.info("***************************************** Mastercard tokenize bulk clean up Started *****************************************");
            log.info("Tokenize bulk results response size {} ...", this.tokenizeBulkResultsResponseTuple2._2.getResults().size());
            for (var tokenizeBulkResult : this.tokenizeBulkResultsResponseTuple2._2.getResults()) {
                if (BulkStatusCode.OK.name().equals(tokenizeBulkResult.getStatusCode())
                        && StringUtils.isNotBlank(tokenizeBulkResult.getTokenReference())) {
                    deleteAllCreatedTokens(tokenizeBulkResult.getTokenReference(), PAYMENT_SCHEME_MASTERCARD);
                }

            }
            this.tokenizeBulkResultsResponseTuple2 = null;
            log.info("***************************************** Mastercard Tokenize bulk clean up Ended *****************************************");
        }
    }

    @SneakyThrows
    @Given("a {string} bulk tokenize request with 1500 valid accounts from file {string}.")
    public void aBulkTokenizeRequestWithValidAccountsFromProvidedFile(String paymentScheme, String bulkTestDataFileName) {
        List<FundingAccountBulk> fundingAccountBulkList = createFundingAccountBulk(readDataFromCSVFile(bulkTestDataFileName), DataGenerator.getUserData(), DataGenerator.getRiskData());
        this.tokenizeBulkRequest = createTokenizeBulkRequestData(paymentScheme, fundingAccountBulkList);
    }

    private List<BulkRequestDataTable> readDataFromCSVFile(final String bulkTestDataFileName) throws IOException, URISyntaxException {
        List<BulkRequestDataTable> bulkRequestDataTableList = new ArrayList<>();
        String[] HEADERS = {"rowId", "cardNumber", "expiryDate", "cvvStr"};
        URL resource = BulkTokenizationSteps.class.getResource("/" + bulkTestDataFileName);
        if (resource != null) {
            try (
                    Reader reader = Files.newBufferedReader(Paths.get(resource.toURI()));
                    CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.builder()
                            .setHeader(HEADERS)
                            .setSkipHeaderRecord(true)
                            .setIgnoreHeaderCase(true)
                            .setDelimiter(",")
                            .setAllowMissingColumnNames(false)
                            .setIgnoreEmptyLines(true)
                            .setIgnoreSurroundingSpaces(true)
                            .setTrim(true)
                            .build())
            ) {
                for (CSVRecord csvRecord : csvParser) {
                    bulkRequestDataTableList.add(BulkRequestDataTable.builder()
                            .rowId(csvRecord.get("rowId"))
                            .cardNumber(csvRecord.get("cardNumber"))
                            .expiryDate(csvRecord.get("expiryDate"))
                            .cvvStr(csvRecord.get("cvvStr"))
                            .build());
                }
            }
        }
        return bulkRequestDataTableList;
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: encFundingAccountData: must not be null\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsMustNotBeNull() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: encFundingAccountData: must not be null");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: encFundingAccountData: size must be between 1 and 2147483647\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsSizeMustBeBetween() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: encFundingAccountData: size must be between 1 and 2147483647");
    }

    @And("it should also successfully fetch or poll {string} bulk results from \"tokenize-bulk-results\" api as soon as JobStatus is \"DONE\" and results should have one \"BAD_REQUEST\"")
    public void itShouldAlsoSuccessfullyFetchOrPollBulkResultsFromApiAsSoonAsJobStatusIsAndResultsShouldHaveOneBAD_REQUEST(String paymentScheme) {
        if (tokenizeBulkRequest != null && StringUtils.isNotBlank(tokenizeBulkRequest.getJobId())) {
            sendPollTokenizeBulkResultsApiRequest(paymentScheme);
            assertTokenizeBulkResultsResponseSuccessAndError(
                    this.tokenizeBulkResultsResponseTuple2._1,
                    this.tokenizeBulkResultsResponseTuple2._2,
                    "Validation error: encFundingAccountData: must not be null");
        }
    }

    private void sendPollTokenizeBulkResultsApiRequest(final String paymentScheme){
        final var tokenizeBulkResultsRequest = TokenizeBulkResultsRequest
                .builder()
                .jobId(tokenizeBulkRequest.getJobId())
                .build();
        this.tokenizeBulkResultsResponseTuple2 = pollTokenizeBulkResults(tokenizeBulkResultsRequest, paymentScheme);
    }

    @SneakyThrows
    @And("\"tokenize-bulk-results\" api should respond with status as \"400\" and errorMessage with \"INVALID_STATE\" and [Invalid PAN]")
    public void mastercardApiShouldRespondWithStatusAsAndErrorMessageWithAndInvalidPAN() {
        if (tokenizeBulkRequest != null && StringUtils.isNotBlank(tokenizeBulkRequest.getJobId())) {
            sendPollTokenizeBulkResultsApiRequest(PAYMENT_SCHEME_MASTERCARD);
            assertTokenizeBulkResultsResponseError(
                    this.tokenizeBulkResultsResponseTuple2._1,
                    this.tokenizeBulkResultsResponseTuple2._2,
                    TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_BAD_REQUEST_ERROR_TSP_INVALID_CARD_DATA),
                    "status: '400', reason: 'INVALID_STATE', message: 'Request cannot be executed due to the incorrect field value', details: '[Invalid PAN]'");
        }
    }

    @SneakyThrows
    @And("\"tokenize-bulk-results\" api should respond with status as \"VTS_INVALID_PARAMETER\" and errorMessage with \"accountNumber is invalid\"")
    public void visaApiShouldRespondWithStatusAsAndErrorMessageWithAndInvalidPAN() {
        if (tokenizeBulkRequest != null && StringUtils.isNotBlank(tokenizeBulkRequest.getJobId())) {
            sendPollTokenizeBulkResultsApiRequest(PAYMENT_SCHEME_VISA);
            assertTokenizeBulkResultsResponseError(
                    this.tokenizeBulkResultsResponseTuple2._1,
                    this.tokenizeBulkResultsResponseTuple2._2,
                    TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_INVALID_PARAMETER_TSP_INVALID_CARD_DATA),
                    "tspMessage: Input for encPaymentInstrument.paymentInstrument.accountNumber is invalid, location: encPaymentInstrument.paymentInstrument.accountNumber");
        }
    }

    @SneakyThrows
    @And("\"tokenize-bulk-results\" api should respond with status as \"400\" and errorMessage with \"INVALID_ARGUMENT\" and [Card Expired]")
    public void apiShouldRespondWithStatusAsAndErrorMessageWithInvalidArgumentAndCardExpired() {
        if (tokenizeBulkRequest != null && StringUtils.isNotBlank(tokenizeBulkRequest.getJobId())) {
            sendPollTokenizeBulkResultsApiRequest(PAYMENT_SCHEME_MASTERCARD);
            assertTokenizeBulkResultsResponseError(
                    this.tokenizeBulkResultsResponseTuple2._1,
                    this.tokenizeBulkResultsResponseTuple2._2,
                    TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_BAD_REQUEST_ERROR_TSP_INVALID_CARD_DATA),
                    "status: '400', reason: 'INVALID_ARGUMENT', message: 'Cannot process the request because it is malformed or has incorrect/missing fields or values.', details: '[Card Expired]'");
        }
    }

    @SneakyThrows
    @And("\"tokenize-bulk-results\" api should respond with status as \"VTS_CARD_NOT_ALLOWED\" and errorMessage with \"tspMessage: The requested action is not allowed for the given PAN\"")
    public void apiVisaShouldRespondWithStatusAsAndErrorMessageWithVtsCardNotAllowed() {
        if (tokenizeBulkRequest != null && StringUtils.isNotBlank(tokenizeBulkRequest.getJobId())) {
            sendPollTokenizeBulkResultsApiRequest(PAYMENT_SCHEME_VISA);
            assertTokenizeBulkResultsResponseError(
                    this.tokenizeBulkResultsResponseTuple2._1,
                    this.tokenizeBulkResultsResponseTuple2._2,
                    TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_CARD_NOT_ALLOWED_TSP_INVALID_CARD_DATA),
                    "tspMessage: The requested action is not allowed for the given PAN.");
        }
    }

    @And("\"tokenize-bulk-results\" api should respond with successful tokenReference for one of the PAN and others may be INTERNAL_SERVER_ERROR")
    public void apiShouldRespondWithSuccessfulTokenReferenceForOneOfThePANAndOthersMayBeINTERNAL_SERVER_ERROR() {
        if (tokenizeBulkRequest != null && StringUtils.isNotBlank(tokenizeBulkRequest.getJobId())) {
            sendPollTokenizeBulkResultsApiRequest(PAYMENT_SCHEME_MASTERCARD);
            assertTokenizeBulkResultsAtLeastOneSuccessResponse(
                    this.tokenizeBulkResultsResponseTuple2._1,
                    this.tokenizeBulkResultsResponseTuple2._2,
                    "status: '503', reason: 'UNAVAILABLE', message: 'Service unavailable. Typically the server not able to serve the request temporarily. Retry after some time', details: '[]'");
        }
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: userData.phoneCountry: must match regX\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorPhoneCountry() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: userData.phoneCountry: must match \"^\\d{2,3}$\"");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: userData.phoneNumber: must match regX\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorPhoneNumber() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: userData.phoneNumber: must match \"^\\d+$\"");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: userData.consumerCountry: must match regX\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorConsumerCountry() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: userData.consumerCountry: must match \"^[A-Za-z]{2}$\"");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: userData.consumerLanguage: must match regX\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorConsumerLanguage() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: userData.consumerLanguage: must match \"^[A-Za-z]{2}$\"");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: userData.email: size must be between 0 and 255\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorEmail255MaxLimit() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: userData.email: size must be between 0 and 255");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: userData.firstName: size must be between 0 and 30\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorFirstName30MaxLimit() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: userData.firstName: size must be between 0 and 30");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: userData.lastName: size must be between 0 and 30\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorLastName30MaxLimit() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: userData.lastName: size must be between 0 and 30");
    }

    @SneakyThrows
    @And("{string} should respond with jobStatus='DONE' and results should contains statusCode='SERVICE_ERROR' with errorMessage as \"tspMessage: The request is invalid. Following parameters may be invalid:<locale>, location: locale\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeSERVICE_ERRORWithErrorMessageAsValidationErrorConsumerLanguageInvalidLocale(String paymentScheme) {
        if (tokenizeBulkRequest != null && StringUtils.isNotBlank(tokenizeBulkRequest.getJobId())) {
            sendPollTokenizeBulkResultsApiRequest(paymentScheme);
            assertTokenizeBulkResponseError(
                    this.tokenizeBulkResultsResponseTuple2._1,
                    this.tokenizeBulkResultsResponseTuple2._2,
                    JobStatusEnum.DONE.name(),
                    TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.SERVICE_ERROR_TSP_SERVICE_ERROR),
                    "tspMessage: The request is invalid. Following parameters may be invalid:<locale>, location: locale");
        }
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: riskData.ip4address: must match regX\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorIpAddressRegXFormat() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: riskData.ip4address: must match \"^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$\"");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: riskData.locationLatitude: must match regX\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorLocationLatitudeRegXFormat() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: riskData.locationLatitude: must match \"^([-+]?\\d{1,2})([.]\\d{1,4}){0,1}$\"");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: riskData.locationLongitude: must match regX\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorLocationLongitudeRegXFormat() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: riskData.locationLongitude: must match \"^([-+]?\\d{1,3})([.]\\d{1,4}){0,1}$\"");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: riskData.accountScore: must match \"^[1-5]$\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorAccountScoreRegXFormat() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: riskData.accountScore: must match \"^[1-5]$\"");
    }

    @Then("it should respond with jobStatus='FAILED' and results should contains statusCode='BAD_REQUEST' with errorMessage as \"Validation error: riskData.deviceScore: must match \"^[1-5]$\"")
    public void itShouldRespondWithJobStatusFAILEDAndResultsShouldContainsStatusCodeBAD_REQUESTWithErrorMessageAsValidationErrorDeviceScoreRegXFormat() {
        assertTokenizeBulkResponseError(
                this.tokenizeBulkResultsResponseTuple._1,
                this.tokenizeBulkResultsResponseTuple._2,
                JobStatusEnum.FAILED.name(),
                "BAD_REQUEST",
                "Validation error: riskData.deviceScore: must match \"^[1-5]$\"");
    }
}
