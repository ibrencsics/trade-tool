/*
 * Copyright (c) Giesecke+Devrient Mobile Security GmbH 2020-2023
 */
package com.gi_de.cpecom.tests.common.customer;

import com.gi_de.cpecom.tests.common.customer.key.KeyService;
import com.gi_de.cpecom.tests.common.customer.key.LocalKeyService;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.ECDHEncrypter;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.jwk.ECKey;
import com.nimbusds.jose.jwk.RSAKey;
import lombok.SneakyThrows;

public class CustomerRequestEncryptor {

    final KeyService keyService = new LocalKeyService();

    @SneakyThrows
    public String encryptRsa(final String plain) {
        final RSAKey rsaKey = RSAKey.parse(keyService.exportKey(TestKeyLabels.CUST1_CP_RSAPRIV_DEC_001).block());
        return jweRsaEncrypt(plain, rsaKey, TestKeyLabels.CUST1_CP_RSAPRIV_DEC_001);
    }

    @SneakyThrows
    public String encryptEc(final String plain) {
        final ECKey ecKey = ECKey.parse(keyService.exportKey(TestKeyLabels.CUST1_CP_ECPRIV_DEC_001).share().block());
        return jweEcEncrypt(plain, ecKey, TestKeyLabels.CUST1_CP_ECPRIV_DEC_001);
    }

    // These methods are copied from the cpecom-key-manager, class CryptoTester.java

    @SneakyThrows
    private static String jweRsaEncrypt(final String plain, final RSAKey rsaKey, final String kid) {
        final JWEObject jwe = new JWEObject(
            new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A128GCM)
                .keyID(kid)
                .customParam("iat", String.valueOf(System.currentTimeMillis() / 1000L))
                .build(),
            new Payload(plain)
        );
        jwe.encrypt(new RSAEncrypter(rsaKey));
        return jwe.serialize();
    }

    @SneakyThrows
    private static String jweEcEncrypt(final String plain, final ECKey ecKey, final String kid) {
        final JWEObject jwe = new JWEObject(
            new JWEHeader.Builder(JWEAlgorithm.ECDH_ES_A128KW, EncryptionMethod.A128GCM)
                .keyID(kid)
                .customParam("iat", String.valueOf(System.currentTimeMillis() / 1000L))
                .build(),
            new Payload(plain)
        );
        jwe.encrypt(new ECDHEncrypter(ecKey));
        return jwe.serialize();
    }
}
