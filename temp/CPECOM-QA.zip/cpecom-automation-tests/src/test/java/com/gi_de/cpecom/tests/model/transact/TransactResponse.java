package com.gi_de.cpecom.tests.model.transact;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.gi_de.cpecom.tests.model.tokenization.TokenInfo;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class TransactResponse {

    private String statusCode;

    private String errorMessage;

    private String tspTransactionId;

    private TokenInfo tokenInfo;

    private String encTransactionPayload;

}
