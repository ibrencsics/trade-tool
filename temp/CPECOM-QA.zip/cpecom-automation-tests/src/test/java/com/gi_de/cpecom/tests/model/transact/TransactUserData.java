package com.gi_de.cpecom.tests.model.transact;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class TransactUserData {

    private String email;

}
