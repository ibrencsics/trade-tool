package com.gi_de.cpecom.tests.model.common;

import com.gi_de.cpecom.tests.common.exceptions.ConfigPropertiesNotFoundException;
import com.gi_de.cpecom.tests.common.exceptions.CusterIdNotFoundException;
import com.gi_de.cpecom.tests.config.ConfigPropertiesLoader;
import com.gi_de.cpecom.tests.config.SystemEnvironments;

import java.util.Properties;

public class TspStatusCodeMapper {

    public static String getErrorStatusCode(TspStatusCodeMapperEnum tspStatusCodeMapperEnum) throws ConfigPropertiesNotFoundException, CusterIdNotFoundException {
        return switch (tspStatusCodeMapperEnum) {
            case MCSCOF_NOT_FOUND_TSP_SERVICE_ERROR ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.MCSCOF_NOT_FOUND, TspStatusCodeEnum.TSP_SERVICE_ERROR);
            case MCSCOF_BAD_REQUEST_ERROR_TSP_CARD_NOT_ELIGIBLE ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.MCSCOF_BAD_REQUEST_ERROR, TspStatusCodeEnum.TSP_CARD_NOT_ELIGIBLE);
            case MCSCOF_BAD_REQUEST_ERROR_TSP_ISSUER_DECLINED ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.MCSCOF_BAD_REQUEST_ERROR, TspStatusCodeEnum.TSP_ISSUER_DECLINED);
            case MCSCOF_BAD_REQUEST_ERROR_TSP_INVALID_CARD_DATA ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.MCSCOF_BAD_REQUEST_ERROR, TspStatusCodeEnum.TSP_INVALID_CARD_DATA);
            case MCSCOF_BAD_REQUEST_ERROR_TSP_UNKNOWN_ERROR ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.MCSCOF_BAD_REQUEST_ERROR, TspStatusCodeEnum.TSP_UNKNOWN_ERROR);
            case MCSCOF_TEMPORARY_INTERNAL_SERVER_ERROR_TSP_TEMPORARY_SERVICE_ERROR ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.MCSCOF_TEMPORARY_INTERNAL_SERVER_ERROR, TspStatusCodeEnum.TSP_TEMPORARY_SERVICE_ERROR);
            case VTS_CARD_NOT_ELIGIBLE_TSP_CARD_NOT_ELIGIBLE ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.VTS_CARD_NOT_ELIGIBLE, TspStatusCodeEnum.TSP_CARD_NOT_ELIGIBLE);
            case VTS_CARD_VERIFICATION_ERROR_TSP_INVALID_CARD_DATA ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.VTS_CARD_VERIFICATION_ERROR, TspStatusCodeEnum.TSP_INVALID_CARD_DATA);
            case VTS_CARD_NOT_ALLOWED_TSP_INVALID_CARD_DATA ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.VTS_CARD_NOT_ALLOWED, TspStatusCodeEnum.TSP_INVALID_CARD_DATA);
            case VTS_INVALID_PARAMETER_TSP_UNKNOWN_ERROR ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.VTS_INVALID_PARAMETER, TspStatusCodeEnum.TSP_UNKNOWN_ERROR);
            case SERVICE_ERROR_TSP_SERVICE_ERROR ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.SERVICE_ERROR, TspStatusCodeEnum.TSP_SERVICE_ERROR);
            case VTS_INVALID_PARAMETER_TSP_INVALID_CARD_DATA ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.VTS_INVALID_PARAMETER, TspStatusCodeEnum.TSP_INVALID_CARD_DATA);
            case VTS_NOT_ALLOWED_TSP_OPERATION_NOT_ALLOWED ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.VTS_NOT_ALLOWED, TspStatusCodeEnum.TSP_OPERATION_NOT_ALLOWED);
            case VTS_DECLINED_TSP_ISSUER_DECLINED ->
                    getApiVersionStatusCode(CoreStatusCodeEnum.VTS_DECLINED, TspStatusCodeEnum.TSP_ISSUER_DECLINED);

        };
    }

    private static String getApiVersionStatusCode(CoreStatusCodeEnum coreStatusCodeEnum, TspStatusCodeEnum tspStatusCodeEnum) throws CusterIdNotFoundException, ConfigPropertiesNotFoundException {
        String customerApiVersionId = "customer-id-" + SystemEnvironments.getCustomerIdSystemEnv() + "-newStatusCodesEnabled";
        Properties properties = ConfigPropertiesLoader.getInstance();
        String customerSupportedVersionId = properties.getProperty(customerApiVersionId);
        if (Boolean.parseBoolean(customerSupportedVersionId)) {
            return tspStatusCodeEnum.name();
        }
        return coreStatusCodeEnum.name();
    }
}
