package com.gi_de.cpecom.tests.model.suspend;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class SuspendResponse {

    private String statusCode;

    private String errorMessage;
}
