package com.gi_de.cpecom.tests.model.common;

public enum CpecomStatusCodeEnum {
    BAD_REQUEST
}
