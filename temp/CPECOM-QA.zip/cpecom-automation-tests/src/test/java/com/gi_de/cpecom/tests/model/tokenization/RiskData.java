package com.gi_de.cpecom.tests.model.tokenization;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class RiskData {

    private String ip4address;

    private String locationLatitude;

    private String locationLongitude;

    private String accountScore;

    private String deviceScore;

}
