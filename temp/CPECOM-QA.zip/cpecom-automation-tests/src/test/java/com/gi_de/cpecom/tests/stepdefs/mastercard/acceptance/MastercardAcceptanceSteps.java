package com.gi_de.cpecom.tests.stepdefs.mastercard.acceptance;


import com.gi_de.cpecom.tests.model.common.CoreStatusCodeEnum;
import com.gi_de.cpecom.tests.model.common.DataGenerator;
import com.gi_de.cpecom.tests.model.common.TspStatusCodeMapper;
import com.gi_de.cpecom.tests.model.common.TspStatusCodeMapperEnum;
import com.gi_de.cpecom.tests.model.delete.DeleteRequest;
import com.gi_de.cpecom.tests.model.delete.DeleteResponse;
import com.gi_de.cpecom.tests.model.suspend.SuspendRequest;
import com.gi_de.cpecom.tests.model.suspend.SuspendResponse;
import com.gi_de.cpecom.tests.model.tokenInfo.TokenInfoRequest;
import com.gi_de.cpecom.tests.model.tokenInfo.TokenInfoResponse;
import com.gi_de.cpecom.tests.model.tokenization.*;
import com.gi_de.cpecom.tests.model.transact.*;
import com.gi_de.cpecom.tests.stepdefs.base.StepDefinitionBase;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.vavr.Tuple2;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.awaitility.Awaitility;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

@Log4j2
public class MastercardAcceptanceSteps extends StepDefinitionBase {
    private TokenRequest tokenRequest;
    private Tuple2<Integer, TokenResponse> tokenResponseTuple;
    private Set<Tuple2<Integer, TokenResponse>> tokenResponseTupleList;
    private DeleteRequest deleteRequest;
    private Tuple2<Integer, DeleteResponse> deleteResponseTuple;
    private SuspendRequest suspendRequest;
    private Tuple2<Integer, SuspendResponse> suspendResponseTuple;
    private TransactRequest transactRequest;
    private Tuple2<Integer, TransactResponse> transactResponseTuple;
    private TokenInfoRequest tokenInfoRequest;
    private Tuple2<Integer, TokenInfoResponse> tokenInfoResponseTuple;

    @Given("a tokenRequest with values {string}, {string}, {string}, {string} and {string}")
    public void givenATokenRequestWithValues(String cardNumber, String expiryDateStr, String cvvStr, String fadPanSource, String consumerEntryModeStr) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr);

        tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .paymentScheme(PAYMENT_SCHEME_MASTERCARD)
                .userData(DataGenerator.getUserData())
                .fundingAccountData(fundingAccountData)
                .riskData(DataGenerator.getRiskData())
                .build();
    }

    @And("a successful tokenResponse from previous call and given a \"DeleteRequest\" with received \"tokenReference\"")
    public void aSuccessfulTokenResponseFromPreviousCallAndGivenAWith() {
        String tokenReference = this.tokenResponseTuple._2.getTokenReference();
        log.info("TokenReference to delete : {}", tokenReference);

        // Given following delete request
        this.deleteRequest = DeleteRequest.builder()
                .tokenReference(tokenReference)
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .reasonCode("CUSTOMER_CONFIRMED")
                .reasonDescription("Some description text")
                .build();
    }

    @Given("a successful tokenResponse from previous call and given a \"TransactRequest\" with received \"tokenReference\"")
    public void aSuccessfulTokenResponseFromPreviousCallAndGivenTransactRequestWithReceivedTokenReference() {
        String tokenReference = this.tokenResponseTuple._2.getTokenReference();
        log.info("TokenReference to delete : {}", tokenReference);

        // Given following TRANSACT request
        this.transactRequest = TransactRequest.builder()
                .tokenReference(tokenReference)
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .transactionData(TransactionData.builder()
                        .transactionType("MIT")
                        .cryptogramType("MC_DSRP_SHORT")
                        .amount("100.00")
                        .currencyCode("840")
                        .merchantId("0815")
                        .sigDeviceDynamicData("sigDeviceDynamicData-12345")
                        .build())
                .transactUserData(TransactUserData.builder().email("test@ecomTest.com").build())
                .transactRiskData(TransactRiskData.builder().ip4address("127.0.0.1").build())
                .build();
    }

    @Given("a successful tokenResponse from previous call and given a \"SuspendRequest\" with received \"tokenReference\"")
    public void aSuccessfulTokenResponseFromPreviousCallAndGivenASuspendRequestWithReceivedTokenReference() {
        String tokenReference = this.tokenResponseTuple._2.getTokenReference();
        log.info("TokenReference to delete : {}", tokenReference);

        // Given following delete request
        this.suspendRequest = SuspendRequest.builder()
                .tokenReference(tokenReference)
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .reasonCode("CUSTOMER_CONFIRMED")
                .reasonDescription("Some description text")
                .build();
    }

    @Given("a another \"DeleteRequest\" with the same \"tokenReference\" received in previous \"Tokenize\" call")
    public void aAnotherDeleteRequestWithTheSameTokenReferenceReceivedInPreviousTokenizeCall() {
    }

    @Given("a tokenRequest values with RiskData latitude and longitude {string}, {string}, {string}, {string}, {string}, {string} and {string}")
    public void aTokenRequestValuesWithRiskDataLatitudeLongitude(String cardNumber, String expiryDateStr, String cvvStr, String fadPanSource, String consumerEntryModeStr, String latitude, String longitude) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr);

        final RiskData riskData = RiskData.builder()
                .locationLatitude(latitude)
                .locationLatitude(longitude)
                .build();

        tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .paymentScheme(PAYMENT_SCHEME_MASTERCARD)
                .userData(UserData.builder().accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID).build())
                .fundingAccountData(fundingAccountData)
                .riskData(riskData)
                .build();
    }

    @Given("a tokenRequest values with RiskData ACCOUNT Score {string}, {string}, {string}, {string}, {string} and {string}")
    public void aTokenRequestValuesWithRiskDataAccountScore(String cardNumber, String expiryDateStr, String cvvStr, String fadPanSource, String consumerEntryModeStr, String accountScore) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr);

        final RiskData riskData = RiskData.builder()
                .accountScore(accountScore)
                .build();

        tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .paymentScheme(PAYMENT_SCHEME_MASTERCARD)
                .userData(UserData.builder().accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID).build())
                .fundingAccountData(fundingAccountData)
                .riskData(riskData)
                .build();
    }

    @Given("a tokenRequest values with RiskData DEVICE Score {string}, {string}, {string}, {string}, {string} and {string}")
    public void aTokenRequestValuesWithRiskDataDeviceScore(String cardNumber, String expiryDateStr, String cvvStr, String fadPanSource, String consumerEntryModeStr, String deviceScore) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr);

        final RiskData riskData = RiskData.builder()
                .deviceScore(deviceScore)
                .build();

        tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .paymentScheme(PAYMENT_SCHEME_MASTERCARD)
                .userData(UserData.builder().accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID).build())
                .fundingAccountData(fundingAccountData)
                .riskData(riskData)
                .build();
    }

    @And("a successful tokenResponse from previous call and given a \"TokenInfoRequest\" with received \"tokenReference\"")
    public void aSuccessfulTokenResponseFromPreviousCallAndGivenATokenInfoRequestWithReceivedTokenReference() {
        String tokenReference = this.tokenResponseTuple._2.getTokenReference();
        log.info("TokenReference to get token Info : {}", tokenReference);

        // Given following delete request
        this.tokenInfoRequest = TokenInfoRequest.builder()
                .tokenReference(tokenReference)
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .build();
    }

    @When("an api request is sent to \"Tokenize\" API")
    public void anApiRequestIsSentToTokenizeAPI() {
        this.tokenResponseTuple = tokenize(tokenRequest, PAYMENT_SCHEME_MASTERCARD);
    }

    @When("{int} api requests are sent to \"Tokenize\" API for same the FPAN")
    public void apiRequestsAreSentToAPIForSameTheFPAN(int requestCount) {
        this.tokenResponseTupleList = new HashSet<>();
        IntStream
                .range(0, requestCount)
                .forEach(i -> this.tokenResponseTupleList.add(tokenize(tokenRequest, PAYMENT_SCHEME_MASTERCARD)));
    }

    @When("an api request is sent to \"Suspend\" API")
    public void anApiRequestIsSentToSuspendAPI() {
        this.suspendResponseTuple = suspend(suspendRequest, PAYMENT_SCHEME_MASTERCARD);
    }

    @When("a request is send to \"Delete\" API to delete the token")
    public void aRequestIsSendToToDeleteTheToken() {
        // Delete the token
        this.deleteResponseTuple = delete(deleteRequest, PAYMENT_SCHEME_MASTERCARD);
    }

    @When("a request is send to \"Delete\" API to delete ALL tokens")
    public void aRequestIsSendToToDeleteALLTokens() {
        // TODO:
        // Delete the token
        this.deleteResponseTuple = delete(deleteRequest, PAYMENT_SCHEME_MASTERCARD);
    }

    @When("a request is send to \"Delete\" API to delete the token once again")
    public void aRequestIsSendToToDeleteTheTokenOnceAgain() {
        // Delete the token
        this.deleteResponseTuple = delete(deleteRequest, PAYMENT_SCHEME_MASTERCARD);
    }

    @When("an api request is sent to \"Token-info\" API")
    public void requestIsSentToTokenizeAPIThenACallToGetCardAPIAndFinallyDeleteTheTokenUsingDeleteAPI() {
        this.tokenInfoResponseTuple = tokenInfo(this.tokenInfoRequest, PAYMENT_SCHEME_MASTERCARD);
    }

    @When("an api request is sent to \"transact\" API")
    public void anApiRequestIsSentToTransactAPI() {
        this.transactResponseTuple = transact(this.transactRequest, PAYMENT_SCHEME_MASTERCARD);
    }

    @Then("it should successfully respond with tokenResponse")
    public void itShouldSuccessfullyRespondWithTokenResponse() {
        assertTokenResponseSuccess(tokenResponseTuple._1, tokenResponseTuple._2, PAYMENT_SCHEME_MASTERCARD);
    }

    @Then("mastercard returning successful tokenResponse as NO NOT eligible pan available for testing")
    public void mastercardReturningSuccessfulTokenResponseAsNoNOTEligiblePanAvailableForTesting() {
        assertTokenResponseSuccess(tokenResponseTuple._1, tokenResponseTuple._2, PAYMENT_SCHEME_MASTERCARD);
    }

    @Then("mastercard returning successful tokenResponse as NO NOT eligible token pan available for testing")
    public void mastercardReturningSuccessfulTokenResponseAsNoNOTEligibleTokenPanAvailableForTesting() {
        assertTokenResponseSuccess(tokenResponseTuple._1, tokenResponseTuple._2, PAYMENT_SCHEME_MASTERCARD);
    }

    @Then("it should successfully respond with tokenResponse for all FPAN requests")
    public void itShouldSuccessfullyRespondWithTokenResponseForAllFPANRequests() {
        if (this.tokenResponseTupleList != null) {
            this.tokenResponseTupleList.forEach(tuple ->
                    assertTokenResponseSuccess(tuple._1, tuple._2, PAYMENT_SCHEME_MASTERCARD)
            );
        }
    }

    @Then("it should successfully SUSPEND the Token")
    public void itShouldSuccessfullySUSPENDTheToken() {
        assertSuspendResponseSuccess(suspendResponseTuple._1, suspendResponseTuple._2);
    }

    @Then("it should successfully DELETE Token")
    public void iItShouldSuccessfullyDELETEToken() {
        log.info("Token deleted successfully...");
        assertDeleteResponseSuccess(this.deleteResponseTuple._1, this.deleteResponseTuple._2);
    }

    @SneakyThrows
    @Then("TokenRequest failed with Error response \"status: '400', reason: 'INVALID_STATE', message: 'Request cannot be executed due to the incorrect field value', details: '[Tokenization request was declined by Issuer]'\"")
    public void tokenRequestFailedWithErrorResponseInvalidStateTokenizationRequestDeclinedByIssuer() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_BAD_REQUEST_ERROR_TSP_ISSUER_DECLINED),
                "status: '400', reason: 'INVALID_STATE', message: 'Request cannot be executed due to the incorrect field value', details: '[Tokenization request was declined by Issuer]'"
        );
    }

    @SneakyThrows
    @Then("DeleteRequest should failed with Error response \"status: '404', reason: 'NOT_FOUND', message: 'Card not found', details: '[]'\"")
    public void shouldRespondWithErrorWithCardNotFound() {
        assertDeleteRequestError(
                deleteResponseTuple._1,
                deleteResponseTuple._2,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_NOT_FOUND_TSP_SERVICE_ERROR),
                "status: '404', reason: 'NOT_FOUND', message: 'Card not found', details: '[]'"
        );
    }

    @Then("it should respond with successful token information")
    public void shouldRespondWithSuccessfulTokenInformation() {
        assertTokenInfoResponseSuccess(this.tokenInfoResponseTuple._1, this.tokenInfoResponseTuple._2, PAYMENT_SCHEME_MASTERCARD);
    }

    @SneakyThrows
    @Then("TokenInfoRequest failed with Error response \"status: '404', reason: 'NOT_FOUND', message: 'Not Found', details: '[Invalid card id]'\"")
    public void shouldRespondWithFailureReasonAsNOT_FOUNDAndDetailAsINVALID_CARD_ID() {
        assertTokenInfoError(
                this.tokenInfoResponseTuple._1,
                this.tokenInfoResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_NOT_FOUND_TSP_SERVICE_ERROR),
                "status: '404', reason: 'NOT_FOUND', message: 'Not Found', details: '[Invalid card id]'"
        );
    }

    @Then("it should respond with successful Transact response with properly formatted payload containing DSRP v3 cryptogram")
    public void shouldAlsoRespondWithSuccessfulTransactResponseDsrpV3Crytogram() {
        assertTokenTransactSuccess(this.transactResponseTuple._1, this.transactResponseTuple._2, PAYMENT_SCHEME_MASTERCARD);
    }

    @SneakyThrows
    @Then("TokenRequest failed with Error response \"status: '400', reason: 'INVALID_ARGUMENT', message: 'Cannot process the request because it is malformed or has incorrect-missing fields or values.', details: '[Card Expired]'\"")
    public void TokenRequestFailedWithErrorResponseAsInvalidArgumentAndCardExpired() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_BAD_REQUEST_ERROR_TSP_INVALID_CARD_DATA),
                "status: '400', reason: 'INVALID_ARGUMENT', message: 'Cannot process the request because it is malformed or has incorrect/missing fields or values.', details: '[Card Expired]'"
        );
    }

    @SneakyThrows
    @Then("TokenRequest failed with Error response \"status: '400', reason: 'INVALID_ARGUMENT', message: 'Cannot process the request because it is malformed or has incorrect-missing fields or values.', details: '[Card Expiry Month Invalid]'\"")
    public void shouldRespondWithFailureResponseWithReasonAsInvalidArgumentAndCardExpiryMonthInvalid() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_BAD_REQUEST_ERROR_TSP_INVALID_CARD_DATA),
                "status: '400', reason: 'INVALID_ARGUMENT', message: 'Cannot process the request because it is malformed or has incorrect/missing fields or values.', details: '[Card Expiry Month Invalid]'"
        );
    }

    @SneakyThrows
    @Then("TokenRequest failed with Error response \"status: '400', reason: 'INVALID_STATE', message: 'Request cannot be executed due to the incorrect field value', details: '[Invalid PAN]'\"")
    public void shouldRespondWithFailureResponseAsInvalidStateAndMessageAsIncorrectFieldValueAndDetailsAsInvalidPAN() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_BAD_REQUEST_ERROR_TSP_INVALID_CARD_DATA),
                "status: '400', reason: 'INVALID_STATE', message: 'Request cannot be executed due to the incorrect field value', details: '[Invalid PAN]'"
        );
    }

    @SneakyThrows
    @Then("TokenRequest failed with Error response \"status: '400', reason: 'INVALID_ARGUMENT', message: 'Cannot process the request because it is malformed or has incorrect-missing fields or values.', details: '[size must be between 16 and 20]'\"")
    public void shouldRespondWithFailureResponseAsInvalidArgumentStateAndMessageAsIncorrectFieldValueAndDetailsAsSizeMustBeBetween16And20() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_BAD_REQUEST_ERROR_TSP_UNKNOWN_ERROR),
                "status: '400', reason: 'INVALID_ARGUMENT', message: 'Cannot process the request because it is malformed or has incorrect/missing fields or values.', details: '[size must be between 16 and 20]'"
        );
    }

    @SneakyThrows
    @Then("TokenRequest failed with Error response \"status: '400', reason: 'INVALID_STATE', message: 'Request cannot be executed due to the incorrect field value', details: '[PAN Ineligible]'\"")
    public void shouldRespondWithFailureResponseAsInvalidStateAndMessageAsIncorrectFieldValueAndDetailsAsPanIneligible() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_BAD_REQUEST_ERROR_TSP_CARD_NOT_ELIGIBLE),
                "status: '400', reason: 'INVALID_STATE', message: 'Request cannot be executed due to the incorrect field value', details: '[PAN Ineligible]'"
        );
    }

    @SneakyThrows
    @Then("TokenRequest failed with Error response \"status: '400', reason: 'INVALID_STATE', message: 'Request cannot be executed due to the incorrect field value', details: '[Tokenization Ineligible]'\"")
    public void shouldRespondWithFailureResponseAsInvalidStateAndMessageAsIncorrectFieldValueAndDetailsAsTokenizationIneligible() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.MCSCOF_BAD_REQUEST_ERROR_TSP_CARD_NOT_ELIGIBLE),
                "status: '400', reason: 'INVALID_STATE', message: 'Request cannot be executed due to the incorrect field value', details: '[Tokenization Ineligible]'"
        );
    }

    @Then("TokenRequest failed with Error response \"Validation error: riskData locationLatitude must match with given regX\"")
    public void shouldRespondWithFailureValidationErrorRiskDataLocationLatitudeMustMatchWithGivenRegX() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                CoreStatusCodeEnum.BAD_REQUEST.name(),
                "Validation error: riskData.locationLatitude: must match \"^([-+]?\\d{1,2})([.]\\d{1,4}){0,1}$\""
        );
    }

    @Then("TokenRequest failed with Error response \"Validation error: riskData locationLatitude AND locationLongitude must match with given regX\"")
    public void shouldRespondWithFailureValidationErrorRiskDataLocationLatitudeANDLocationLongitudeMustMatchWithGivenRegX() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                CoreStatusCodeEnum.BAD_REQUEST.name(),
                "Validation error: riskData.locationLatitude: must match \"^([-+]?\\d{1,2})([.]\\d{1,4}){0,1}$\", riskData.locationLongitude: must match \"^([-+]?\\d{1,3})([.]\\d{1,4}){0,1}$\""
        );
    }

    @Before
    public void initialization() {
        this.tokenRequest = null;
        this.deleteRequest = null;
    }

    public void cleanUpScenario() {
        if (this.tokenResponseTupleList != null && !this.tokenResponseTupleList.isEmpty()) {
            log.info("***************************************** Mastercard Multiple Token clean up Started *****************************************");
            log.info("Deleting multiple {} tokens...", this.tokenResponseTupleList);
            for (var tokenRespTuple : this.tokenResponseTupleList) {
                deleteAllCreatedTokens(tokenRespTuple._2.getTokenReference(), PAYMENT_SCHEME_MASTERCARD);
            }
            this.tokenResponseTupleList = null;
            log.info("***************************************** Mastercard Token clean up Ended *****************************************");
        }
        if (this.deleteResponseTuple == null && this.tokenResponseTuple != null) {
            log.info("***************************************** Mastercard Single Token clean up Started *****************************************");
            log.info("Deleting single token...");
            deleteAllCreatedTokens(this.tokenResponseTuple._2.getTokenReference(), PAYMENT_SCHEME_MASTERCARD);
            this.tokenResponseTuple = null;
            log.info("***************************************** Mastercard Token clean up Ended *****************************************");
        }

    }


}

