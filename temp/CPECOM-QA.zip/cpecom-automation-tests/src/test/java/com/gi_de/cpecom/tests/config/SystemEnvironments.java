package com.gi_de.cpecom.tests.config;

import com.gi_de.cpecom.tests.common.exceptions.CusterIdNotFoundException;
import com.gi_de.cpecom.tests.common.exceptions.SslCertificateNotFoundException;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;

import java.util.Properties;

@Log4j2
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class SystemEnvironments {

    private final static String TARGET_ENV = "targetEnv";
    private final static String CUSTOMER_ID = "customerId";
    private final static String IS_LOCAL_RUN = "isLocalRun";
    private final static String DEV_APIM_ENV = "dev-apim";
    private final static String DEV_APPGW_ENV = "dev-appgw";
    private final static String PAT_APIM_ENV = "pat-apim";
    private final static String PAT_APPGW_ENV = "pat-appgw";
    private final static String CUSTOMER_ID_TEST = "test";
    private final static String CUSTOMER_ID_TEST_PSP_001 = "test-psp-001";
    private final static String CUSTOMER_ID_TEST_PSP_002 = "test-psp-002";

    private static String getSystemEnvironment(String name) {
        final String property = System.getProperty(name);
        return property == null ? System.getenv(name) : property;
    }

    public static String getSystemTargetEnv() {
        return getSystemEnvironment(TARGET_ENV);
    }

    public static String getIsLocalRunSystemEnv() {
        return getSystemEnvironment(IS_LOCAL_RUN);
    }

    public static String getCustomerIdSystemEnv() throws CusterIdNotFoundException {
        return switch (getSystemEnvironment(CUSTOMER_ID)) {
            case "test"         -> CUSTOMER_ID_TEST;
            case "test-psp-001" -> CUSTOMER_ID_TEST_PSP_001;
            case "test-psp-002" -> CUSTOMER_ID_TEST_PSP_002;
            default ->
                    throw new CusterIdNotFoundException("Customer Id provided as environment variable is not found...");
        };
    }

    public static String getTargetEnvConfigurationFileName() {
        final String targetEnv = getSystemTargetEnv();
        log.info("Target Config Environment : " + targetEnv);
        return switch (targetEnv) {
            case DEV_APIM_ENV  -> "dev-apim-config.properties";
            case DEV_APPGW_ENV -> "dev-appgw-config.properties";
            case PAT_APIM_ENV  -> "pat-apim-config.properties";
            case PAT_APPGW_ENV -> "pat-appgw-config.properties";
            default            -> "dev-local-apim-config.properties"; // default if no env assigned
        };
    }

    public static String getCustomerSslCertificatePath(Properties properties) throws SslCertificateNotFoundException, CusterIdNotFoundException {
        final String customerId = SystemEnvironments.getCustomerIdSystemEnv();
        log.info("Test running for Customer Id : {}", customerId);
        return switch (customerId) {
            case CUSTOMER_ID_TEST         -> properties.getProperty("test-customer-ssl-certificate-filePath");
            case CUSTOMER_ID_TEST_PSP_001 -> properties.getProperty("test-psp-001-ssl-certificate-filePath");
            default                       -> throw new SslCertificateNotFoundException("SSL customer certificate path is not configured for tests..."); // default if no env assigned
        };
    }

}
