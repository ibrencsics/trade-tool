package com.gi_de.cpecom.tests.stepdefs.base;

import com.gi_de.cpecom.tests.model.common.DataGenerator;
import com.gi_de.cpecom.tests.model.tokenization.FundingAccountData;
import com.gi_de.cpecom.tests.model.tokenization.TokenRequest;
import com.gi_de.cpecom.tests.model.tokenization.UserData;
import org.junit.platform.commons.util.StringUtils;

public class CommonStepDefinitions extends StepDefinitionBase {

    protected TokenRequest aValidMandatoryTokenRequest(
            String cardNumber,
            String expiryDateStr,
            String cvvStr,
            String fadPanSource,
            String consumerEntryModeStr,
            String paymentScheme) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr);

        return TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(paymentScheme))
                .paymentScheme(paymentScheme)
                .userData(UserData.builder().accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID).build())
                .fundingAccountData(fundingAccountData)
                .riskData(null)
                .build();
    }
}
