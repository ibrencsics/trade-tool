package com.gi_de.cpecom.tests.model.transact;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class TransactRequest {

    private String tokenReference;

    private String gdPaymentAppId;

    private TransactionData transactionData;

    private TransactUserData transactUserData;

    private TransactRiskData transactRiskData;

}
