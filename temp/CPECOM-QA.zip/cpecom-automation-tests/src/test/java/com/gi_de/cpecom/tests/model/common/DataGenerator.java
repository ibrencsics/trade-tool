package com.gi_de.cpecom.tests.model.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gi_de.cpecom.tests.common.CucumberTestUtils;
import com.gi_de.cpecom.tests.common.customer.CustomerChdBuilder;
import com.gi_de.cpecom.tests.common.customer.CustomerRequestEncryptor;
import com.gi_de.cpecom.tests.model.bulk.BulkRequestDataTable;
import com.gi_de.cpecom.tests.model.bulk.FundingAccountBulk;
import com.gi_de.cpecom.tests.model.tokenization.FundingAccountData;
import com.gi_de.cpecom.tests.model.tokenization.RiskData;
import com.gi_de.cpecom.tests.model.tokenization.UserData;
import org.junit.platform.commons.util.StringUtils;
import reactor.util.annotation.Nullable;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DataGenerator {

    public static final String CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID = "cpecomTestAutomationUserDataAccountId";
    private static final CustomerChdBuilder CUSTOMER_CHD_BUILDER = new CustomerChdBuilder(
            new CustomerRequestEncryptor(),
            new ObjectMapper()
    );

    private static String encFundingAccountData(
            final String accountNumber,
            @Nullable final String expiryDate,
            final String securityCode
    ) {
        if (accountNumber == null && securityCode == null) {
            return null;
        } else if ("".equals(accountNumber) && "".equals(securityCode)) {
            return "";
        }
        return CUSTOMER_CHD_BUILDER.build(
                accountNumber,
                CucumberTestUtils.convertDateStringToExpiryDate(expiryDate),
                securityCode
        );
    }

    public static FundingAccountData getFundingAccountData(
            String accountNumber,
            String expiryDateStr,
            String securityCodeStr,
            String fadPanSource,
            String consumerEntryMode) {
        final String consumerEntryModeStr = StringUtils.isBlank(consumerEntryMode) ? null : consumerEntryMode;
        final String securityCode = ("null").equalsIgnoreCase(securityCodeStr) ? null : securityCodeStr;
        final String encryptedFundingAccountDataStr = encFundingAccountData(accountNumber, expiryDateStr, securityCode);

        // PushProvisioning case if panSource is VIA_APPLICATION which is not supported yet.
        if ("VIA_APPLICATION".equals(fadPanSource)) {
            return FundingAccountData.builder()
                    .panSource(fadPanSource)
                    .consumerEntryMode(consumerEntryModeStr)
                    .opaqueFundingAccountData("DM4MMC000000000BGKEJIMXUMLORTSJ2NWTCSNSQP6I4RQ659")
                    .build();
        }
        return FundingAccountData.builder()
                .panSource(fadPanSource)
                .consumerEntryMode(consumerEntryModeStr)
                .encFundingAccountData(encryptedFundingAccountDataStr)
                .build();
    }

    public static List<FundingAccountBulk> getFundingAccountBulkList(List<BulkRequestDataTable> bulkRequestDataTableList, UserData userData, RiskData riskData) {
        if (bulkRequestDataTableList == null || bulkRequestDataTableList.isEmpty()) {
            return null;
        }

        Stream<BulkRequestDataTable> bulkRequestDataTableStream;
        if (bulkRequestDataTableList.size() > 100) {
            bulkRequestDataTableStream = bulkRequestDataTableList.parallelStream();
        } else {
            bulkRequestDataTableStream = bulkRequestDataTableList.stream();
        }

        return bulkRequestDataTableStream.map(dataRow -> {
            String securityCode = ("null").equalsIgnoreCase(dataRow.getCvvStr()) ? null : dataRow.getCvvStr();
            String encryptedFundingAccountDataStr = encFundingAccountData(dataRow.getCardNumber(), dataRow.getExpiryDate(), securityCode);
            return FundingAccountBulk.builder()
                    .rowId(dataRow.getRowId())
                    .encFundingAccountData(encryptedFundingAccountDataStr)
                    .userData(userData == null ? UserData.builder()
                            .accountId(dataRow.getAccountId())
                            .email(dataRow.getEmail())
                            .firstName(dataRow.getFirstName())
                            .lastName(dataRow.getLastName())
                            .phoneCountry(dataRow.getPhoneCountry())
                            .phoneNumber(dataRow.getPhoneNumber())
                            .consumerCountry(dataRow.getConsumerCountry())
                            .consumerLanguage(dataRow.getConsumerLanguage())
                            .build() : userData)
                    .riskData(riskData == null ? RiskData.builder()
                            .ip4address(dataRow.getIp4address())
                            .locationLatitude(dataRow.getLocationLatitude())
                            .locationLongitude(dataRow.getLocationLongitude())
                            .accountScore(dataRow.getAccountScore())
                            .deviceScore(dataRow.getDeviceScore())
                            .build() : riskData)
                    .build();
        }).collect(Collectors.toList());
    }

    public static UserData getUserDataWithMandatoryOnly() {
        return UserData.builder()
                .accountId(CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID)
                .build();
    }

    public static UserData getUserData() {
        String idStr = CpecomIdGenerator.createRandomDataId();
        return UserData.builder()
                .accountId(CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID)
                .email("user" + idStr + "@test.com")
                .firstName("firstName" + idStr)
                .lastName("lastName" + idStr)
                .phoneCountry("001")
                .phoneNumber("00000000")
                .build();
    }

    public static RiskData getRiskData() {
        return RiskData.builder()
                .ip4address("100.100.100.100")
                .locationLatitude("47.7511")
                .locationLongitude("120.7401")
                .accountScore("1")
                .deviceScore("2")
                .build();
    }

   /*public static void main(String[] args) throws JsonProcessingException {
        String accountNumber = "5204731600014784";
        String expiryDate = "2025-12";
        String securityCode = "712";
        final var chd = FundingAccountDataPlain.builder()
                .accountNumber(accountNumber)
                .expirationDate(expiryDate)
                .securityCode(securityCode)
                .build();

        System.out.printf(new CustomerRequestEncryptor().encryptRsa(new ObjectMapper().writeValueAsString(chd)));
    }*/
}
