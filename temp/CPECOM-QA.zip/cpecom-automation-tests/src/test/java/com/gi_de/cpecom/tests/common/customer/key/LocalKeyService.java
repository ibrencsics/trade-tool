/*
 * Copyright (c) Giesecke+Devrient Mobile Security GmbH 2020-2023
 */
package com.gi_de.cpecom.tests.common.customer.key;

import com.nimbusds.jose.jwk.Curve;
import com.nimbusds.jose.jwk.ECKey;
import com.nimbusds.jose.jwk.OctetSequenceKey;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.util.Base64;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.junit.platform.commons.util.StringUtils;
import reactor.core.publisher.Mono;

import java.io.File;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.interfaces.ECPublicKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Log4j2
@SuppressWarnings({"squid:S2068", "squid:S2386"})
@NoArgsConstructor
public class LocalKeyService implements KeyService {

    private static final String KEYSTORE_PATH_KEY = "KEYSTORE_PATH";
    public static final String DEFAULT_KEYSTORE_NAME = "key-vault-keys.jceks";
    public static final char[] PASSWORD = "123456".toCharArray();

    private static final Curve CURVE = Curve.P_256;

    private static String LOCAL_KEYSTORE_PATH = null;

    private KeyStore keyStore = null;

    // TODO(neuperts - 4/29/22): [CPECOM-422] test profile checks - this needs to be implemted correctly
    public LocalKeyService(final String keyStorePath) {
        if (LOCAL_KEYSTORE_PATH == null) {
            LOCAL_KEYSTORE_PATH = keyStorePath;
        }
    }

    @Override
    public Mono<String> exportKey(final String label) {
        return switch (getKeyType(label)) {
            case "HMAC", "AES", "SECRET" -> getSecretKey(label, label);
            case "RSAPRIV", "RSAX509", "RSAPUB" -> getRsaKey(label, label);
            case "ECPRIV", "ECX509", "ECPUB" -> getEcKey(label, label);
            default -> throw new IllegalArgumentException("Invalid key type " + getKeyType(label));
        };
    }

    // This is the only place where we exploit the fact that keys are named according to a naming convention
    // This is not production quality code
    private static String getKeyType(final String label) {
        final String[] tokens = label.split("-");

        if ("TLS".equals(tokens[0])) { // TLS-XXX-XXX
            return "RSAX509";
        } else {
            if (tokens.length < 3) {
                throw new IllegalArgumentException("Invalid key label " + label);
            }
            return tokens[2]; // XXX-XXX-<keyType>-XXX
        }
    }

    @Override
    public void warmUp() {
        log.trace("No need to warm up, this class is just for local testing");
    }

    private Mono<String> getSecretKey(final String label, final String kid) {
        return Mono.fromCallable(
            () -> {
                final var key = getKeyStore().getKey(label, PASSWORD);
                return new OctetSequenceKey.Builder(key.getEncoded())
                    .keyID(kid)
                    .build()
                    .toJSONString();
            }
        );
    }

    private Mono<String> getRsaKey(final String label, final String kid) {
        return getRsaPrivateKey(label, kid)
            .onErrorResume(t -> getRsaX509Cert(label, kid));
    }

    private Mono<String> getEcKey(final String label, final String kid) {
        return getEcPrivateKey(label, kid)
            .onErrorResume(t -> getEcX509Cert(label, kid));
    }

    private Mono<String> getRsaPrivateKey(final String label, final String kid) {
        return Mono.fromCallable(
            () -> {
                final var keyEntry = (KeyStore.PrivateKeyEntry) getKeyStore().getEntry(label, new KeyStore.PasswordProtection(PASSWORD));
                return new RSAKey.Builder((RSAPublicKey) keyEntry.getCertificate().getPublicKey())
                    .keyID(kid)
                    .privateKey(keyEntry.getPrivateKey())
                    .x509CertChain(
                        Arrays.stream(keyEntry.getCertificateChain())
                            .map(LocalKeyService::certToBase64)
                            .collect(Collectors.toList())
                    )
                    .build()
                    .toJSONString();
            }
        );
    }

    private Mono<String> getEcPrivateKey(final String label, final String kid) {
        return Mono.fromCallable(
            () -> {
                final var keyEntry = (KeyStore.PrivateKeyEntry) getKeyStore().getEntry(label, new KeyStore.PasswordProtection(PASSWORD));
                return new ECKey.Builder(CURVE, (ECPublicKey) keyEntry.getCertificate().getPublicKey())
                    .keyID(kid)
                    .privateKey(keyEntry.getPrivateKey())
                    .build()
                    .toJSONString();
            }
        );
    }

    private Mono<String> getRsaX509Cert(final String label, final String kid) {
        return Mono.fromCallable(
            () -> {
                final var cert = getKeyStore().getCertificate(label);
                return new RSAKey.Builder((RSAPublicKey) cert.getPublicKey())
                    .keyID(kid)
                    .x509CertChain(List.of(Base64.encode(cert.getEncoded())))
                    .build()
                    .toJSONString();
            }
        );
    }

    private Mono<String> getEcX509Cert(final String label, final String kid) {
        return Mono.fromCallable(
            () -> {
                final var cert = getKeyStore().getCertificate(label);
                return new ECKey.Builder(CURVE, (ECPublicKey) cert.getPublicKey())
                    .keyID(kid)
                    .x509CertChain(List.of(Base64.encode(cert.getEncoded())))
                    .build()
                    .toJSONString();
            }
        );
    }

    @SneakyThrows
    private KeyStore getKeyStore() {
        synchronized (this) {
            if (keyStore == null) {
                final String keystorePath =
                    StringUtils.isNotBlank(LOCAL_KEYSTORE_PATH) ? LOCAL_KEYSTORE_PATH : System.getenv(KEYSTORE_PATH_KEY);

                log.warn("This message MUST NOT be seen in PROD. Loaded key from {}", keystorePath);

                // Can be used in scenarios when the keygen project can be on the classpath
                // E.g. in the Azure App Service load tests
                if (keystorePath == null) {
                    final InputStream is = getClass().getClassLoader().getResourceAsStream(DEFAULT_KEYSTORE_NAME);
                    keyStore = KeyStore.getInstance("JCEKS");
                    keyStore.load(is, PASSWORD);
                    // Used in business modules (crypto, tspgw, ...) when running outside of Azure
                } else {
                    keyStore = KeyStore.getInstance(new File(keystorePath), PASSWORD);
                }
            }
            return keyStore;
        }
    }

    @SneakyThrows
    private static Base64 certToBase64(final Certificate cert) {
        return Base64.encode(cert.getEncoded());
    }
}
