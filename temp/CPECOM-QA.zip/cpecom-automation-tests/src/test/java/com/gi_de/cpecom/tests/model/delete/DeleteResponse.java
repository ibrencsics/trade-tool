package com.gi_de.cpecom.tests.model.delete;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class DeleteResponse {

    private String statusCode;

    private String errorMessage;

}
