package com.gi_de.cpecom.tests.stepdefs.visa.acceptance;

import com.gi_de.cpecom.tests.model.common.*;
import com.gi_de.cpecom.tests.model.delete.DeleteRequest;
import com.gi_de.cpecom.tests.model.delete.DeleteResponse;
import com.gi_de.cpecom.tests.model.resume.ResumeRequest;
import com.gi_de.cpecom.tests.model.resume.ResumeResponse;
import com.gi_de.cpecom.tests.model.suspend.SuspendRequest;
import com.gi_de.cpecom.tests.model.suspend.SuspendResponse;
import com.gi_de.cpecom.tests.model.tokenInfo.TokenInfoRequest;
import com.gi_de.cpecom.tests.model.tokenInfo.TokenInfoResponse;
import com.gi_de.cpecom.tests.model.tokenization.*;
import com.gi_de.cpecom.tests.model.transact.TransactRequest;
import com.gi_de.cpecom.tests.model.transact.TransactResponse;
import com.gi_de.cpecom.tests.model.transact.TransactionData;
import com.gi_de.cpecom.tests.stepdefs.base.CommonStepDefinitions;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.vavr.Tuple2;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.awaitility.Awaitility;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

@Log4j2
public class VisaAcceptanceSteps extends CommonStepDefinitions {
    private TokenRequest tokenRequest;
    private List<TokenRequest> tokenRequestList;
    private Tuple2<Integer, TokenResponse> tokenResponseTuple;
    private Tuple2<Integer, TokenResponse> tokenResponseTuple2;
    private Set<Tuple2<Integer, TokenResponse>> tokenResponseTupleList;
    private DeleteRequest deleteRequest;
    private Tuple2<Integer, DeleteResponse> deleteResponseTuple;
    private SuspendRequest suspendRequest;
    private Tuple2<Integer, SuspendResponse> suspendResponseTuple;
    private ResumeRequest resumeRequest;
    private Tuple2<Integer, ResumeResponse> resumeResponseTuple;
    private TransactRequest transactRequest;
    private Tuple2<Integer, TransactResponse> transactResponseTuple;
    private TokenInfoRequest tokenInfoRequest;
    private Tuple2<Integer, TokenInfoResponse> tokenInfoResponseTuple;


    @Given("a valid mandatory tokenRequest with values {string}, {string}, {string}, {string} and {string}")
    public void aValidMandatoryTokenRequestWithValues(String cardNumber, String expiryDateStr, String cvvStr, String fadPanSource, String consumerEntryModeStr) {
        this.tokenRequest = aValidMandatoryTokenRequest(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr, PAYMENT_SCHEME_VISA);
    }

    @Given("a visa tokenRequest values with RiskData latitude and longitude {string}, {string}, {string}, {string}, {string}, {string} and {string}")
    public void aVisaTokenRequestValuesWithRiskDataLatitudeAndLongitudeAnd(String cardNumber, String expiryDateStr, String cvvStr, String fdaPanSource, String consumerEntryModeStr, String latitude, String longitude) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fdaPanSource, consumerEntryModeStr);

        final RiskData riskData = RiskData.builder()
                .locationLatitude(latitude)
                .locationLongitude(longitude)
                .build();

        this.tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .paymentScheme(PAYMENT_SCHEME_VISA)
                .userData(UserData.builder().accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID).build())
                .fundingAccountData(fundingAccountData)
                .riskData(riskData)
                .build();
    }

    @Given("a visa tokenRequest values with RiskData ACCOUNT SCORE {string}, {string}, {string}, {string}, {string} and {string}")
    public void aVisaTokenRequestValuesWithRiskDataAccountScoreAnd(String cardNumber, String expiryDateStr, String cvvStr, String fdaPanSource, String consumerEntryModeStr, String accountScore) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fdaPanSource, consumerEntryModeStr);

        final RiskData riskData = RiskData.builder()
                .accountScore(accountScore)
                .build();

        this.tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .paymentScheme(PAYMENT_SCHEME_VISA)
                .userData(UserData.builder().accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID).build())
                .fundingAccountData(fundingAccountData)
                .riskData(riskData)
                .build();
    }

    @Given("a visa tokenRequest values with RiskData DEVICE SCORE {string}, {string}, {string}, {string}, {string} and {string}")
    public void aVisaTokenRequestValuesWithRiskDataDEVICESCOREAnd(String cardNumber, String expiryDateStr, String cvvStr, String fdaPanSource, String consumerEntryModeStr, String deviceScore) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fdaPanSource, consumerEntryModeStr);

        final RiskData riskData = RiskData.builder()
                .deviceScore(deviceScore)
                .build();

        this.tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .paymentScheme(PAYMENT_SCHEME_VISA)
                .userData(UserData.builder().accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID).build())
                .fundingAccountData(fundingAccountData)
                .riskData(riskData)
                .build();
    }

    @Given("a two visa different tokenRequests for same PAN with values {string}, {string}, {string}, {string} and {string}")
    public void visaAcceptanceTwoTokenRequestMandatoryOnlyWithValuesAnd(String cardNumber, String expiryDateStr, String cvvStr, String fdaPanSource, String consumerEntryModeStr, DataTable dataTable) {
        final String gdPaymentAppId = getGdPaymentAppId(PAYMENT_SCHEME_VISA);
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fdaPanSource, consumerEntryModeStr);

        this.tokenRequestList = new ArrayList<>();
        // Token Request 1
        final var tokenRequest_1 = TokenRequest.builder()
                .gdPaymentAppId(gdPaymentAppId)
                .paymentScheme(PAYMENT_SCHEME_VISA)
                .userData(UserData.builder()
                        .accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID)
                        .email(dataTable.asList().get(1))
                        .build())
                .fundingAccountData(fundingAccountData)
                .build();
        this.tokenRequestList.add(tokenRequest_1);
        // Token Request 2
        final var tokenRequest_2 = TokenRequest.builder()
                .gdPaymentAppId(gdPaymentAppId)
                .paymentScheme(PAYMENT_SCHEME_VISA)
                .userData(UserData.builder()
                        .accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID)
                        .email(dataTable.asList().get(2))
                        .build())
                .fundingAccountData(fundingAccountData)
                .build();
        this.tokenRequestList.add(tokenRequest_2);
    }

    @Given("a {int} visa tokenRequests for same PAN with values {string}, {string}, {string}, {string} and {string}")
    public void visaAcceptanceTwoTokenRequestMandatoryOnlyWithValuesAnd(int requestCount, String cardNumber, String expiryDateStr, String cvvStr, String fdaPanSource, String consumerEntryModeStr) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fdaPanSource, consumerEntryModeStr);
        this.tokenRequestList = new ArrayList<>();

        IntStream
                .range(0, requestCount)
                .forEach(i -> {
                    final String randomId = CpecomIdGenerator.createRandomDataId();
                    final var tokenRequest = TokenRequest.builder()
                            .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                            .paymentScheme(PAYMENT_SCHEME_VISA)
                            .userData(UserData.builder()
                                    .accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID)
                                    .firstName("firstName-" + randomId)
                                    .lastName("lastName-" + randomId)
                                    .phoneNumber("000000" + i)
                                    .phoneCountry("0" + i)
                                    .email("randomId@testg.com")
                                    .build())
                            .fundingAccountData(fundingAccountData)
                            .build();
                    this.tokenRequestList.add(tokenRequest);
                });
    }

    @When("a valid visa api request is sent to \"Tokenize\" API")
    public void aVisaApiRequestIsSentToTokenizeAPI() {
        this.tokenResponseTuple = tokenize(this.tokenRequest, PAYMENT_SCHEME_VISA);
    }

    @When("a valid one more visa api request is sent to \"Tokenize\" API")
    public void aValidOneMoreVisaApiRequestIsSentToTokenizeAPI() {
        this.tokenResponseTuple2 = tokenize(this.tokenRequest, PAYMENT_SCHEME_VISA);
    }

    @When("a valid visa api request is sent to \"Tokenize\" API with \"MISSING REQUEST ID\"")
    public void aVisaApiRequestIsSentToTokenizeAPIWithMissingRequestId() {
        final String[] nullCustomRequestId = new String[]{""};
        this.tokenResponseTuple = tokenize(this.tokenRequest, PAYMENT_SCHEME_VISA, nullCustomRequestId);
    }

    @Then("visa should successfully respond with tokenResponse")
    public void visaShouldSuccessfullyRespondWithTokenResponse() {
        assertTokenResponseSuccess(tokenResponseTuple._1, tokenResponseTuple._2, PAYMENT_SCHEME_VISA);
    }

    @And("a successful tokenResponse from previous call and given a \"SuspendRequest\" with a \"tokenReference\"")
    public void aSuccessfulTokenResponseFromPreviousCallAndGivenASuspendRequestWithATokenReference() {
        String tokenReference = this.tokenResponseTuple._2.getTokenReference();
        log.info("TokenReference to suspend : {}", tokenReference);

        // Given following suspend request
        this.suspendRequest = SuspendRequest.builder()
                .tokenReference(tokenReference)
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .reasonCode("CUSTOMER_CONFIRMED")
                .reasonDescription("Some description text")
                .build();
    }

    @When("a valid visa api request is sent to \"Suspend\" API")
    public void aValidVisaApiRequestIsSentToSuspendAPI() {
        this.suspendResponseTuple = suspend(this.suspendRequest, PAYMENT_SCHEME_VISA);
    }

    @Then("visa should successfully SUSPEND an active token")
    public void visaShouldSuccessfullySUSPENDAnActiveToken() {
        assertSuspendResponseSuccess(suspendResponseTuple._1, suspendResponseTuple._2);
    }

    @And("a successful tokenResponse from previous call and given a \"ResumeRequest\" with a \"tokenReference\"")
    public void aSuccessfulTokenResponseFromPreviousCallAndGivenResumeRequestWithATokenReference() {
        String tokenReference = this.tokenResponseTuple._2.getTokenReference();
        log.info("TokenReference to resume : {}", tokenReference);

        // Given following resume request
        this.resumeRequest = ResumeRequest.builder()
                .tokenReference(tokenReference)
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .reasonCode("CUSTOMER_CONFIRMED")
                .reasonDescription("Some description text")
                .build();
    }

    @And("a successful tokenResponse from previous call and given a valid visa \"DeleteRequest\" with a \"tokenReference\"")
    public void aSuccessfulTokenResponseFromPreviousCallAndGivenAValidVisaDeleteRequestWithATokenReference() {
        String tokenReference = this.tokenResponseTuple._2.getTokenReference();
        log.info("TokenReference to delete : {}", tokenReference);

        // Given following delete request
        this.deleteRequest = DeleteRequest.builder()
                .tokenReference(tokenReference)
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .reasonCode("CUSTOMER_CONFIRMED")
                .reasonDescription("Some description text")
                .build();
    }

    @When("a valid visa api request is sent to \"Resume\" API")
    public void aValidVisaApiRequestIsSentToResumeAPI() {
        this.resumeResponseTuple = resume(this.resumeRequest, PAYMENT_SCHEME_VISA);
    }

    @Then("visa should successfully RESUME a suspended token")
    public void visaShouldSuccessfullyRESUMEASuspendedToken() {
        assertResumeResponseSuccess(resumeResponseTuple._1, resumeResponseTuple._2);
    }

    @When("a valid visa api request is sent to \"Delete\" API")
    public void aValidVisaApiRequestIsSentToDeleteAPI() {
        this.deleteResponseTuple = delete(this.deleteRequest, PAYMENT_SCHEME_VISA);
    }

    @Then("visa should successfully DELETE an active token")
    public void visaShouldSuccessfullyDELETEDASuspendedToken() {
        assertDeleteResponseSuccess(this.deleteResponseTuple._1, this.deleteResponseTuple._2);
    }

    @And("a successful tokenResponse from previous call and given a \"TransactRequest\" with a \"tokenReference\"")
    public void aSuccessfulTokenResponseFromPreviousCallAndGivenAWithA() {
        String tokenReference = this.tokenResponseTuple._2.getTokenReference();
        log.info("TokenReference for transact request : {}", tokenReference);

        // Given following transact request
        this.transactRequest = TransactRequest.builder()
                .tokenReference(tokenReference)
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .transactionData(TransactionData.builder()
                        .cryptogramType("VISA_TAVV")
                        .build())
                .build();
    }

    @When("a valid visa api request is sent to \"Transact\" API")
    public void aValidVisaApiRequestIsSentToAPI() {
        this.transactResponseTuple = transact(this.transactRequest, PAYMENT_SCHEME_VISA);
    }

    @Then("visa should successfully respond with transactResponse")
    public void visaShouldSuccessfullyRespondWithTransactResponse() {
        assertTokenTransactSuccess(this.transactResponseTuple._1, this.transactResponseTuple._2, PAYMENT_SCHEME_VISA);
    }

    public void cleanUpScenario() {

        if (this.tokenResponseTupleList != null && !this.tokenResponseTupleList.isEmpty()) {
            log.info("***************************************** Visa Token clean up Started *****************************************");
            log.info("Deleting multiple {} tokens...", this.tokenResponseTupleList.size());
            for (var tokenRespTuple : this.tokenResponseTupleList) {
                deleteAllCreatedTokens(tokenRespTuple._2.getTokenReference(), PAYMENT_SCHEME_VISA);
            }
            this.tokenResponseTupleList = null;
            log.info("***************************************** Visa Token clean up Ended *****************************************");
        }
        if (this.deleteResponseTuple == null && this.tokenResponseTuple != null) {
            log.info("***************************************** Visa Token clean up Started *****************************************");
            log.info("Deleting single token...");
            deleteAllCreatedTokens(this.tokenResponseTuple._2.getTokenReference(), PAYMENT_SCHEME_VISA);
            this.tokenResponseTuple = null;
            log.info("***************************************** Visa Token clean up Ended *****************************************");
        }

    }

    @And("a successful tokenResponse from previous call and given a valid visa \"TokenInfoRequest\" with received \"tokenReference\"")
    public void aSuccessfulTokenResponseFromPreviousCallAndGivenAValidVisaTokenInfoRequestWithReceivedTokenReference() {
        String tokenReference = this.tokenResponseTuple._2.getTokenReference();
        log.info("TokenReference for token-info request : {}", tokenReference);

        // Given following token-info request
        this.tokenInfoRequest = TokenInfoRequest.builder()
                .tokenReference(tokenReference)
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_VISA))
                .build();
    }

    @When("a valid visa api request is sent to \"Token-Info\" API")
    public void aValidVisaApiRequestIsSentToTokenInfoAPI() {
        this.tokenInfoResponseTuple = tokenInfo(this.tokenInfoRequest, PAYMENT_SCHEME_VISA);
    }

    @Then("visa should successfully respond with TOKEN INFO for an active token")
    public void visaShouldSuccessfullyRespondWithTOKENINFOForAnActiveToken() {
        assertTokenInfoResponseSuccess(this.tokenInfoResponseTuple._1, this.tokenInfoResponseTuple._2, PAYMENT_SCHEME_VISA);
    }

    @Then("visa TokenRequest should failed with Error response \"Validation error: riskData.locationLongitude & riskData.locationLatitude must match regular expression\"")
    public void visaAcceptanceTokenRequestFailedWithErrorResponseValidationErrorRiskDataLocationLatiRiskDataLongiMustMatchRegularExpression() {
        assertTokenRequestError(
                this.tokenResponseTuple._1,
                this.tokenResponseTuple._2,
                200,
                CoreStatusCodeEnum.BAD_REQUEST.name(),
                "Validation error:",
                "riskData.locationLatitude: must match \"^([-+]?\\d{1,2})([.]\\d{1,4}){0,1}$\"",
                "riskData.locationLongitude: must match \"^([-+]?\\d{1,3})([.]\\d{1,4}){0,1}$\""
        );
    }

    @When("{int} valid visa api re-provision requests are sent to \"Tokenize\" API for same the FPAN")
    public void request_countValidVisaApiReProvisionRequestsAreSentToAPIForSameTheFPAN(int requestCount) {
        this.tokenResponseTupleList = new HashSet<>();
        IntStream
                .range(0, requestCount)
                .forEach(i -> this.tokenResponseTupleList.add(tokenize(this.tokenRequest, PAYMENT_SCHEME_VISA)));
    }

    @Then("visa should successfully respond with tokenResponse for each FPAN re-provision request")
    public void visaShouldSuccessfullyRespondWithTokenResponseForEachFPANReProvisionRequest() {
        if (this.tokenResponseTupleList != null) {
            this.tokenResponseTupleList.forEach(tuple ->
                    assertTokenResponseSuccess(tuple._1, tuple._2, PAYMENT_SCHEME_VISA)
            );
        }
    }

    @When("two valid visa tokenRequests are sent to re-provision same PAN for different client wallet account, and account type of wallet.")
    public void twoValidVisaTokenRequestsAreSentToReProvisionSamePANForDifferentClientWalletAccountAndAccountTypeOfWallet() {
        this.tokenResponseTupleList = new HashSet<>();
        if (this.tokenRequestList != null) {
            this.tokenRequestList.forEach(tokenReq ->
                    this.tokenResponseTupleList.add(tokenize(tokenReq, PAYMENT_SCHEME_VISA))
            );
        }
    }

    @Then("visa should respond successfully with re-provisioning an already provision PAN")
    public void visaAcceptanceShouldRespondSuccessfullyWithReProvisioningAnAlreadyProvisionPAN() {
        if (this.tokenResponseTupleList != null) {
            this.tokenResponseTupleList.forEach(tuple ->
                    assertTokenResponseSuccess(tuple._1, tuple._2, PAYMENT_SCHEME_VISA)
            );
        }
    }

    @When("a more than {int} valid visa tokenRequests are sent for re-tokenization")
    public void aMoreThanValidVisaTokenRequestsAreSentForReTokenization(int requestCount) {
        this.tokenResponseTupleList = new HashSet<>();
        if (this.tokenRequestList != null) {
            this.tokenRequestList.forEach(tokenReq ->
                    this.tokenResponseTupleList.add(tokenize(tokenReq, PAYMENT_SCHEME_VISA))
            );
        }
    }

    @Then("visa should successfully respond with 100 tokenResponse")
    public void visaAcceptanceShouldSuccessfullyRespondWith100TokenResponse() {
        if (this.tokenResponseTupleList != null) {
            this.tokenResponseTupleList.forEach(tuple ->
                    assertTokenResponseSuccess(tuple._1, tuple._2, PAYMENT_SCHEME_VISA)
            );
        }
    }

    @SneakyThrows
    @Then("visa TokenRequest should failed with Error response \"tspMessage: Further operations are no longer allowed. Please contact bank to resolve the issue\"")
    public void visaTokenRequstShouldFailedWithErrorResponseWithAsFurtherOperationsAreNoLongerAllowedPleaseContactBankToResolveTheIssue() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_CARD_NOT_ELIGIBLE_TSP_CARD_NOT_ELIGIBLE),
                "tspMessage: Further operations are no longer allowed. Please contact your bank to resolve the issue."
        );
    }

    @SneakyThrows
    @Then("visa TokenRequest should failed with Error response \"tspMessage: Your request does not have valid set of parameters required to process the business function., location: encPaymentInstrument\"")
    public void visaTokenRequestShouldFailedWithErrorResponseWithTspMessageYourRequestDoesNotHaveValidSetOfParametersRequired() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_CARD_VERIFICATION_ERROR_TSP_INVALID_CARD_DATA),
                "tspMessage: Your request does not have valid set of parameters required to process the business function., location: encPaymentInstrument"
        );
    }

    @SneakyThrows
    // COF-Token-Requester-005 & COF-Token-Requester-007
    @Then("visa TokenRequest should failed with Error response \"tspMessage: Further operations for this card are no longer allowed. Contact the bank to resolve this issue\"")
    public void visaErrorResponseWithTspMessageFurtherOperationsForThisCardAreNoLongerAllowedContactTheBankToResolveThisIssue() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_CARD_VERIFICATION_ERROR_TSP_INVALID_CARD_DATA),
                "tspMessage: Further operations for this card are no longer allowed. Contact the bank to resolve this issue."
        );
    }

    @SneakyThrows
    // COF-Token-Requester-006
    @Then("visa TokenRequest should failed with Error response \"tspMessage: The requested action is not allowed for the given PAN\"")
    public void visaTokenRequestFailedWithErrorResponseWithTspMessageTheRequestedActionIsNotAllowedForTheGivenPAN() {
        assertTokenRequestError(
            tokenResponseTuple._1,
            tokenResponseTuple._2,
            200,
            TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_CARD_NOT_ALLOWED_TSP_INVALID_CARD_DATA),
            "tspMessage: The requested action is not allowed for the given PAN."
        );
    }

    @SneakyThrows
    @Then("visa TokenRequest should failed with Error response \"tspMessage: Further operations are no longer allowed. Please contact your bank to resolve the issue.\"")
    public void visaTokenRequestShouldFailedWithErrorResponseWithTspMessageFurtherOperationsAreNoLongerAllowedPleaseContactYourBankToResolveTheIssue() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_CARD_NOT_ELIGIBLE_TSP_CARD_NOT_ELIGIBLE),
                "tspMessage: Further operations are no longer allowed. Please contact your bank to resolve the issue."
        );
    }


    @SneakyThrows
    @Then("visa ResumeRequest should failed with Error response \"tspMessage: Requested action is not allowed for the given token.\"")
    public void visaAcceptanceResumeRequestErrorResponseWithTspMessageRequestedActionIsNotAllowedForTheGivenToken() {
        assertResumeResponseError(
                this.resumeResponseTuple._1,
                this.resumeResponseTuple._2,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_NOT_ALLOWED_TSP_OPERATION_NOT_ALLOWED),
                "tspMessage: Requested action is not allowed for the given token.");
    }

    @SneakyThrows
    @Then("visa TransactRequest should failed with Error response \"tspMessage: The token state does not allow the operation.\"")
    public void visaAcceptanceTransactRequestFailedWithErrorResponseTspMessageTheTokenStateDoesNotAllowTheOperation() {
        assertTokenTransactError(
                this.transactResponseTuple._1,
                this.transactResponseTuple._2,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_INVALID_PARAMETER_TSP_UNKNOWN_ERROR),
                "tspMessage: The token state does not allow the operation.");
    }

    @SneakyThrows
    @Then("visa TokenRequest should failed with Error vts invalid parameter \"tspMessage: The request is invalid. Following parameters may be invalid:<paymentInstrumentReference>, location: paymentInstrumentReference\"")
    public void visaTokenRequestShouldFailedWithErrorVtsInvalidParameterTspMessageEncryptorOfJWEIsNotAnIssuerLocationPanSource() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.SERVICE_ERROR_TSP_SERVICE_ERROR),
                "tspMessage: The request is invalid. Following parameters may be invalid:<paymentInstrumentReference>, location: paymentInstrumentReference"
        );
    }

    @SneakyThrows
    @Then("visa TokenRequest should failed with Error response \"tspMessage: Your request does not have valid set of parameters required to process the business function.\"")
    public void visaTokenRequestShouldFailedWithErrorResponseTspMessageYourRequestDoesNotHaveValidSetOfParametersRequiredToProcessTheBusinessFunction() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_INVALID_PARAMETER_TSP_UNKNOWN_ERROR),
                "tspMessage: Your request does not have valid set of parameters required to process the business function."
        );
    }

    @Then("visa TokenRequest should failed with Error response \"Validation error: FundingAccountDataPlain.expirationDate: must match regular expression\"")
    public void visaAcceptanceTokenRequestFailedWithErrorResponseValidationErrorFundingAccountDataPlainExpirationDateMustMatchD$() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                CoreStatusCodeEnum.BAD_REQUEST.name(),
                "Validation error: FundingAccountDataPlain.expirationDate: must match \"^2\\d{3}-(0[1-9]|1[012])$\""
        );
    }

    @SneakyThrows
    @Then("visa TokenRequest should failed with Error response \"tspMessage: Input for encPaymentInstrument.paymentInstrument.expirationDate.month is invalid or inconsistent with the profile., location: encPaymentInstrument.paymentInstrument.expirationDate.month\"")
    public void visaTokenRequestShouldFailedWithErrorResponseTspMsgInputForEncPaymentInstrumentExpDateMonthIsInvalidOrInconsistent() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_INVALID_PARAMETER_TSP_INVALID_CARD_DATA),
                "tspMessage: Input for encPaymentInstrument.paymentInstrument.expirationDate.month is invalid or inconsistent with the profile., location: encPaymentInstrument.paymentInstrument.expirationDate.month"
        );
    }

    @SneakyThrows
    @Then("Visa Acceptance: TokenizeRequest failed with VTS Declined Error response \"tspMessage: Further operations for this card are no longer allowed. Contact the issuer to resolve the issue.\"")
    public void visaAcceptanceTokenizeRequestFailedWithVTSDeclinedErrorResTspMessageFurtherOperationsForThisCardAreNoLongerAllowedContactTheIssuerToResolveTheIssue() {
        assertTokenRequestError(
                this.tokenResponseTuple2._1,
                this.tokenResponseTuple2._2,
                200,
                TspStatusCodeMapper.getErrorStatusCode(TspStatusCodeMapperEnum.VTS_DECLINED_TSP_ISSUER_DECLINED),
                "tspMessage: Further operations for this card are no longer allowed. Contact the issuer to resolve the issue."
        );
    }

    @Then("visa TokenRequest should failed with Error response \"MISSING REQUEST ID\"")
    public void visaAcceptanceTokenRequestFailedWithErrorResponseMISSINGREQUESTID() {
        assertTokenRequestError(
                this.tokenResponseTuple._1,
                this.tokenResponseTuple._2,
                200,
                CoreStatusCodeEnum.MISSING_REQUEST_ID.name(),
                new String[]{null}
        );
    }

    @And("the {int} seconds wait between Previous call and Transact call")
    public void theSecondsWaitBetweenSuspendAndTransactCall(int seconds) {
        log.info("Waiting for {} sec between calls...", seconds);
        Awaitility.await().pollDelay(seconds, TimeUnit.SECONDS).atMost(seconds + 5, TimeUnit.SECONDS).until(() -> true);
    }
}
