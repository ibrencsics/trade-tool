package com.gi_de.cpecom.tests.stepdefs.mastercard.tokenization;

import com.gi_de.cpecom.tests.model.common.CpecomStatusCodeEnum;
import com.gi_de.cpecom.tests.model.common.DataGenerator;
import com.gi_de.cpecom.tests.model.tokenization.FundingAccountData;
import com.gi_de.cpecom.tests.model.tokenization.TokenRequest;
import com.gi_de.cpecom.tests.model.tokenization.TokenResponse;
import com.gi_de.cpecom.tests.model.tokenization.UserData;
import com.gi_de.cpecom.tests.stepdefs.base.StepDefinitionBase;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.vavr.Tuple2;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class TokenizationSteps extends StepDefinitionBase {

    private Tuple2<Integer, TokenResponse> tokenResponseTuple;

    private TokenRequest tokenRequest;

    @SneakyThrows
    @BeforeAll
    public static void setUpBeforeAllSteps() {
        log.info("Test Start");
    }

    @Given("a valid mastercard tokenRequest with values {string}, {string}, {string}, {string} and {string}")
    public void aValidMasterCardTokenRequestWithValuesAndFor(String cardNumber, String expiryDateStr, String cvvStr, String fadPanSource, String consumerEntryModeStr) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr);

        tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .paymentScheme(PAYMENT_SCHEME_MASTERCARD)
                .userData(UserData.builder().accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID).build())
                .fundingAccountData(fundingAccountData)
                .riskData(null)
                .build();
    }

    @SneakyThrows
    @When("a mastercard tokenization api request is sent to \"Tokenize\" API")
    public void aMastercardTokenizationApiRequestIsSentToTokenizeAPI() {
        this.tokenResponseTuple = this.tokenize(tokenRequest, PAYMENT_SCHEME_MASTERCARD);
    }

    @Then("mastercard should respond with active token")
    public void mastercardShouldRespondWithActiveToken() {
        assertTokenResponseSuccess(this.tokenResponseTuple._1, this.tokenResponseTuple._2, PAYMENT_SCHEME_MASTERCARD);
    }

    public void cleanUpScenario() {
        log.info("Scenario clean up started.");
        if (this.tokenResponseTuple != null) {
            deleteAllCreatedTokens(this.tokenResponseTuple._2.getTokenReference(), PAYMENT_SCHEME_MASTERCARD);
        }
        log.info("Scenario clean up finished.");
    }

    @AfterAll
    public static void setUpAfterAllSteps() {
        log.info("Test Finished");
    }

    @Given("a valid mastercard tokenRequest with values {string}, {string}, {string}, {string} and {string} and User Data email id")
    public void aValidMastercardTokenRequestWithValuesAndAndUserDataEmailId(String cardNumber, String expiryDateStr, String cvvStr, String fadPanSource, String consumerEntryModeStr, DataTable dataTable) {
        final FundingAccountData fundingAccountData = DataGenerator.getFundingAccountData(cardNumber, expiryDateStr, cvvStr, fadPanSource, consumerEntryModeStr);
        tokenRequest = TokenRequest.builder()
                .gdPaymentAppId(getGdPaymentAppId(PAYMENT_SCHEME_MASTERCARD))
                .paymentScheme(PAYMENT_SCHEME_MASTERCARD)
                .userData(UserData.builder()
                        .accountId(DataGenerator.CPECOM_TEST_AUTOMATION_USER_DATA_ACCOUNT_ID)
                        .email(dataTable.asList().get(1))
                        .build())
                .fundingAccountData(fundingAccountData)
                .riskData(null)
                .build();
    }


    @Then("TokenRequest failed with Error message 'Validation error: userData.email: size must be between 0 and 255'")
    public void shouldRespondWithFailureResponseAsInvalidStateAndMessageAsIncorrectFieldValueAndDetailsAsValidationErrorUserDataEmail() {
        assertTokenRequestError(
                tokenResponseTuple._1,
                tokenResponseTuple._2,
                200,
                CpecomStatusCodeEnum.BAD_REQUEST.name(),
                "Validation error: userData.email: size must be between 0 and 255"
        );
    }
}
