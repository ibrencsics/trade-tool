package com.gi_de.cpecom.tests.config;

import com.gi_de.cpecom.tests.common.exceptions.ConfigPropertiesNotFoundException;
import com.gi_de.cpecom.tests.common.exceptions.CusterIdNotFoundException;
import com.gi_de.cpecom.tests.common.exceptions.SslCertificateNotFoundException;
import io.cucumber.plugin.ConcurrentEventListener;
import io.cucumber.plugin.event.EventHandler;
import io.cucumber.plugin.event.EventPublisher;
import io.cucumber.plugin.event.TestRunFinished;
import io.cucumber.plugin.event.TestRunStarted;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import lombok.extern.log4j.Log4j2;

import java.io.InputStream;
import java.security.KeyStore;
import java.util.Properties;

@Log4j2
public class CucumberHooks implements ConcurrentEventListener {

    @Override
    public void setEventPublisher(EventPublisher eventPublisher) {
        eventPublisher.registerHandlerFor(TestRunStarted.class, beforeAll);
        eventPublisher.registerHandlerFor(TestRunFinished.class, afterAll);
    }

    private final EventHandler<TestRunStarted> beforeAll = event -> {
        log.info("BeforeAll Start");
        try {

            // create baseUrl from environment
            Properties properties = ConfigPropertiesLoader.getInstance();
            RestAssured.baseURI = properties.getProperty("base-url");
            RestAssured.basePath = properties.getProperty("app-context") + properties.get("api-version");

            if (Boolean.parseBoolean(SystemEnvironments.getIsLocalRunSystemEnv())) {
                RestAssured.proxy("cws.accounts.intern", 8081);
            }
            log.info("Connecting to '{}' Environment", SystemEnvironments.getSystemTargetEnv());
            log.info("Connecting to '{}' CPECOM Server", RestAssured.baseURI);
            KeyStore keyStore = KeyStore.getInstance("PKCS12");

            final String sslCertificateFilePath = SystemEnvironments.getCustomerSslCertificatePath(properties);
            InputStream is = CucumberHooks.class.getResourceAsStream(sslCertificateFilePath);
            keyStore.load(is, "mypassword".toCharArray());
            org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "mypassword");
            // set the config in rest assured
            SSLConfig config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
            RestAssured.config = RestAssured.config().sslConfig(config);
            RestAssured.defaultParser = Parser.JSON;

            // Default headers setting
            RestAssured.given().headers("Content-type", "application/json");
            RestAssured.given().headers("Accept", "application/json");
            RestAssured.given().contentType(ContentType.JSON);

            log.debug("API base URI {}", RestAssured.baseURI);
            log.debug("API base URI {}", RestAssured.basePath);
            log.info("BeforeAll Finished");

        } catch (CusterIdNotFoundException ex) {
            log.error("CusterIdNotFoundException: {}", ex.getMessage());
        } catch (ConfigPropertiesNotFoundException ex) {
            log.error("ConfigPropertiesNotFoundException: {}", ex.getMessage());
        } catch (SslCertificateNotFoundException ex) {
            log.error("SslCertificateNotFoundException: {}", ex.getMessage());
        } catch (Exception ex) {
            log.error("Exception during ssl handshake with server {}", ex.getMessage());
        }
    };



    private final EventHandler<TestRunFinished> afterAll = event -> log.info("AfterAll End");
}


