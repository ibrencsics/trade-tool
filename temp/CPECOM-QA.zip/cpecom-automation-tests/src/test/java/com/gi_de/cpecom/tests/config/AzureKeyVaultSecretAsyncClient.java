package com.gi_de.cpecom.tests.config;

import com.azure.identity.EnvironmentCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretAsyncClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;

import java.util.concurrent.atomic.AtomicReference;

public class AzureKeyVaultSecretAsyncClient {

    private static final AtomicReference<SecretAsyncClient> INSTANCE = new AtomicReference<>();

    private AzureKeyVaultSecretAsyncClient() {
    }

    public static SecretAsyncClient getInstance() {
        if (INSTANCE.get() == null) {
            SecretAsyncClient newInstance = new SecretClientBuilder()
                    .vaultUrl("https://kv-qa-cpecom-dev.vault.azure.net/")
                    .credential(new EnvironmentCredentialBuilder().build())
                    .buildAsyncClient();
            if (INSTANCE.compareAndSet(null, newInstance)) {
                return newInstance;
            }
        }
        return INSTANCE.get();
    }
}
