package com.gi_de.cpecom.tests.model.resume;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class ResumeRequest {

    private String tokenReference;

    private String gdPaymentAppId;

    private String reasonCode;

    private String reasonDescription;
}
