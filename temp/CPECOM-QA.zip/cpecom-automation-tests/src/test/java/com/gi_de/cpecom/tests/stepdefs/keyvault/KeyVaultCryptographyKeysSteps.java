package com.gi_de.cpecom.tests.stepdefs.keyvault;

import com.azure.core.exception.HttpResponseException;
import com.azure.core.exception.ResourceNotFoundException;
import com.azure.core.util.polling.AsyncPollResponse;
import com.azure.security.keyvault.keys.cryptography.CryptographyAsyncClient;
import com.azure.security.keyvault.keys.cryptography.models.DecryptResult;
import com.azure.security.keyvault.keys.cryptography.models.EncryptionAlgorithm;
import com.azure.security.keyvault.secrets.SecretAsyncClient;
import com.azure.security.keyvault.secrets.models.DeletedSecret;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.gi_de.cpecom.tests.config.AzureKeyVaultCryptoAsyncClient;
import com.gi_de.cpecom.tests.config.AzureKeyVaultSecretAsyncClient;
import com.gi_de.cpecom.tests.model.keyvault.KeyProperties;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.OctetSequenceKey;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Assertions;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.*;

@Log4j2
public class KeyVaultCryptographyKeysSteps {

    public static final String KEY_TYPE_JWE_OVER_JWK = "JWE_OVER_JWK";
    public static final String KEY_TYPE_JWK = "JWK";
    private CryptographyAsyncClient cryptographyAsyncClient = null;
    private SecretAsyncClient secretAsyncClient = null;

    private KeyVaultSecret keyVaultSecretResponse;

    private KeyVaultSecret keyVaultSecretRequest;

    private KeyProperties keyProperties;

    private String decryptedJwkKey;

    @SneakyThrows
    @Before("@KEY-VAULT-TESTS")
    public void initializationBeforeSteps() {
        log.info("------------------------ Key Vault Crypto Client Initialization Starting ------------------------");
        this.cryptographyAsyncClient = AzureKeyVaultCryptoAsyncClient.getInstance();
        this.secretAsyncClient = AzureKeyVaultSecretAsyncClient.getInstance();
        log.info("CryptographyAsyncClient Object : {}", this.cryptographyAsyncClient);
        log.info("------------------------ Key Vault Crypto Client Initialization Finished ------------------------");
    }

    @Given("a random jwk key with values {string}, {string}, {string} which need to encrypt and upload to azure key vault secret")
    public void aRandomJwkKeyWithValuesWhichNeedToEncryptAndUploadToAzureKeyVaultSecret(String keyLabel, String isSensitive, String canOverwrite) {
        this.keyProperties = KeyProperties.builder()
                .jwk(generateJwkKey())
                .keyLabel(keyLabel)
                .isSensitive(Boolean.parseBoolean(isSensitive))
                .isOverwrite(Boolean.parseBoolean(canOverwrite))
                .build();
    }

    @When("request is send to encrypt a data and then upload it to azure key vault")
    public void requestIsSendToEncryptADataAndThenUploadItToAzureKeyVault() {
        log.info("------------------------------ processing Start ----------------------------------");
        this.keyVaultSecretResponse = encryptAndUploadKeyToAzureKeyVault(this.keyProperties.getKeyLabel(), this.keyProperties.getJwk(), this.keyProperties.isSensitive(), this.keyProperties.isOverwrite());
        log.info("--------------------- Key Value : {}", this.keyVaultSecretResponse.getValue());
        log.info("------------------------------ processing End ----------------------------------");
    }

    public KeyVaultSecret encryptAndUploadKeyToAzureKeyVault(final String label, final JWK jwkKey, final boolean isSensitive, final boolean canOverwrite) {
        return throwIfKeyExists(label, canOverwrite)
                .then(Mono.just(getJwkString(jwkKey)))
                .flatMap(jwkStr -> createKeyVaultJwkSecret(label, jwkStr, isSensitive))
                .flatMap(this.secretAsyncClient::setSecret)
                .block();
    }

    private Mono<Void> throwIfKeyExists(final String label, final boolean canOverwrite) {
        return this.secretAsyncClient.getSecret(label)
                .flatMap(existingKey -> {
                    if (canOverwrite) {
                        return Mono.just("Overwriting ignore it");
                    } else {
                        return Mono.error(new Exception("Key Already exist"));
                    }
                })
                .switchIfEmpty(Mono.just("ignore"))
                .onErrorResume(ResourceNotFoundException.class, ex -> Mono.just("ignore - key not found"))
                .then();
    }

    Mono<KeyVaultSecret> createKeyVaultJwkSecret(final String label, final String value, final boolean isSensitive) {
        return
                Mono.zip(
                                isSensitive ? jwkEncrypt(value) : Mono.just(toImportFormat(value)),
                                Mono.fromCallable(() -> JWK.parse(value)).map(this::getExpiration),
                                Mono.fromCallable(() -> JWK.parse(value)).map(this::getNotBefore)
                        )
                        .map(data -> {
                            log.info("Encrypted Value : {}", data.getT1());
                            log.info("Expiry Date : {}", data.getT2());
                            log.info("Not Before Date : {}", data.getT3());
                            final KeyVaultSecret keyVaultSecret = new KeyVaultSecret(label, data.getT1());
                            keyVaultSecret.getProperties().setContentType(isSensitive ? KEY_TYPE_JWE_OVER_JWK : KEY_TYPE_JWK);
                            data.getT2().ifPresent(exp ->
                                    keyVaultSecret.getProperties().setExpiresOn(exp.toInstant().atOffset(ZoneOffset.UTC)));
                            data.getT3().ifPresent(before ->
                                    keyVaultSecret.getProperties().setNotBefore(before.toInstant().atOffset(ZoneOffset.UTC)));
                            this.keyVaultSecretRequest = keyVaultSecret;
                            return keyVaultSecret;
                        });
    }

    private Mono<String> jwkEncrypt(String originalData) {
        log.info("Original Data (Jwk Key) : {}", originalData);
        return this.cryptographyAsyncClient.encrypt(EncryptionAlgorithm.RSA_OAEP_256, originalData.getBytes(StandardCharsets.UTF_8))
                .onErrorMap(ResourceNotFoundException.class, ex -> new Exception("Exception: Resource not found while encrypt"))
                .onErrorMap(UnsupportedOperationException.class, ex -> new Exception("Exception: Unsupported Operation exception while ecrypt"))
                .map(encryptResult -> {
                    log.info("Cipher Text : {}", encryptResult.getCipherText());
                    return bytesToBase64(encryptResult.getCipherText());
                });
    }

    private String getSecretAndDecryptJwkKey(String label){
        return this.secretAsyncClient.getSecret(label)
                .doOnError(ResourceNotFoundException.class, ex -> log.error("ResourceNotFoundException Occurred", ex))
                .doOnError(HttpResponseException.class, ex -> log.error("HttpResponseException Occurred", ex))
                .onErrorComplete()
                .map(KeyVaultSecret::getValue)
                .map(KeyVaultCryptographyKeysSteps::base64ToBytes)
                .flatMap(this::jwkDecrypt)
                .block();
    }

    private Mono<String> jwkDecrypt(byte[] cipherText) {
        log.info("Cipher Text (Jwk Key) : {}", cipherText);
        return this.cryptographyAsyncClient.decrypt(EncryptionAlgorithm.RSA_OAEP_256, cipherText)
                .onErrorMap(ResourceNotFoundException.class, ex -> new Exception("Exception: Resource not found while decrypt"))
                .onErrorMap(UnsupportedOperationException.class, ex -> new Exception("Exception: Unsupported Operation exception while decrypt"))
                .map(DecryptResult::getPlainText)
                .map(plainText -> new String(plainText, StandardCharsets.UTF_8));
    }

    private Optional<Date> getExpiration(final JWK jwk) {
        final List<X509Certificate> certs = jwk.getParsedX509CertChain();
        if (certs != null && !certs.isEmpty()) {
            return certs.stream()
                    .map(X509Certificate::getNotAfter)
                    .min(Date::compareTo);
        } else {
            return Optional.ofNullable(jwk.getExpirationTime());
        }
    }

    private Optional<Date> getNotBefore(final JWK jwk) {
        final List<X509Certificate> certs = jwk.getParsedX509CertChain();
        if (certs != null && !certs.isEmpty()) {
            return certs.stream()
                    .map(X509Certificate::getNotBefore)
                    .min(Date::compareTo);
        } else {
            return Optional.ofNullable(jwk.getNotBeforeTime());
        }
    }

    @Then("azure key vault should store the in-sensitive key and successfully return the stored data")
    public void azureKeyVaultShouldStoreTheInSensitiveKeyAndSuccessfullyReturnTheStoredData() {
        assertKeyVaultResponse();
    }

    private void assertKeyVaultResponse(){
        Assertions.assertNotNull(this.keyVaultSecretResponse);
        Assertions.assertNotNull(this.keyVaultSecretResponse.getName());
        Assertions.assertNotNull(this.keyProperties.getKeyLabel(), this.keyVaultSecretResponse.getName());
        Assertions.assertNotNull(this.keyVaultSecretResponse.getId());
        Assertions.assertNotNull(this.keyVaultSecretResponse.getProperties());
        Assertions.assertNotNull(this.keyVaultSecretResponse.getProperties().getNotBefore());
        Assertions.assertNotNull(this.keyVaultSecretResponse.getProperties().getExpiresOn());
        Assertions.assertNotNull(this.keyVaultSecretResponse.getProperties().getContentType());
        Assertions.assertEquals(this.keyVaultSecretRequest.getProperties().getContentType(), this.keyVaultSecretResponse.getProperties().getContentType());
        Assertions.assertNotNull(this.keyVaultSecretResponse.getProperties().getExpiresOn());
        Assertions.assertEquals(this.keyVaultSecretRequest.getProperties().getExpiresOn().toEpochSecond(), this.keyVaultSecretResponse.getProperties().getExpiresOn().toEpochSecond());
        Assertions.assertNotNull(this.keyVaultSecretResponse.getProperties().getNotBefore());
        Assertions.assertEquals(this.keyVaultSecretRequest.getProperties().getNotBefore().toEpochSecond(), this.keyVaultSecretResponse.getProperties().getNotBefore().toEpochSecond());

    }

    private byte[] generateSymmetricKey() {
        byte[] keyBytes = new byte[32];
        new java.security.SecureRandom().nextBytes(keyBytes);
        return keyBytes;
    }

    private JWK generateJwkKey() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime sameDayNextYear = now.plusYears(1);
        Date currentDateTime = Date.from(now.atZone(ZoneId.systemDefault()).toInstant());
        Date expirationTime = Date.from(sameDayNextYear.atZone(ZoneId.systemDefault()).toInstant());
        return new OctetSequenceKey
                .Builder(generateSymmetricKey())
                .keyID(UUID.randomUUID().toString())
                .expirationTime(expirationTime)
                .notBeforeTime(currentDateTime)
                .build();
    }

    private String getJwkString(JWK jwk) {
        return jwk.toJSONString();
    }

    private static String toImportFormat(final String jwkJsonString) {
        return Base64.getEncoder().encodeToString(jwkJsonString.getBytes(StandardCharsets.UTF_8));
    }

    public static String bytesToBase64(final byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    public static byte[] base64ToBytes(final String base64) {
        return Base64.getUrlDecoder().decode(base64);
    }

    @And("finally delete and purge the cryptography secret with name {string} from key vault")
    public void finallyDeleteAndPurgeTheCryptographySecretWithNameFromKeyVault(String secretName) {
        AsyncPollResponse<DeletedSecret, Void> deleteResponse = this.secretAsyncClient.beginDeleteSecret(secretName).blockLast();
        assertDeleteSecret(secretName, deleteResponse);
    }

    private void assertDeleteSecret(String secretName, AsyncPollResponse<DeletedSecret, Void> deleteResponse) {
        log.info("------------------------ Key Vault Delete Started ------------------------");
        Assertions.assertNotNull(deleteResponse);
        Assertions.assertNotNull(deleteResponse.getValue());
        Assertions.assertNotNull(deleteResponse.getValue().getName());
        Assertions.assertNotNull(deleteResponse.getStatus());
        Assertions.assertEquals(secretName, deleteResponse.getValue().getName());
        Assertions.assertTrue(deleteResponse.getStatus().isComplete());
        log.info("Deleted Secret Name: " + deleteResponse.getValue().getName());
        log.info("Delete Status: " + deleteResponse.getStatus());
        log.info("Is Key Secret Deleted: {}", deleteResponse.getStatus().isComplete());
        this.secretAsyncClient.purgeDeletedSecret(secretName)
                .doOnSuccess(purgeResponse ->
                        log.info("Successfully Purged current Secret - '{}'", secretName))
                .block();
        log.info("------------------------ Key Vault Delete Finished ------------------------");
    }

    @When("request is send to encrypt a Jwk key and then decrypt a key to receive original jwk key")
    public void requestIsSendToEncryptAJwkKeyAndThenDecryptAKeyToReceiveOriginalJwkKey() {

        log.info("------------------------------ Key Encryption and upload Start ----------------------------------");
        this.keyVaultSecretResponse = encryptAndUploadKeyToAzureKeyVault(this.keyProperties.getKeyLabel(), this.keyProperties.getJwk(), this.keyProperties.isSensitive(), this.keyProperties.isOverwrite());
        log.info("--------------------- Key Value : {}", this.keyVaultSecretResponse.getValue());
        log.info("------------------------------ Key Encryption and upload Finished ----------------------------------");

        log.info("------------------------------ Key Decryption and upload Start ----------------------------------");
        this.decryptedJwkKey = getSecretAndDecryptJwkKey(this.keyProperties.getKeyLabel());
        log.info("Original JWK key : {}", this.keyProperties.getJwk());
        log.info("Decrypted JWK key : {}", this.decryptedJwkKey);
        log.info("------------------------------ Key Decryption and upload Finished ----------------------------------");
    }

    @Then("it should successfully encrypt the key and upload it to azure key vault secret")
    public void itShouldSuccessfullyEncryptTheKeyAndUploadItToAzureKeyVaultSecret() {
        assertKeyVaultResponse();
    }

    @Then("it should successfully decrypt the encrypted key from azure key vault secret")
    public void itShouldSuccessfullyDecryptTheEncryptedKeyFromAzureKeyVaultSecret() {
        assertKeyVaultResponse();
        Assertions.assertEquals(getJwkString(this.keyProperties.getJwk()), this.decryptedJwkKey);
    }
}
