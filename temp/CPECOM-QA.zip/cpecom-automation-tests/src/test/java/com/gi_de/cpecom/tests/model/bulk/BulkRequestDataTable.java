package com.gi_de.cpecom.tests.model.bulk;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BulkRequestDataTable {

    private String rowId;

    private String cardNumber;

    private String expiryDate;

    private String cvvStr;

    private String accountId;

    private String email;

    private String firstName;

    private String lastName;

    private String phoneCountry;

    private String phoneNumber;

    private String consumerCountry;

    private String consumerLanguage;

    private String ip4address;

    private String locationLatitude;

    private String locationLongitude;

    private String accountScore;

    private String deviceScore;
}
