package com.gi_de.cpecom.tests.model.bulk;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.gi_de.cpecom.tests.model.tokenization.RiskData;
import com.gi_de.cpecom.tests.model.tokenization.UserData;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class FundingAccountBulk {

    private String rowId;

    private String encFundingAccountData;

    private UserData userData;

    private RiskData riskData;
}
