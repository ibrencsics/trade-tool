package com.gi_de.cpecom.tests.stepdefs.keyvault;

import com.azure.core.util.polling.AsyncPollResponse;
import com.azure.security.keyvault.secrets.SecretAsyncClient;
import com.azure.security.keyvault.secrets.models.DeletedSecret;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.azure.security.keyvault.secrets.models.SecretProperties;
import com.gi_de.cpecom.tests.common.CucumberTestUtils;
import com.gi_de.cpecom.tests.config.AzureKeyVaultSecretAsyncClient;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Assertions;
import org.junit.platform.commons.util.StringUtils;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.util.Map;

@Log4j2
public class KeyVaultSecretSteps {

    private KeyVaultSecret keyVaultSecret;

    private SecretAsyncClient secretAsyncClient;

    private KeyVaultSecret createdKeyVaultSecret;

    private SecretProperties updatedSecretProperties;

    private Mono<SecretProperties> secretPropertiesMono;

    private AsyncPollResponse<DeletedSecret, Void> deletedSecretResponse;

    @SneakyThrows
    @Before("@KEY-VAULT-TESTS")
    public void initializationBeforeSteps() {
        log.info("------------------------ Key Vault Secret Client Initialization Starting ------------------------");
        this.secretAsyncClient = AzureKeyVaultSecretAsyncClient.getInstance();
        log.info("*************** this.secretAsyncClient : {}", this.secretAsyncClient);
        log.info("------------------------ Key Vault Secret Client Initialization Finished ------------------------");
    }

    private void clearExistingSecretFromKeyVault(String secretName) {
        // clear exising secret before processing...
        deleteSecretFromKeyVault(secretName);
    }

    private void deleteSecretFromKeyVault(String secretName) {
        this.secretAsyncClient.getSecret(secretName)
                .publishOn(Schedulers.boundedElastic())
                .doOnError(ex -> {
                    log.info("Secret is NOT Exist or thrown some exception...");
                    log.info("Secret '{}' is not exist in KeyVault so skipping delete processing...", secretName);
                    log.info("Checking if this secret is soft deleted....");
                    deleteDeletedSecretFromKeyVault(secretName);
                })
                .onErrorComplete()
                .doOnNext(deletedSecretResponse -> {
                    log.info("------------------------- Delete ACTIVE secret START ----------------------");
                    AsyncPollResponse<DeletedSecret, Void> deleteResponse = this.secretAsyncClient.beginDeleteSecret(secretName).blockLast(Duration.ofSeconds(10));
                    if (deleteResponse != null) {
                        log.info("Delete Status: " + deleteResponse.getStatus().toString());
                        log.info("Deleted Secret Name: " + deleteResponse.getValue().getName());
                        this.secretAsyncClient.purgeDeletedSecret(secretName)
                                .doOnSuccess(purgeResponse ->
                                        log.info("Successfully Purged current Secret - '{}'", secretName))
                                .block(Duration.ofSeconds(10));
                    }
                    log.info("------------------------- Delete ACTIVE secret START ----------------------");

                })
                .block(Duration.ofSeconds(10));
    }

    private void deleteDeletedSecretFromKeyVault(String secretName) {
        log.info("------------------------- Delete DELETED secret START ----------------------");
        this.secretAsyncClient.getDeletedSecret(secretName)
                .publishOn(Schedulers.boundedElastic())
                .doOnError(err -> log.info("Secret '{}' is NOT exist in Soft-Delete state so skipping purge processing...", secretName))
                .onErrorComplete()
                .doOnNext(alreadyDeletedSecret -> {
                    log.info("Successfully Purged already deleted Secret - '{}'", secretName);
                    this.secretAsyncClient.purgeDeletedSecret(alreadyDeletedSecret.getName()).block(Duration.ofSeconds(10));
                })
                .block(Duration.ofSeconds(10));
        log.info("------------------------- Delete DELETED secret Finished ----------------------");
    }

    @Given("a new {string}, {string} pair with secret properties like {string}, {string}, {string}, {string}, {string}")
    public void givenANewSecretNameAndValuePairWithSecretProperties(String secretName, String secretValue, String isEnabled, String contentType, String expireOn, String notBefore, String tags) {
        // Clear existing secret from key vault if any otherwise testcase may fail
        clearExistingSecretFromKeyVault(secretName);
        //Create secret
        createKeyVaultSecret(secretName, secretValue, isEnabled, contentType, expireOn, notBefore, tags);
    }

    private void createKeyVaultSecret(String secretName, String secretValue, String isEnabled, String contentType, String expireOn, String notBefore, String tags) {
        final String[] tagsArray = StringUtils.isNotBlank(tags) ? tags.split("-") : null;

        SecretProperties secretProperties = new SecretProperties();
        secretProperties.setEnabled(Boolean.valueOf(isEnabled));
        secretProperties.setContentType(formatContentType(contentType));
        secretProperties.setExpiresOn(CucumberTestUtils.convertStringToOffsetDateTime(expireOn));
        secretProperties.setNotBefore(CucumberTestUtils.convertStringToOffsetDateTime(notBefore));
        if (tagsArray != null) {
            secretProperties.setTags(Map.of(tagsArray[0], tagsArray[1]));
        }

        this.keyVaultSecret = new KeyVaultSecret(secretName, secretValue);
        this.keyVaultSecret.setProperties(secretProperties);
    }

    private String formatContentType(String contentType) {
        if ("NULL".equalsIgnoreCase(contentType)) {
            return null;
        }
        if ("[blank]".equalsIgnoreCase(contentType)) {
            return "";
        } else {
            return contentType;
        }
    }

    @Given("an existing {string}, {string} and updating the secret properties to {string}, {string}, {string}, {string}, {string}")
    public void anExistingAndUpdatingTheSecretPropertiesTo(String secretName, String secretValue, String isEnabled, String contentType, String expireOn, String notBefore, String tags, DataTable dataTable) {
        // Clear existing secret from key vault if any otherwise testcase may fail
        clearExistingSecretFromKeyVault(secretName);
        // Create a secret
        createKeyVaultSecret(secretName, secretValue, isEnabled, contentType, expireOn, notBefore, tags);
        // Update secret
        this.updatedSecretProperties = new SecretProperties();
        this.updatedSecretProperties.setEnabled(Boolean.parseBoolean(dataTable.cell(1, 0)));
        this.updatedSecretProperties.setContentType(formatContentType(dataTable.cell(1, 1)));
        this.updatedSecretProperties.setExpiresOn(CucumberTestUtils.convertStringToOffsetDateTime(dataTable.cell(1, 2)));
        this.updatedSecretProperties.setNotBefore(CucumberTestUtils.convertStringToOffsetDateTime(dataTable.cell(1, 3)));
        final String updateTags = dataTable.cell(1, 4);
        if (StringUtils.isNotBlank(updateTags)) {
            final String[] updatedTagsArray = updateTags.split("-");
            this.updatedSecretProperties.setTags(Map.of(updatedTagsArray[0], updatedTagsArray[1]));
        }
    }

    @When("a request is send to Azure Key Vault to CREATE a secret")
    public void whenARequestIsSendToAzureKeyVaultToCreateASecret() {
        this.createdKeyVaultSecret = this.secretAsyncClient
                .setSecret(keyVaultSecret).block();
    }

    @Then("it should successfully create a secret with secret properties")
    public void itShouldSuccessfullyCreateASecretWithSecretProperties() {
        assertCreateSecretSuccessful();
    }

    private void assertCreateSecretSuccessful() {
        log.info("---------------------------------- KeyVault Assertions start --------------------------------------");
        Assertions.assertNotNull(this.createdKeyVaultSecret);
        Assertions.assertEquals(this.keyVaultSecret.getName(), this.createdKeyVaultSecret.getName());
        Assertions.assertEquals(this.keyVaultSecret.getValue(), this.createdKeyVaultSecret.getValue());
        Assertions.assertNotNull(this.keyVaultSecret.getProperties());
        Assertions.assertEquals(this.keyVaultSecret.getProperties().getContentType(), this.createdKeyVaultSecret.getProperties().getContentType());
        Assertions.assertEquals(this.keyVaultSecret.getProperties().isEnabled(), this.createdKeyVaultSecret.getProperties().isEnabled());
        Assertions.assertEquals(this.keyVaultSecret.getProperties().getExpiresOn().toEpochSecond(), this.createdKeyVaultSecret.getProperties().getExpiresOn().toEpochSecond());
        Assertions.assertEquals(this.keyVaultSecret.getProperties().getNotBefore().toEpochSecond(), this.createdKeyVaultSecret.getProperties().getNotBefore().toEpochSecond());
        if (this.createdKeyVaultSecret.getProperties().getTags() != null && this.keyVaultSecret.getProperties().getTags() != null) {
            Assertions.assertTrue(this.createdKeyVaultSecret.getProperties().getTags().containsKey(this.keyVaultSecret.getProperties().getTags().keySet().stream().findFirst().orElse("")));
        }
        log.info("---------------------------------- KeyVault Assertions finished --------------------------------------");
    }

    @When("a request is send to Azure Key Vault to UPDATE a secret")
    public void aRequestIsSendToAzureKeyVaultToUpdateASecret() {
        // Create a new secret
        this.createdKeyVaultSecret = this.secretAsyncClient
                .setSecret(this.keyVaultSecret).block();

        // Update a existing secret
        KeyVaultSecret keyVaultSecretResponse = this.secretAsyncClient.getSecret(this.keyVaultSecret.getName()).block();
        if (keyVaultSecretResponse != null) {
            SecretProperties secretProperties = keyVaultSecretResponse.getProperties();
            secretProperties.setContentType(this.updatedSecretProperties.getContentType());
            secretProperties.setExpiresOn(this.updatedSecretProperties.getExpiresOn());
            secretProperties.setEnabled(this.updatedSecretProperties.isEnabled());
            secretProperties.setNotBefore(this.updatedSecretProperties.getNotBefore());
            secretProperties.setTags(this.updatedSecretProperties.getTags());

            this.secretPropertiesMono = this.secretAsyncClient.updateSecretProperties(secretProperties);
        }
    }

    @Then("it should successfully update a secret with secret properties")
    public void itShouldSuccessfullyUpdateASecretWithSecretProperties() {

        // Create Asserts
        assertCreateSecretSuccessful();

        log.info("------------------------ Key Vault Update Started ------------------------");
        Assertions.assertNotNull(this.secretPropertiesMono);

        SecretProperties secretResponse = this.secretPropertiesMono.block();
        Assertions.assertNotNull(secretResponse);
        Assertions.assertNotNull(this.updatedSecretProperties);
        Assertions.assertEquals(this.updatedSecretProperties.getContentType(), secretResponse.getContentType());
        Assertions.assertEquals(this.updatedSecretProperties.isEnabled(), secretResponse.isEnabled());
        Assertions.assertEquals(this.updatedSecretProperties.getExpiresOn().toEpochSecond(), secretResponse.getExpiresOn().toEpochSecond());
        Assertions.assertEquals(this.updatedSecretProperties.getNotBefore().toEpochSecond(), secretResponse.getNotBefore().toEpochSecond());
        if (secretResponse.getTags() != null && this.updatedSecretProperties.getTags() != null){
            Assertions.assertTrue(secretResponse.getTags().containsKey(this.updatedSecretProperties.getTags().keySet().stream().findFirst().orElse("")));
        }

        log.info("------------------------ Key Vault Update Finished ------------------------");
    }

    @Given("an existing {string}, {string} which need to be delete from key vault pair with secret properties {string}, {string}, {string}, {string}, {string}")
    public void anExistingWhichNeedToDeleteFromKeyVault(String secretName, String secretValue, String isEnabled, String contentType, String expireOn, String notBefore, String tags) {
        // Clear existing secret from key vault if any otherwise testcase may fail
        clearExistingSecretFromKeyVault(secretName);
        // Given for create secret
        createKeyVaultSecret(secretName, secretValue, isEnabled, contentType, expireOn, notBefore, tags);
    }

    @When("a request is send to Azure Key Vault to DELETE a secret with name {string}")
    public void aRequestIsSendToAzureKeyVaultToDELETEASecret(String secretName) {
        // Create a new secret
        this.createdKeyVaultSecret = this.secretAsyncClient
                .setSecret(keyVaultSecret).block();
        // Delete existing secret
        this.deletedSecretResponse = this.secretAsyncClient.beginDeleteSecret(secretName).blockLast();
    }

    @Then("it should successfully DELETE secret with {string} including it's all versions")
    public void itShouldSuccessfullyDELETESecretIncludingAllVersions(String secretName) {
        // Create Asserts
        assertCreateSecretSuccessful();
        // Delete Asserts
        assertDeleteSecret(secretName, this.deletedSecretResponse);
    }

    private void assertDeleteSecret(String secretName, AsyncPollResponse<DeletedSecret, Void> deleteResponse) {
        log.info("------------------------ Key Vault Delete Started ------------------------");
        Assertions.assertNotNull(deleteResponse);
        Assertions.assertNotNull(deleteResponse.getValue());
        Assertions.assertNotNull(deleteResponse.getValue().getName());
        Assertions.assertNotNull(deleteResponse.getStatus());
        Assertions.assertEquals(secretName, deleteResponse.getValue().getName());
        Assertions.assertTrue(deleteResponse.getStatus().isComplete());
        log.info("Deleted Secret Name: " + deleteResponse.getValue().getName());
        log.info("Delete Status: " + deleteResponse.getStatus());
        log.info("Is Key Secret Deleted: {}", deleteResponse.getStatus().isComplete());
        this.secretAsyncClient.purgeDeletedSecret(secretName)
                .doOnSuccess(purgeResponse ->
                        log.info("Successfully Purged current Secret - '{}'", secretName))
                .block();
        log.info("------------------------ Key Vault Delete Finished ------------------------");
    }

    @And("finally delete and purge the secret with name {string} from key vault")
    public void finallyDeleteAndPurgeTheSecretWithNameFromKeyVault(String secretName) {
        AsyncPollResponse<DeletedSecret, Void> deleteResponse = this.secretAsyncClient.beginDeleteSecret(secretName).blockLast();
        assertDeleteSecret(secretName, deleteResponse);
    }
}
