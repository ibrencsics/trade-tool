package com.gi_de.cpecom.tests.model.keyvault;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.nimbusds.jose.jwk.JWK;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class KeyProperties {

    private JWK jwk;

    private String keyLabel;

    private boolean isSensitive;

    private boolean isOverwrite;
}
