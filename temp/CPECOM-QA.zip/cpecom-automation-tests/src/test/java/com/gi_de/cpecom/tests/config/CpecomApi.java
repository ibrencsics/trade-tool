package com.gi_de.cpecom.tests.config;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class CpecomApi {
    public static final String PATH_TOKENIZE = "/tokenize";
    public static final String PATH_TRANSACT = "/transact";
    public static final String PATH_SUSPEND = "/suspend";
    public static final String PATH_RESUME = "/resume";
    public static final String PATH_DELETE = "/delete";
    public static final String PATH_REGISTER_DEVICE = "/register-device";
    public static final String PATH_BIND_DEVICE = "/bind-device";
    public static final String PATH_UNBIND_DEVICE = "/unbind-device";
    public static final String PATH_GET_IDV_OPTIONS = "/get-idv-options";
    public static final String PATH_SELECT_IDV_OPTION = "/select-idv-option";
    public static final String PATH_EXECUTE_IDV_OPTION = "/execute-idv-option";
    public static final String PATH_BULK_TOKENIZE = "/tokenize-bulk";
    public static final String PATH_BULK_MULTI_SCHEME_TOKENIZE = "/tokenize-bulk-multi-scheme";
    public static final String PATH_BULK_TOKENIZE_RESULTS = "/tokenize-bulk-results";
    @Deprecated
    public static final String PATH_ONBOARD = "/onboard";
    @Deprecated
    public static final String PATH_ONBOARD_TO_TSP = "/onboard-to-tsp";
    @Deprecated
    public static final String PATH_ONBOARD_TO_TSP_STATUS_CHECK = "/onboard-to-tsp-status-check";
    public static final String PATH_ONBOARD_TO_VTS = "/onboard-to-vts";
    public static final String PATH_ONBOARD_TO_MC = "/onboard-to-mc";
    public static final String PATH_OFF_BOARD_FROM_MC = "/offboard-from-mc";
    public static final String PATH_ONBOARD_TO_MC_STATUS = "/onboard-to-mc-status";
    public static final String PATH_TOKEN_INFO = "/token-info";
    public static final String PATH_TX_HISTORY = "/get-tx-history";
}
