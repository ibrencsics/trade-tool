package com.gi_de.cpecom.tests.common.exceptions;

public class SslCertificateNotFoundException extends Exception {

    public SslCertificateNotFoundException(String message) {
        super(message);
    }

}
