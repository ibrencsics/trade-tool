package com.gi_de.cpecom.tests.common.exceptions;

public class CusterIdNotFoundException extends Exception {

    public CusterIdNotFoundException(String message) {
        super(message);
    }
}
