package com.gi_de.cpecom.tests;

import org.junit.platform.suite.api.*;

import static io.cucumber.junit.platform.engine.Constants.*;
@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("cucumber/features/")
@ConfigurationParameters({
    @ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "com.gi_de.cpecom.tests.stepdefs"),
    @ConfigurationParameter(key = JUNIT_PLATFORM_NAMING_STRATEGY_PROPERTY_NAME, value = "long")
})
//some test comment
public class CucumberRunner {}
