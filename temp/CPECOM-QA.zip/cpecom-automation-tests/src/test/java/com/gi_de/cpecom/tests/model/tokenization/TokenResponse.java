package com.gi_de.cpecom.tests.model.tokenization;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class TokenResponse {

    private String statusCode;

    private String errorMessage;

    private String tokenReference;

    private String tspTokenReference;

    private TokenInfo tokenInfo;

    private String cardMetadataId;
}
