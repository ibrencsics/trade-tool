package com.gi_de.cpecom.tests.model.common;

public enum JobStatusEnum {
    DONE,
    INPROGRESS,
    FAILED
}
