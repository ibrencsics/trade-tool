/*
 * Copyright (c) Giesecke+Devrient Mobile Security GmbH 2020-2023
 */
package com.gi_de.cpecom.tests.common.customer;

public class TestKeyLabels {

    // Customer ENC and DEC keys

    public static final String CUST1_CP_ECPRIV_DEC_001 = "CUST1-CP-ECPRIV-DEC-001";
    public static final String CUST1_CP_RSAPRIV_DEC_001 = "CUST1-CP-RSAPRIV-DEC-001";
    public static final String CUST1_CP_ECPUB_ENC_001 = "CUST1-CP-ECPUB-ENC-001";

    // Customer SIGN and VERIFY keys - will be removed after NCA merge

    public static final String CUST1_CP_ECPRIV_SIGN_001 = "CUST1-CP-ECPRIV-SIGN-001";
    public static final String CUST1_CP_RSAPRIV_SIGN_001 = "CUST1-CP-RSAPRIV-SIGN-001";
    public static final String CUST1_CP_ECPUB_VERIFY_001 = "CUST1-CP-ECPUB-VERIFY-001";
    public static final String CUST1_CP_RSAPUB_VERIFY_001 = "CUST1-CP-RSAPUB-VERIFY-001";
}
