package com.gi_de.cpecom.tests.model.tokenization;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@Data
public class FundingAccountDataPlain {

    private String accountNumber;

    private String expirationDate;

    private String securityCode;
}
