#!/bin/bash

################################################################################
# Script to install the stuff used by the examples on a fresh machine.
# Some manual actions at the end are required (they get printed, same as
# summary of what was installed).
################################################################################

# For key validations.
sudo install -m 0755 -d /etc/apt/keyrings

# Vars
EXEC_LOG_FILE=/tmp/exec.log
devops_admin=adminuser
AGENT_DIR=/home/adminuser/ado-agent/
AZURE_AGENT_TOKEN=

# Create exec log
rm -f $EXEC_LOG_FILE
touch $EXEC_LOG_FILE
echo 'Running' >>$EXEC_LOG_FILE

# Update apt
sudo apt-get update --assume-yes
sudo apt-mark hold WALinuxAgent
sudo apt-get upgrade --assume-yes
sudo apt-mark unhold WALinuxAgent

# Install Java (JAVA_HOME won't be set)
sudo apt-get install --assume-yes openjdk-17-jdk-headless &&
  echo 'Java installed' >>$EXEC_LOG_FILE

# Install docker
# https://docs.docker.com/engine/install/ubuntu/#install-using-the-repository
sudo apt-get install --assume-yes ca-certificates curl gnupg
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo \
  "deb [arch="$(dpkg --print-architecture)" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  "$(. /etc/os-release && echo "$VERSION_CODENAME")" stable" |
  sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt-get update --assume-yes
sudo apt-get install --assume-yes docker-ce docker-ce-cli containerd.io
sudo chmod a+r /etc/apt/keyrings/docker.gpg
sudo usermod -aG docker "$devops_admin" &&
  echo 'Docker installed' >>$EXEC_LOG_FILE
sudo systemctl start docker &&
  echo 'Docker started' >>$EXEC_LOG_FILE

# Setup agent direcotry
# https://learn.microsoft.com/en-us/azure/devops/pipelines/agents/linux-agent?view=azure-devops
if ! [[ -d "$AGENT_DIR" ]]; then
  mkdir -p "$AGENT_DIR"
  TMP=agent.tar.gz
  # Agent should automatically upadte when a pipeline requires a new feature.
  wget -O "$TMP" https://vstsagentpackage.azureedge.net/agent/3.220.5/vsts-agent-linux-x64-3.220.5.tar.gz
  tar zxvf $TMP -C $AGENT_DIR
  rm $TMP
  TMP=
fi

# Setup azure cli
# https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt
sudo apt-get install --assume-yes azure-cli &&
  echo 'Installed azure-cli' >>$EXEC_LOG_FILE

# Setup kubectl
# https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/
sudo apt-get update --assume-yes
sudo apt-get install --assume-yes ca-certificates curl
curl -fsSL https://packages.cloud.google.com/apt/doc/apt-key.gpg |
  sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-archive-keyring.gpg
echo "deb [signed-by=/etc/apt/keyrings/kubernetes-archive-keyring.gpg] https://apt.kubernetes.io/ kubernetes-xenial main" |
  sudo tee /etc/apt/sources.list.d/kubernetes.list
sudo apt-get update --assume-yes
sudo apt-get install --assume-yes kubectl
kubectl completion bash | sudo tee /etc/bash_completion.d/kubectl >/dev/null

# Setup asdf (required for kubelogin)
sudo apt-get install --assume-yes unzip
git clone "https://github.com/asdf-vm/asdf.git" ~/.asdf --branch v0.12.0
# Assume script hasn't been added yet -> add to bashrc and source it.
if ! asdf --version >/dev/null 2>&1; then
  echo '. "$HOME/.asdf/asdf.sh"' >>~/.bashrc
  . "$HOME/.asdf/asdf.sh"
  echo '. "$HOME/.asdf/completions/asdf.bash"' >>~/.basrc
  . "$HOME/.asdf/completions/asdf.bash"
fi

# Setup kubelogin
asdf plugin add kubelogin
asdf install kubelogin latest
asdf global kubelogin latest
asdf update
asdf plugin update kubelogin
asdf install kubelogin latest
asdf global kubelogin latest

## Summary and Todo's after this script
# Keep at the end so it's readable after the installs.
cat <<EOF
What's done:
  - Installed JDK:
  - Installed Docker and created docker-group to use without sudo
    -> requires reconnecting shell
  - Prepared agent installation at:
    $AGENT_DIR
  - Installed azure-cli
  - Installed kubectl
  - Installed kubelogin

Remaining todo's:
  Java:
  - maybe set JAVA_HOME (might not be required)
  Agent (run commands from within $AGENT_DIR):
  - \`./config.sh\`
  - \`sudo ./svc.sh install\`
  - \`sudo ./svc.sh run\`
  Azure registrys
  - \`az login\`
  - \`az acr login --name <container registry name>\`
  Kubernetes
  - set up \`k\` as alias for \`kubectl\`: \`echo "alias k=kubectl" >> ~/.bashrc\`
  - set up bash completion for \`k\`:
    \`echo 'complete -o default -F __start_kubectl k' >>~/.bashrc\`
EOF
