# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Infrastructure provisioning (business tenant)

## Creating the pipelines

TODO:
- Document required AzureDevOps permissions for setting up the pipeline and for approving the service connections
- Document steps for setting up the pipeline in AzureDevOps

## Infra pipeline prerequisites

Following secrets/certificates should be added to the environment specifig ``lz-kev-vault``
before running the cpecom-infra-pipeline

* cpecom-sql-server-admin-pwd - Admin password for SQL Server.
* devops-admin-ssh-public-key - Public ssh key for DevOps VM Admin
* test-admin-ssh-public-key - Public ssh key for Test VM Admin
* aks-admin-ssh-public-key - Public ssh key for AKS Admin
* aks-ingress-rootca - Root CA for AKS Ingress certificate
* appgw-cert - Certificate for Application Gateway

After running the `cpecom-infra-pipeline` for the first time, following certificates
should be added the environment specifig KeyVault ``kv-certs-cpecom-<env>``:

* aks-ingress-cert - Certificate for AKS Ingress.

### Create Devops VM Linux User

Prerequisites:
- Ensure you have at least `Key Vault Secrets Officer` role over the scope of Infra KeyVault
- Ensure you have at least [Virtual Machine Contributor](https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles#virtual-machine-contributor)
role over the scope of DevopsVm

**NOTE:**
Current script assumes that the user who is executing the script is the one for whom the Linux user is going to be created.
If this is not the case, `AAD_USER_ID` (line 27) must be defined manually instead of reading the information from
signed-in user data.

```
# Navigate to environment specific script folder
cd CPECOM/scripts/<env>/devops-vm
# Execute 'create-devops-vm-user' script
./create-devops-vm-user.sh <linux-user-name>
```

### Uploading Infra Secrets and Certificates

Prerequisites:
- Ensure you have at least `Key Vault Certificates Officer` role over the scope of Certificates KeyVault
- Ensure you have at least `Key Vault Secrets Officer` role over the scope of Infra KeyVault
- KeyVault Infra and KeyVault Certificates exist

```
# Generate certificates (for dev only)
$ cd CPECOM/scripts/dev/appgw_and_nginx_certs
$ ./gen_certs.sh
# Generate secrets and upload certificates
$ cd CPECOM/scripts/dev
$ ./generate_and_upload_secrets.sh
# Generate linkerd CA and issuer secrets
$ cd CPECOM/scripts/dev/linkerd
$ ./generate_linkerd_dev_certs.sh
$ ./upload_linkerd_issuer_certs.sh
```

### Uploading Workload Secrets (for test keys only)

Prerequisites:
- Ensure you have az cli installed
- Ensure you have at least [Storage Blob Data Contributor](https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles#storage-blob-data-contributor)
role over to scope of ``devops`` storage account blob
- Target `Storage Account` and blob container (`devops`) exists
- Ensure you have Linux User and SSH Keys created for `CPECOM DevOps VM`
- Ensure you have at least `Key Vault Secrets Officer` and `Key Vault Crypto User` roles
over the scope of kv-gw and kv-crypto.

1. Upload test-keys to Storage Account

```
$ cd CPECOM/dev
$ ./upload_test_keys.sh
```

2. Login to DevOps VM via Bastion

3. Execute export keys script

```
$ cd /deployment/key-manager
$ ./export-test-keys.sh
```

NOTE: This will run KeyManager twice. You will have to complete MFA login for
both of these runs.

## DB Users

NOTEs: 
- This step will change when/if we switch to Managed Sql Server

Prerequisites:
- Ensure you have `Kv Secret Officer` role over the scope kv-be and kv-metadata
- Ensure devops vm user has been created, and you have permission for ssh secret key
- Ensure you are member of ``cpecom_sql_server_aad_admin`` ad group (Needed for reading DB Admin Pwd)

1. Login to Devops VM via Bastion 
2. Login to azure
   ``az login --tenant b3b09976-7567-445d-b27a-c164bb617670``
3. Go to Infra KeyVault and copy value of ``cpecom-sql-server-admin-pwd`` -secret to clipboard
4. Execute init db-users script
   ```
   cd /deployment/db-users
   ./create_db_users.sh db_admin
   => <paste db admin pwd>
   ```
## AKS Access

Prerequisites:
- Ensure you have required access package. E.g. CPECOM-<ENV> AKS Admin Access Package, CPECOM-<ENV> AKS Cluster Admin Access Package or CPECOM-<ENV> AKS Readers Access Package.
 
**Dev:**
* Login to DevOps VM and execute:
```
$ az login --tenant b3b09976-7567-445d-b27a-c164bb617670
$ az account set --subscription CPECOM-DEV
$ az aks get-credentials -n aks-cpecom-dev-001 -g rg-cpecom-dev-canadacentral-001
```

* Set cpecom as default ns (Optional)
```
kubectl config set-context --current --namespace=cpecom
```

**Stage:**
```
$ az login --tenant b3b09976-7567-445d-b27a-c164bb617670
$ az account set --subscription CPECOM-STAGE
$ az aks get-credentials -n aks-cpecom-stage-001 -g rg-cpecom-stage-canadacentral-001
```

* Set cpecom as default ns (Optional)
```
kubectl config set-context --current --namespace=cpecom
```

**PAT:**
```
$ az login --tenant b3b09976-7567-445d-b27a-c164bb617670
$ az account set --subscription CPECOM-PAT
$ az aks get-credentials -n aks-cpecom-pat-001 -g rg-cpecom-pat-canadacentral-001
```

* Set cpecom as default ns (Optional)
```
kubectl config set-context --current --namespace=cpecom
```

**Prod:**
TBD...

### Upgrading DevOps VM

DevOps VM is using a Centos image published by Center for Internet Security Inc (CIS). When upgrading
the image version we must define `offer`, `publisher`, `sku`, and `version` of image.

* To find offers of publisher CIS for CentOs, following script can be user:
```
$ az vm image list --offer CentOs --all --output table --publisher center-for-internet-security-inc
```

* Offer, publisher, sku, and version can be extracted from `Urn` of offer with following patter `Publisher:Offer:Sku:Version`

* After finding the image, availability on given region can be verified with

```
$ az vm image show -l <location> --urn <urn-of-image>
```

## Upgrading AKS Kubernetes version

1. Check available upgrades:
```
# All available upgrades in specified region
$ az aks get-versions --location canadacentral --output table

## Upgrade paths for specified cluster
$ az login --tenant b3b09976-7567-445d-b27a-c164bb617670
$ az account set --subscription CPECOM-DEV
$ az aks get-upgrades -g rg-cpecom-dev-canadacentral-001 -n aks-cpecom-dev-001 --output table
```
* The output for all available upgrades should be something like this
    ```
    KubernetesVersion    Upgrades
    -------------------  ----------------------------------------
    1.22.2(preview)      None available
    1.22.1(preview)      1.22.2(preview)
    1.21.2               1.22.1(preview), 1.22.2(preview)
    1.21.1               1.21.2, 1.22.1(preview), 1.22.2(preview)
    1.20.9               1.21.1, 1.21.2
    1.20.7               1.20.9, 1.21.1, 1.21.2
    1.19.13              1.20.7, 1.20.9
    1.19.11              1.19.13, 1.20.7, 1.20.9
    ```    
* The output for specifig cluster should be something like this
    ```
    Name     ResourceGroup                    MasterVersion    Upgrades
    -------  -------------------------------  ---------------  -----------------------
    default  rg-cpecom-dev-canadacentral-001  1.19.11          1.19.13, 1.20.7, 1.20.9
    ```

* [AKS must be updated sequentially. Minor version cannot be skipped](https://docs.microsoft.com/en-us/azure/aks/upgrade-cluster). 
This means that for the scenario above, the upgrade path to the GA latest versions would be 
``1.19.11 -> 1.20.9 -> 1.21.2``

2. Based on the upgrade path defined above, define next AKS version ``in env/<target-env>.tfvars``

* Run cpecom-infrastructure pipeline. This will trigger automated cordon & drain for 
nodes. By default, this means that a new node with latest-version and os image will be 
deployed. Then old nodes will be upgraded one-by-one, by first terminating the pods and
then performing the update. [https://docs.microsoft.com/en-us/azure/aks/concepts-security#cluster-upgrades].

* Pipeline will run until all nodes have been upgraded. When testing with 3 node cluster update took
about 20 minutes

## Linkerd

---
NOTE:
Currently,  linkerd cli is installed to *devops vm* on path ``/usr/local/bin/.linkerd2`` but it is not
configured to PATH of each user. Linkerd cli can be added to path with ``export PATH=$PATH:/usr/local/bin/.linkerd2/bin``.
---

### Rotating linkerd certificates

TODO [CPECOM-438]: Document process for rotating issuer-secrets and trust anchor cert

### Linkerd commands

* Verify linkerd installation

```
$ linkerd check
```

* Verify linkerd viz installation

```
$ linkerd viz check
```

### Linkerd viz commands

* Paths being called:
```
$ linkerd -n cpecom viz top deploy
```

* Verify mTLS (aggregated using linkerd viz edges)

```
$ linkerd viz -n cpecom edges deployment
```

* Verify mTLS (packet level using linkerd viz tap)

```
$ linkerd viz -n cpecom tap deploy
```

### Inspecting HELM release state stored in K8s secret

```
kubectl get secret <secret-name> -n <secret-ns> -o go-template='{{.data.release | base64decode | base64decode}}' | gzip -d | jq
E.g.
kubectl get secret sh.helm.release.v1.linkerd-release.v7 -n linkerd -o go-template='{{.data.release | base64decode | base64decode}}' | gzip -d | jq
```

## [Disaster recovery](docs/dr.md)

## Inspect requests blocked by Appgw WAF

1. Open Appgw in Azure portal
2. Navigate to Logs
3. Run query:
    ```
   AzureDiagnostics 
    | where ResourceProvider == "MICROSOFT.NETWORK" and Category == "ApplicationGatewayFirewallLog"   
    ```
   
## Troubleshooting Devops vm blob fuse issues

* Script execution logs: ``/var/lib/waagent/custom-script``
* Blob fuse config file: ``/root/fuse_connection.cfg``
* If mounting has failed because of invalid config file (e.g. wrong blob container name), blob directory has to be unmounted before trying to re-mount:
```
# Unmount 
umount /deployment
# Mount
sudo blobfuse "/deployment" --tmp-path=/mnt/resource/blobfusetmp --config-file="/root/fuse_connection.cfg" -o attr_timeout=240 -o entry_timeout=240 -o negative_timeout=12 0 -o allow_other
```

### Dashboard

* AppService logs for Dashboard dev:
```
# dashboard-server
az webapp log tail -g rg-cpecom-dashboard-dev-stage-canadacentral-001  -n cpecom-customer-dashboard-dev --subscription CPECOM-STAGE

# dashboard-auth-handler
az webapp log tail -g rg-cpecom-dashboard-dev-stage-canadacentral-001  -n cpecom-customer-dashboard-auth-handler-dev --subscription CPECOM-STAGE
```
* AppService SSH
```
az webapp create-remote-connection -g rg-cpecom-dashboard-dev-stage-canadacentral-001  -n cpecom-customer-dashboard-dev --subscription CPECOM-STAGE
az webapp ssh -g rg-cpecom-dashboard-dev-stage-canadacentral-001  -n cpecom-customer-dashboard-dev --subscription CPECOM-STAGE
```

**References**

https://docs.microsoft.com/en-us/azure/aks/upgrade-cluster

https://docs.microsoft.com/en-us/azure/aks/supported-kubernetes-versions?tabs=azure-cli

https://docs.microsoft.com/en-us/azure/aks/concepts-security#cluster-upgrades


