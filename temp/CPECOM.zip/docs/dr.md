## Failover

---
NOTE: 
Before running CPECOM-infra-dr pipeline, ensure Platform-dr pipeline for cpecom has run successfully.
---

1. **Run ``CPECOM-Infra-dr`` pipeline (tier3 & tier4)**
   1. From Azure Devops, navigate to ``Pipelines``
   2. Select ``All`` -> ``application`` -> ``CPECOM`` -> ``CPECOM-Infra-dr``
   3. Click ``Run pipeline``
   4. Click ``Run``
   5. Approve the plans for tier3 and tier4 when requested by the pipeline run

2. **Run ``CPECOM-Application`` pipeline (Choose Plan & Deploy Stages for DR-environments, e.g. Terraform Plan Stage DR, Terraform Apply Stage DR)**
   1. From Azure Devops, navigate to ``Pipelines``
   2. Select ``All`` -> ``application`` -> ``CPECOM`` -> ``CPECOM-Application``
   3. Click ``Run pipeline``
   4. Click ``Stages to run``
   5. Un-check ``Run all stages``
   6. Check ``Terraform Plan <Env>_Dr`` and ``Terraform Apply <Env>_Dr``
   7. Click ``Use selected stages``
   8. Click ``Run``
   9. Approve the plan when requested by the pipeline

3. **Run ``CPECOM-failover`` pipeline**
    1. From Azure Devops, navigate to ``Pipelines``
    2. Select ``All`` -> ``application`` -> ``CPECOM`` -> ``CPECOM-failover``
    3. Click ``Run pipeline``
    4. Click ``Run``
   
4. **Verify failover**
   
   1. Verify Azure SQL failover
      1. Open ``portal.azure.com``
      2. Find Azure SQL Server ``sql-cpecom-<env>-canadaeast-001``
      3. Click ``Failover groups``
      4. Open ``sqlfog-cpecom-<env>-001`` and ensure current **primary** Sql Server is ``sql-cpecom-<env>-canadaeast-001``
   2. Verify Cosmos failover
      1. Open ``portal.azure.com``
      2. Find Cosmos Db ``cosmos-cpecom-<env>-canadacentral-001``
      3. Click ``Replicate data globally`` and ensure current **Write Region** is ``Canada East``
   3. Verify Traffic Manager failover
      1. Open ``portal.azure.com``
      2. Find Traffic Manager Profile ``cp-ecom-<env>``
      3. From overview page, verify that state of
         1. pip-appgw-cpecom-<env>-canadacentral-001 is **Disabled**
         2. pip-appgw-cpecom-<env>-canadaeast-001 is **Enabled**
   4. Verify Application Gateway health
      1. Open ``portal.azure.com``
      2. Find ``appgw-cpecom-<env>-canadaeast-001``
      3. Click ``Resource Health`` and ensure current health status is **Available**
      
## Failback

1. **Run ``CPECOM-failback`` pipeline**
    1. From Azure Devops, navigate to ``Pipelines``
    2. Select ``All`` -> ``application`` -> ``CPECOM`` -> ``CPECOM-failback``
    3. Click ``Run pipeline``
    4. Click ``Run``

2. **Verify failback**

    1. Verify Azure SQL failover
        1. Open ``portal.azure.com``
        2. Find Azure SQL Server ``sql-cpecom-<env>-canadacentral-001``
        3. Click ``Failover groups``
        4. Open ``sqlfog-cpecom-<env>-001`` and ensure current **primary** Sql Server is ``sql-cpecom-<env>-canadacentral-001``
    2. Verify Cosmos failover
        1. Open ``portal.azure.com``
        2. Find Cosmos Db ``cosmos-cpecom-<env>-canadacentral-001``
        3. Click ``Replicate data globally`` and ensure current **Write Region** is ``Canada Central``
    3. Verify Traffic Manager failover
        1. Open ``portal.azure.com``
        2. Find Traffic Manager Profile ``cp-ecom-<env>``
        3. From overview page, verify that state of
            1. pip-appgw-cpecom-<env>-canadacentral-001 is **Enabled**
            2. pip-appgw-cpecom-<env>-canadaeast-001 is **Disabled**
    4. Verify Application Gateway health
        1. Open ``portal.azure.com``
        2. Find ``appgw-cpecom-<env>-canadacentral-001``
        3. Click ``Resource Health`` and ensure current health status is **Available**

3. **Run ```CPECOM-dr-destroy``` pipeline**
   1. From Azure Devops, navigate to ``Pipelines``
   2. Select ``All`` -> ``application`` -> ``CPECOM`` -> ``CPECOM-Infra-dr-destroy``
   3. Click ``Run pipeline``
   4. Click ``Run``



