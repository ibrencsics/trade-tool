## Dashboard

### Setup dashboard b2c for dashboardProjectId claim extension

1. Create new **User Attribute**
    * User attributes -> Add 
    * Enter following data:
      * Name: extension_EcomTokenizerCustomers
      * Data Type: String
      * Save
2. Create new API Connector
    * API Connectors -> New API Connector
    * Enter following data:
      * DisplayName: DashboardAuthHandlerConnector
      * Endpoint URL: https://cpecom-customer-dashboard-auth-handler-dev.azurewebsites.net/define-dashboard-project-memberships
      * Authentication type: Certificate -> Upload b2c client certificate
      * Save
3. Define Application claims for User flow
   * User flows -> B2C_1_signupsignin-email -> Application claims
   * Select Application claims
     * Check User's Object ID
     * Check extension_EcomTokenizerCustomers 
     * Save
4. Connect API Connector to User flow
   * User flows -> B2C_1_signupsignin-email -> API connectors
     * For *Before including application claims in token* select: *DashboardAuthHandlerConnector*
     * Save
   

### Dev-Certificates currently in use

* **cpecom-dev-root-ca.cer** - CA of cpecom dev-environment(s).
Uploaded to the dashboard lz-keyvault and from there to *cpecom-customer-dashboard-server* azure application. Used to validate cpecom-env server certificate.
* **b2c-dashboardcpecom-dev.pfx** - Client certificate of cpecom-customer-dashboard-server. 
Uploaded to to the dashboard lz-keyvault and bound to cpecom-customer-dashboard-dev app service plan.
* **test-root-ca** - Temporary CA for cpecom dashboard. Uploaded to the dashboard lz-keyvault and from there 
to *cpecom-customer-dashboard-auth-handler* azure application. Used to validate b2c client certificate.
* **b2c-dashboardcpecom-dev.pfx** - Temporary client certificate for cpecom-dashboard b2c api connector. Uploaded manually to azure b2c. 
Used as authentication method when b2c connects *cpecom-customer-dashboard-auth-handler*.