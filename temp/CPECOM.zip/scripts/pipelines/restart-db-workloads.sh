#!/usr/bin/env bash

restart_deployment() {
  local deployment=$1
  local ns=$2
  kubectl rollout restart deploy "$deployment" -n "$ns" &&
  kubectl rollout status deploy "$deployment" -n "$ns" --timeout 3m
}

restart_deployment "core-app" "cpecom" &&
restart_deployment "transact-app" "cpecom" &&
restart_deployment "metadata-app" "cpecom" &&
restart_deployment "admin-app" "cpecom" &&
restart_deployment "bulk-app" "cpecom" &&
echo "Done"