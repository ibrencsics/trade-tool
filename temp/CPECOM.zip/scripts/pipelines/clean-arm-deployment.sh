clean_arm_deployment() {
  local arm_deployment_name=$1
  local arm_deployment_rg_name=$2
  echo "*** Delete ARM Deployment: $arm_deployment_rg_name/$arm_deployment_name"
  az group deployment delete --name "$arm_deployment_name" --resource-group "$arm_deployment_rg_name"
}

usage() {
  echo "Usage: clean-arm-deployment.sh" \
    "<arm_deployment_name>" \
    "<arm_deployment_rg_name>"
}

if [ $# -lt 2 ];
then
	usage
  exit 1
else
  arm_deployment_name=$1
  arm_deployment_rg_name=$2
fi

clean_arm_deployment "$arm_deployment_name" "$arm_deployment_rg_name"


