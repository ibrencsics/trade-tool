#!/usr/bin/env bash

generate_output_blob_sas_uri() {
  local containerName=$1
  local staName=$2
  local end=`date -u -d "30 minutes" '+%Y-%m-%dT%H:%MZ'`
  az storage container generate-sas --auth-mode key \
                                  --expiry $end \
                                  --permissions racw \
                                  --name "$containerName" \
                                  --account-name "$staName" \
                                  --output tsv
}

run_cloud_test_runner() {
  local test_vm_rg_name=$1
  local test_vm_name=$2
  local output_sta_blob_uri=$3
  local error_sta_blob_uri=$4
  local tsp_mock_image=$5
  local cloud_test_runner_image=$6
  local test_profile_name=$7
  local test_customer=$8
  local target_tsp=$9
  local test_suite=${10}
  local test_tags_to_include=${11}
  local test_tags_to_exclude=${12}

  local script="/tests/run-cloud-test-runner.sh \
      $tsp_mock_image \
      $cloud_test_runner_image \
      $test_profile_name \
      $test_suite \
      $test_customer \
      $target_tsp \
      $test_tags_to_include \
      $test_tags_to_exclude"

  echo "### $script"

  az vm run-command create \
      --name run-cloud-test-runner \
      --resource-group "$test_vm_rg_name" \
      --vm-name "$test_vm_name" \
      --script "$script" \
      --output-blob-uri "$output_sta_blob_uri" \
      --error-blob-uri "$error_sta_blob_uri"
}

usage() {
  echo "Usage: run-cloud-test-runner.sh <test_vm_rg_name> <test_vm_name> <sta_name> <sta_container_name> <output_sta_blob_uri> <error_sta_blob_uri> <tsp_mock_image> <cloud_test_runner_image> <test_profile_name> <test_suite> <test_customer> <test_tags_to_include> <test_tags_to_exclude>"
}

if [ $# -lt 14 ];
then
	usage
  exit 1
else
  test_vm_rg_name=$1
  test_vm_name=$2
  sta_name=$3
  sta_container_name=$4
  output_sta_blob_uri=$5
  error_sta_blob_uri=$6
  tsp_mock_image=$7
  cloud_test_runner_image=$8
  test_profile_name=$9
  test_suite=${10}
  test_customer=${11}
  target_tsp=${12}
  test_tags_to_include=${13}
  test_tags_to_exclude=${14}
fi

echo "## Generate SAS for tester output" &&
sas=$(generate_output_blob_sas_uri "$sta_container_name" "$sta_name") &&
output_uri="$output_sta_blob_uri?$sas"
error_output_uri="$error_sta_blob_uri?$sas"
echo "## Run cloud tester." &&
run_cloud_test_runner \
  "$test_vm_rg_name" \
  "$test_vm_name" \
  "$output_uri" \
  "$error_output_uri" \
  "$tsp_mock_image" \
  "$cloud_test_runner_image" \
  "$test_profile_name" \
  "$test_customer" \
  "$target_tsp" \
  "$test_suite" \
  "$test_tags_to_include" \
  "$test_tags_to_exclude"