#!/usr/bin/env bash

purgeAfdEndpoint() {
  local rg_afd_endpoint="$1"
  local afd_profile_name="$2"
  local afd_endpoint_name="$3"
  local content_paths="$4"

  az afd endpoint purge -g "$rg_afd_endpoint" --endpoint-name "$afd_endpoint_name" --profile-name "$afd_profile_name" --content-paths "$content_paths"
}

usage() {
  echo "Usage: purge-cdn-endpoint.sh <rg_afd_endpoint> <afd_profile_name> <afd_endpoint_name> <content_paths>"
}

if [ $# -lt 4 ];
then
	usage
  exit 1
else
  rg_afd_endpoint="$1"
  afd_profile_name="$2"
  afd_endpoint_name="$3"
  content_paths="$4"
  purgeAfdEndpoint "$rg_afd_endpoint" "$afd_profile_name" "$afd_endpoint_name" "$content_paths"
fi




