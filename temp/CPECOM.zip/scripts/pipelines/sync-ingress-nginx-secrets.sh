#!/bin/bash

# Sourced FNs
. ../fn/ingress-nginx.sh

# Env
NGINX_NS="ingress-nginx"

usage() {
  echo "Usage: sync-ingress-nginx-secrets.sh <workDirPath> <kvName> <certName>"
}

if [ $# -lt 3 ];
then
	usage
  exit 1
else
  workDirPath=$1
	kvName=$2
  ingressNginxCertName=$3
fi

echo "#### workDirPath: $workDirPath kvName: $kvName ingressNginxCertName: $ingressNginxCertName" &&

# Create/Update NS for ingress-nginx
echo "#### Create NS $NGINX_NS" &&
nginx_create_ns "$NGINX_NS" &&

# Download nginx cert and key
echo "#### Download nginx cert $ingressNginxCertName" &&
nginx_download_cert "$kvName" "$ingressNginxCertName" \
                              "$workDirPath/nginx.pfx" "$workDirPath/nginx-cert.pem" "$workDirPath/nginx-key.pem" &&

# Create/Update nginx cert kubernetes secret
echo "#### Sync Nginx cert secret" &&
nginx_create_cert_secret "$NGINX_NS" "$workDirPath/nginx-key.pem" "$workDirPath/nginx-cert.pem" &&

echo "#### Ok"