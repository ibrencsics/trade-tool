#!/bin/bash

kubectl delete ns cpecom --force ;
kubectl delete ns linkerd --force ;
kubectl delete ns linkerd-viz --force ;
kubectl delete ns kured --force ;
kubectl delete ns metrics --force ;
kubectl delete ns ingress-nginx --force ;
kubectl delete ns datadog --force ;
kubectl delete ns icinga --force ;
echo "### Done"