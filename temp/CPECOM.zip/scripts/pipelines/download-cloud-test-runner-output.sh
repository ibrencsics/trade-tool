#!/usr/bin/env bash

az_sta_download_blob() {
  local sta_name=$1
  local sta_container_name=$2
  local sta_container_blob_name=$3
  local output_file_path=$4

  az storage blob download \
      --account-name "$sta_name" \
      -c "$sta_container_name" \
      -n "$sta_container_blob_name" \
      -f "$output_file_path"
}

usage() {
  echo "Usage: download-test-results.sh <sta_name> <sta_container_name> <sta_container_blob_name> <output_file_path>"
}

if [ $# -lt 4 ];
then
	usage
  exit 1
else
  sta_name=$1
  sta_container_name=$2
  sta_container_blob_name=$3
  output_file_path=$4
fi

az_sta_download_blob "$sta_name" "$sta_container_name" "$sta_container_blob_name" "$output_file_path"