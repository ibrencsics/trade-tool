#!/bin/bash -e

appendCpecomImageTfVar() {
              acr=$1
              tfVarsFile=$2
              variable=$3
              image=$4
              imagePath="$acr/$image"
              echo "$variable=\"$imagePath\"" >> "$tfVarsFile"
}

usage() {
  echo "Usage: create-cpecom-images-tfvars.sh" \
    "<tfVarsFileOutputPath>" \
    "<acr>" \
    "<cpecomFlywayBackendImage>" \
    "<cpecomFlywayMetadataImage>" \
    "<cpecomBulkImage>" \
    "<cpecomCoreImage>" \
    "<cpecomCryptoImage>" \
    "<cpecomCustgwImage>" \
    "<cpecomMetadataImage>" \
    "<cpecomTransactImage>" \
    "<cpecomTspgwImage>" \
    "<cpecomAdminImage>" \
    "<cpecomDashboardBeImage>"
}

if [ $# -lt 13 ];
then
	usage
  exit 1
else
  tfVarsFileOutputPath=$1
  acr=$2
  cpecomFlywayBackendImage=$3
  cpecomFlywayMetadataImage=$4
  cpecomBulkImage=$5
  cpecomCoreImage=$6
  cpecomCryptoImage=$7
  cpecomCustgwImage=$8
  cpecomMetadataImage=${9}
  cpecomTransactImage=${10}
  cpecomTspgwImage=${11}
  cpecomAdminImage=${12}
  cpecomDashboardBeImage=${13}
fi

tfVarsFile="$tfVarsFileOutputPath/cpecom-images.auto.tfvars" &&
[ ! -e "$tfVarsFile" ] || rm "$tfVarsFile" &&
touch "$tfVarsFile" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" flyway_backend_image "$cpecomFlywayBackendImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" flyway_metadata_image "$cpecomFlywayMetadataImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" cpecom_bulk_image "$cpecomBulkImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" cpecom_core_image "$cpecomCoreImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" cpecom_crypto_image "$cpecomCryptoImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" cpecom_custgw_image "$cpecomCustgwImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" cpecom_metadata_image "$cpecomMetadataImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" cpecom_transact_image "$cpecomTransactImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" cpecom_tspgw_image "$cpecomTspgwImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" cpecom_admin_image "$cpecomAdminImage" &&
appendCpecomImageTfVar "$acr" "$tfVarsFile" cpecom_dashboard_be_image "$cpecomDashboardBeImage" &&
echo "### Done. Produced following tfvars file:" &&
cat "$tfVarsFile"