#!/usr/bin/env bash

. ../fn/az.sh

switch_cosmos() {
  local cosmos_rg_name=$1
  local cosmos_account_name=$2
  local cosmos_primary_region=$3
  local cosmos_secondary_region=$4

  az_cosmos_failover_priority_change "$cosmos_rg_name" "$cosmos_account_name" "$cosmos_primary_region=0" "$cosmos_secondary_region=1"
}

switch_sql_server() {
  local sql_fog_name=$1
  local sql_primary_server_rg=$2
  local sql_primary_server_name=$3

  az_sql_failover_set_primary "$sql_fog_name" "$sql_primary_server_rg" "$sql_primary_server_name"
}

switch_traffic_manager_endpoint() {

  local traffic_manager_rg_name=$1
  local traffic_manager_profile_name=$2
  local traffic_manager_endpoint_to_enable=$3
  local traffic_manager_endpoint_to_disable=$4

  az_enable_traffic_manager_endpoint "$traffic_manager_rg_name" "$traffic_manager_profile_name" "$traffic_manager_endpoint_to_enable" &&
    az_disable_traffic_manager_endpoint "$traffic_manager_rg_name" "$traffic_manager_profile_name" "$traffic_manager_endpoint_to_disable"
}

usage() {
  echo "Usage: ./dr-switch.sh" \
    "traffic_manager_rg_name" \
    "traffic_manager_profile_name" \
    "traffic_manager_endpoint_to_enable" \
    "traffic_manager_endpoint_to_disable" \
    "azure_sql_fog_name" \
    "azure_sql_primary_server_name" \
    "azure_sql_primary_server_rg_name" \
    "cosmos_rg_name" \
    "cosmos_account_name" \
    "cosmos_primary_region" \
    "cosmos_secondary_region"
}

if [ $# -lt 11 ]; then
  usage
  exit 1
else
  traffic_manager_rg_name=$1
  traffic_manager_profile_name=$2
  traffic_manager_endpoint_to_enable=$3
  traffic_manager_endpoint_to_disable=$4

  azure_sql_fog_name=$5
  azure_sql_primary_server_rg_name=$6
  azure_sql_primary_server_name=$7

  cosmos_rg_name=$8
  cosmos_account_name=$9
  cosmos_primary_region=${10}
  cosmos_secondary_region=${11}
fi

echo "## Dr switch" &&
echo "### Switch Azure SQL" &&
switch_sql_server "$azure_sql_fog_name" "$azure_sql_primary_server_rg_name" "$azure_sql_primary_server_name" &&
echo "## Ok" &&
echo "### Switch Cosmos" &&
switch_cosmos "$cosmos_rg_name" "$cosmos_account_name" "$cosmos_primary_region" "$cosmos_secondary_region" &&
echo "## Ok" &&
echo "### Switch TrafficManager Endpoint" &&
switch_traffic_manager_endpoint "$traffic_manager_rg_name" "$traffic_manager_profile_name" "$traffic_manager_endpoint_to_enable" "$traffic_manager_endpoint_to_disable" &&
echo "## Ok"