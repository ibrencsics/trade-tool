#!/bin/bash -e

# Sourced FNs
. ../fn/linkerd.sh

# Env
LINKERD_NS="linkerd"

usage() {
  echo "Usage: sync-linkerd-secrets.sh <workDirPath> <kvName> <certName> <tfAutoVarsOutputPath>"
}

if [ $# -lt 4 ];
then
	usage
  exit 1
else
  workDirPath=$1
	kvName=$2
  linkerdIssuerCertName=$3
  tfOutputPath=$4
fi

echo "#### workDirPath: $workDirPath kvName: $kvName linkerdCertName: $linkerdIssuerCertName tfOutputPath: $tfOutputPath"

# Create NS for linkerd
echo "#### Create NS $LINKERD_NS" &&
linkerd_create_ns "$LINKERD_NS" &&

# Download issuer secrets
echo "#### Download issuer cert $linkerdIssuerCertName" &&
linkerd_download_issuer_secrets "$kvName" "$linkerdIssuerCertName" \
                                "$workDirPath/issuer.pfx" "$workDirPath/issuer-cert.pem" "$workDirPath/issuer-key.pem" "$workDirPath/trust-root-cert.pem" &&

# Generate auto.tfvars file containing the linkerd trust-root cert in base64 encoded format
echo "#### Generate Trust root cert tfvars file: $tfOutputPath/linkerd.auto.tfvars" &&
linkerd_generate_linkerd_trust_anchor_cert_tf_var "$workDirPath/trust-root-cert.pem" "$tfOutputPath/linkerd.auto.tfvars" &&

# Create linkerd issuer kubernetes secret
echo "#### Sync Linkerd Issuer secret" &&
linkerd_create_issuer_secrets "$LINKERD_NS" "$workDirPath/issuer-key.pem" "$workDirPath/issuer-cert.pem" &&

echo "#### Ok"