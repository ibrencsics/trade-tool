#!/bin/bash

# Sourced FNs
. ../../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="CPECOM-STAGE"
LZ_KV_NAME="kv-gd-cpecom-dashboard-d"
SECRET_NAME="test-root-ca"
CRT_FILE="./tmp/test-root-ca.crt"
CER_FILE="./tmp/test-root-ca.cer"
WORK_DIR="./tmp"

upload_root_ca() {
  secret_name=$1
  secret_file=$2
  kv_name=$3

  base64enc_file="$WORK_DIR/$secret_name"base64

  base64 -w0 "$secret_file" >"$base64enc_file" &&
    secret_value=$(cat "$base64enc_file") &&
    az_set_kv_secret "$secret_name" "$secret_value" "$kv_name"
}

#
# NOTE: It is assumed that CA cert is in PEM format.
#
echo "Upload " &&
  az_login "$TENANT_ID" "$SUBSCRIPTION" &&
  openssl x509 -inform PEM -outform der -in "$CRT_FILE" -out "$CER_FILE" &&
  upload_root_ca "$SECRET_NAME" "$CER_FILE" "$LZ_KV_NAME" &&
  echo "DONE"
