#!/bin/bash -e

. ../../../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="CPECOM-DEV"

DEV_KEYMAN_KV_LOCATION="canadacentral"
DEV_KEYMAN_RG_NAME="rg-kv-dev-keyman"
DEV_KEYMAN_KV_NAME="kv-dev-keyman"
DEV_CA_CERTIFICATE_PATH="./dev-ca/out/dev-ca.crt"
DEV_CA_PRIVATE_KEY_PATH="./dev-ca/out/dev-ca.key"
DEV_CA_NAME_SECRET_LABEL="dev-ca-root-certificate"
DEV_CA_KEY_LABEL="dev-ca-root-key"

create_kv_rg() {
  location=$1
  rg_name=$2
  az group create --location "$location" --name "$rg_name"
}

create_kv() {
  location=$1
  rg_name=$2
  kv_name=$3
  az keyvault create \
    --location "$location" \
    --resource-group "$rg_name" \
    --name "$kv_name" \
    --network-acls kv-dev-keyman-network-acls.json \
    --enable-rbac-authorization "true" \
    --enabled-for-deployment "true" \
    --enabled-for-disk-encryption "true" \
    --retention-days "7" \
    --sku "standard"
}

az_login "$TENANT_ID" "$SUBSCRIPTION" &&
create_kv_rg "$DEV_KEYMAN_KV_LOCATION" "$DEV_KEYMAN_RG_NAME" &&
create_kv "$DEV_KEYMAN_KV_LOCATION" "$DEV_KEYMAN_RG_NAME" "$DEV_KEYMAN_KV_NAME"
echo "DONE"
