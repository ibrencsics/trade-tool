#!/bin/bash

create_ca() {
  CA_NAME=$1

  cat >out/"$CA_NAME".conf <<EOF
  [req]
  default_bits  = 4096
  distinguished_name = req_distinguished_name
  x509_extensions = v3_req
  prompt = no

  [req_distinguished_name]
  countryName = DE
  stateOrProvinceName = Bavaria
  localityName = Munich
  organizationName = Giesecke+Devrient GmbH
  organizationalUnitName = MSSTS
  commonName = "$CA_NAME".gi-de.com

  [v3_req]
  basicConstraints=CA:TRUE
EOF

  # Key
  openssl genrsa -des3 -out out/"$CA_NAME".key -passout pass:123456 2048 &&
  # Crt
  openssl req -x509 -new -nodes -key out/"$CA_NAME".key -sha256 -days 1825 -out out/"$CA_NAME".crt -config out/"$CA_NAME".conf -passin pass:123456 &&
  # PEM to DER
  openssl x509 -in out/"$CA_NAME".crt -out out/"$CA_NAME".der -outform DER &&
  echo "CA $CA_NAME DONE" &&
  echo "----------------"
  rm out/"$CA_NAME".conf
}

# CA
CN_CA=dev-ca
mkdir -p out

# Generate root CA
create_ca "$CN_CA"