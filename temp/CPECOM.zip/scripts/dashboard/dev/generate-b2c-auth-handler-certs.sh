#!/bin/bash

create_ca() {
  CA_NAME=$1

  cat > "$OUTPUT_DIR/$CA_NAME".conf << EOF
[req]
default_bits  = 2048
distinguished_name = req_distinguished_name
x509_extensions = v3_req
prompt = no

[req_distinguished_name]
countryName = DE
stateOrProvinceName = Bavaria
localityName = Munich
organizationName = Giesecke+Devrient GmbH
organizationalUnitName = MSSTS
commonName = "$CA_NAME".gi-de.com

[v3_req]
basicConstraints=CA:TRUE
EOF

  openssl genrsa -des3 -out "$OUTPUT_DIR/$CA_NAME".key -passout pass:123456 2048
  openssl req -x509 -new -nodes -key "$OUTPUT_DIR/$CA_NAME".key -sha256 -days 1825 -out "$OUTPUT_DIR/$CA_NAME".crt -config "$OUTPUT_DIR/$CA_NAME".conf -passin pass:123456
  rm "$OUTPUT_DIR/$CA_NAME".conf
}

create_cert() {
  SUBJECT_NAME=$1
  FILE_NAME=$(echo $1 | tr "[:upper:]" "[:lower:]")
  CA_NAME=$2

  cat > "$OUTPUT_DIR/$FILE_NAME".conf << EOF
[req]
default_bits  = 2048
distinguished_name = req_distinguished_name
x509_extensions = v3_req
req_extensions = v3_req
prompt = no

[req_distinguished_name]
countryName = DE
stateOrProvinceName = Bavaria
localityName = Munich
organizationName = G+D Mobile Security GmbH
organizationalUnitName = MSSTS
commonName = $SUBJECT_NAME

[v3_req]
basicConstraints = CA:FALSE
keyUsage = keyAgreement, keyEncipherment, digitalSignature
extendedKeyUsage = clientAuth
EOF

  openssl req -new -config "$OUTPUT_DIR/$FILE_NAME".conf -keyout "$OUTPUT_DIR/$FILE_NAME".key -out "$OUTPUT_DIR/$FILE_NAME".csr -nodes
  openssl x509 -req -extensions v3_req -extfile "$OUTPUT_DIR/$FILE_NAME".conf -in "$OUTPUT_DIR/$FILE_NAME".csr -CA "$OUTPUT_DIR/$CA_NAME".crt -CAkey "$OUTPUT_DIR/$CA_NAME".key -CAcreateserial -out "$OUTPUT_DIR/$FILE_NAME".crt -days 3650 -sha256 -passin pass:123456

  rm "$OUTPUT_DIR/$FILE_NAME".conf
  rm "$OUTPUT_DIR/$FILE_NAME".csr
}

sign_csr() {
  SUBJECT_NAME=$1
  FILE_NAME=$(echo $1 | tr "[:upper:]" "[:lower:]")
  CA_NAME=$2

  cat > "$OUTPUT_DIR/$FILE_NAME".conf << EOF
[req]
default_bits  = 2048
distinguished_name = req_distinguished_name
x509_extensions = v3_req
req_extensions = v3_req
prompt = no

[req_distinguished_name]
countryName = DE
stateOrProvinceName = Bavaria
localityName = Munich
organizationName = G+D Mobile Security GmbH
organizationalUnitName = MSSTS
commonName = $SUBJECT_NAME

[v3_req]
basicConstraints = CA:FALSE
keyUsage = keyAgreement, keyEncipherment, digitalSignature
extendedKeyUsage = clientAuth
EOF

  openssl x509 -req -extensions v3_req -extfile "$OUTPUT_DIR/$FILE_NAME".conf -in "$OUTPUT_DIR/$FILE_NAME".csr -CA "$OUTPUT_DIR/$CA_NAME".crt -CAkey "$OUTPUT_DIR/$CA_NAME".key -CAcreateserial -out "$OUTPUT_DIR/$FILE_NAME".crt -days 3650 -sha256 -passin pass:123456

  rm "$OUTPUT_DIR/$FILE_NAME".conf
}

OUTPUT_DIR="tmp"

# Generate root CA
create_ca test-root-ca
# Generate client cert
create_cert b2c-dashboardcpecom-dev test-root-ca
