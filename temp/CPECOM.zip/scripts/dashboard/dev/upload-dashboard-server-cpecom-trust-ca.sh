#!/bin/bash

# Sourced FNs
. ../../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="CPECOM-STAGE"
LZ_KV_NAME="kv-gd-cpecom-dashboard-d"
SECRET_NAME="cpecom-dev-root-ca"
CER_BASE64_FILE="./tmp/cpecom-dev-root-ca.cer"

upload_root_ca() {
  secret_name=$1
  secret_file=$2
  kv_name=$3

  secret_value=$(cat "$secret_file") && az_set_kv_secret "$secret_name" "$secret_value" "$kv_name"
}

#
# NOTE: It is assumed that CA cert is in base64 encoded cer format.
#
echo "Upload Root CAs" &&
  az_login "$TENANT_ID" "$SUBSCRIPTION" &&
  upload_root_ca "$SECRET_NAME" "$CER_BASE64_FILE" "$LZ_KV_NAME" &&
  echo "DONE"