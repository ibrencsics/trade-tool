#!/bin/bash

# Sourced FNs
. ../../fn/az.sh

cert_as_pfx() {
  local crt=$1
  local key=$2
  local caCrt=$3
  local pfxOut=$4

  openssl pkcs12 -export -inkey "$key" -in "$crt" -certfile "$caCrt" -out "$pfxOut" -passout pass:
}

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="CPECOM-STAGE"
LZ_KV_NAME="kv-gd-cpecom-dashboard-d"
CERT_PATH="./tmp/test-appgw-cert.crt"
KEY_PATH="./tmp/test-appgw-cert.key"
CA_PATH="./tmp/cpecom-appgw-tls-server-root-ca.crt"
PFX_OUT="./tmp/dashboard-test-client-cert.pfx"

echo "Cert as pfx" &&
  cert_as_pfx "$CERT_PATH" "$KEY_PATH" "$CA_PATH" "$PFX_OUT" &&
  az_login "$TENANT_ID" "$SUBSCRIPTION" &&
  az_import_kv_cert dashboard-dev-client-cert "$PFX_OUT" "$LZ_KV_NAME" &&
  echo "DONE"