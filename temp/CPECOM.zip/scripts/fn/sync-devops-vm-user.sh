#!/usr/bin/env bash


usage() {
  echo "Usage: sync-devops-vm-user.sh <work_dir_path> <kv_name> <vm_rg_name> <vm_name> <aad_user_id> <linux_user_name>"
}

random_pwd() {
  pwd=$(openssl rand -base64 20)
  echo "$pwd"
}

rsa_key_pair() {

  key_name=$1
  work_dir=$2

  ssh-keygen \
    -t rsa \
    -b 4096 \
    -C "$key_name" \
    -f "$work_dir/$key_name" \
    -N "" &&

  echo "$work_dir/$key_name"
}

set_kv_secret() {
  secret_name=$1
  secret_value=$2
  kv_name=$3

  az keyvault secret set \
    --name "$secret_name" \
    --vault-name "$kv_name" \
    --value "$secret_value" \
    --output none
}

az_vm_user_update() {
  rg=$1
  vm_name=$2
  user_name=$3
  pwd=$4
  ssh_public_key=$5

  az vm user update -u "$user_name" \
                    --password "$pwd" \
                    --ssh-key-value "$ssh_public_key" \
                    -n "$vm_name" \
                    -g "$rg" \
                    --output none
}

add_to_linux_groups() {
  rg=$1
  vm_name=$2
  linux_user_name=$3

  local group_deployer="deployer"
  local group_docker="docker"
  local script="usermod -aG $group_docker $linux_user_name && usermod -aG $group_deployer $linux_user_name"

  az vm run-command create --name "add-to-linux-groups-command" \
                           -g "$rg" \
                           --vm-name "$vm_name" \
                           --async-execution false \
                           --timeout-in-seconds 120 \
                           --script "$script" \
                           --output none
}

az_assign_secret_permissions() {
  kv_name=$1
  aad_user_id=$2
  ssh_private_key_name=$3
  linux_user_pwd_name=$4

  kv_id=$(az keyvault show -n "$kv_name" -o tsv --query id) &&
  echo "## Assign \"Key Vault Reader\": $kv_id" &&
  az role assignment create --role "Key Vault Reader" --assignee "$aad_user_id" --scope "$kv_id" --output none &&
  echo "## Assign Key Vault Secrets User: $kv_id/secrets/$ssh_private_key_name"&&
  az role assignment create --role "Key Vault Secrets User" --assignee "$aad_user_id" --scope "$kv_id/secrets/$ssh_private_key_name" --output none &&
  echo "## Assign Key Vault Secrets User: $kv_id/secrets/$linux_user_pwd_name" &&
  az role assignment create --role "Key Vault Secrets User" --assignee "$aad_user_id" --scope "$kv_id/secrets/$linux_user_pwd_name" --output none
}

if [ $# -lt 6 ];
then
	usage
  exit 1
else
  work_dir_path=$1
	kv_name=$2
	vm_rg_name=$3
	vm_name=$4
  aad_user_id=$5
  linux_user_name=$6
fi

RSA_KEY_NAME="devopsvm-$linux_user_name-ssh"
LINUX_PWD_NAME="devopsvm-$linux_user_name-pwd"

# Create ssh RSA key pair
echo "#### Create SSH Key Pair" &&
rsa_key_pair "$RSA_KEY_NAME" "$work_dir_path" &&

# Create random pwd
echo "#### Create linux user password" &&
linux_user_pwd=$(random_pwd) &&

# Create VM User (LINUX_USER_NAME, SSH_PUBLIC_KEY, PWD)
rsa_key_path="$work_dir_path/$RSA_KEY_NAME" &&
echo "#### Create linux user $linux_user_name. Using key from: $rsa_key_path" &&
ssh_public_key=$(cat "$rsa_key_path.pub") &&
az_vm_user_update "$vm_rg_name" "$vm_name" "$linux_user_name" "$linux_user_pwd" "$ssh_public_key" &&

# Store Linux ssh private key to KV
echo "#### Store ssh private key for $linux_user_name to $kv_name" &&
ssh_private_key=$(cat "$rsa_key_path") &&
set_kv_secret "$RSA_KEY_NAME" "$ssh_private_key" "$kv_name" &&

# Store Linux pwd key to KV
echo "#### Store linux user pwd for $linux_user_name to $kv_name" &&
set_kv_secret "$LINUX_PWD_NAME" "$linux_user_pwd" "$kv_name" &&

# Add user to deployer -group
echo "#### Add linux group membership for $linux_user_name" &&
add_to_linux_groups "$vm_rg_name" "$vm_name" "$linux_user_name" &&

# Assign secret reader permission for linux password
echo "#### Assign KeyVault permissions" &&
az_assign_secret_permissions "$kv_name" "$aad_user_id" "$RSA_KEY_NAME" "$LINUX_PWD_NAME"