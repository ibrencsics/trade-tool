linkerd_create_ns() {
  local namespace=$1
  cat <<EOF | kubectl apply -f -
  kind: Namespace
  apiVersion: v1
  metadata:
    name: "$namespace"
    annotations:
      linkerd.io/inject: disabled
    labels:
      linkerd.io/is-control-plane: "true"
      config.linkerd.io/admission-webhooks: disabled
      linkerd.io/control-plane-ns: "$namespace"
      name: "$namespace"
EOF
}

linkerd_create_issuer_secrets() {
  local linkerd_ns=$1
  local issuer_private_key_pem_file=$2
  local issuer_cert_pem_file=$3

  local issuer_private_key_base64=$(base64 -w0 "$issuer_private_key_pem_file") &&
  local issuer_cert_base64=$(base64 -w0 "$issuer_cert_pem_file") &&

  cat <<EOF | kubectl apply -f -
  apiVersion: v1
  kind: Secret
  metadata:
    name: linkerd-identity-issuer
    namespace: $linkerd_ns
    labels:
      linkerd.io/control-plane-component: identity
      linkerd.io/control-plane-ns: $linkerd_ns
  type: Generic
  data:
    tls.key: $issuer_private_key_base64
    tls.crt: $issuer_cert_base64
EOF
}

linkerd_download_issuer_secrets() {
  local kv_name=$1
  local kv_cert_name=$2

  local issuer_pfx_out=$3
  local issuer_crt_pem_out=$4
  local issuer_key_pem_out=$5
  local ca_crt_pm_out=$6

  az keyvault secret download --name "$kv_cert_name" --vault-name "$kv_name" -f "$issuer_pfx_out" --encoding base64 &&
  openssl pkcs12 -password pass: -in "$issuer_pfx_out" -nocerts -nodes | openssl pkcs8 -nocrypt -out "$issuer_key_pem_out" &&
  openssl pkcs12 -password pass: -in "$issuer_pfx_out" -nokeys -nodes | openssl x509 -out "$issuer_crt_pem_out" &&
  openssl pkcs12 -password pass: -in "$issuer_pfx_out" -nokeys -cacerts -nodes | openssl x509 -out "$ca_crt_pm_out"
}

linkerd_generate_linkerd_trust_anchor_cert_tf_var() {
  local trust_anchor_cert_pem_file=$1
  local outputPath=$2

  local trust_anchor_cert_pem_base64=$(base64 -w0 "$trust_anchor_cert_pem_file") &&
  echo linkerd_trust_anchor_cert_base64="\"$trust_anchor_cert_pem_base64\"" > "$outputPath"
}