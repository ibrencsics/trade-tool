#!/bin/bash -e

k8s_read_api_server_endpoint_ip() {
  local apiEndPoint=$(kubectl get endpoints -n default kubernetes -o jsonpath={@.subsets..addresses..ip}) &&
    echo "$apiEndPoint"
}