linkerd_dev_create_open_ssl_conf() {
  local output=$1
  cat >"$output" <<EOF
  [ v3_ca ]
  basicConstraints = critical,CA:TRUE
  subjectKeyIdentifier = hash
EOF
}

linkerd_dev_create_ca_conf() {
  local commonName=$1
  local output=$2
  cat >"$output" <<EOF
[req]
distinguished_name = req_distinguished_name
prompt = no

[req_distinguished_name]
countryName = DE
stateOrProvinceName = Bavaria
localityName = Munich
organizationName = Giesecke+Devrient GmbH
organizationalUnitName = MSSTS
commonName = "$commonName"

EOF
}

linkerd_dev_create_ca_key_and_cert() {
  local validityDays=$1
  local caConf=$2

  local caPrivateKeyOut=$3
  local caPublicKeyOut=$4
  local caCrtOut=$5

  # Create CA private key
  if [ ! -f "$caPrivateKeyOut" ]; then
      openssl ecparam -name prime256v1 -genkey -noout -out "$caPrivateKeyOut"
  fi

  # Create CA public key
  openssl ec -in "$caPrivateKeyOut" -pubout -out "$caPublicKeyOut" &&
  # Create self signed CA certificate
  openssl req -x509 -new -key "$caPrivateKeyOut" -days "$validityDays" -out "$caCrtOut" -config "$caConf"
}

linkerd_dev_create_issuer_conf() {
  local commonName=$1
  local output=$2
  cat >"$output" <<EOF

[req]
distinguished_name = req_distinguished_name
prompt = no

[req_distinguished_name]
countryName = DE
stateOrProvinceName = Bavaria
localityName = Munich
organizationName = Giesecke+Devrient GmbH
organizationalUnitName = MSSTS
commonName = "$commonName"

EOF
}

linkerd_dev_create_issuer_key_and_cert() {
  local validityDays=$1
  local opensslConf=$2
  local issuerConf=$3
  local caPrivateKey=$4
  local caCert=$5

  local issuerPrivateKeyOut=$6
  local issuerPublicKeyOut=$7
  local issuerCsrOut=$8
  local issuerCrtOut=$9

  # Create issuer private key
  if [ ! -f "$issuerPrivateKeyOut" ]; then
      openssl ecparam -name prime256v1 -genkey -noout -out "$issuerPrivateKeyOut"
  fi

  # Create issuer public key
  openssl ec -in "$issuerPrivateKeyOut" -pubout -out "$issuerPublicKeyOut" &&

  # Create certificate signing request
  openssl req -new -key "$issuerPrivateKeyOut" -out "$issuerCsrOut" -config "$issuerConf"  &&

  # Create issuer cert by signing request
  openssl x509 \
      -extensions v3_ca -extfile "$opensslConf" \
      -req \
      -in "$issuerCsrOut" \
      -days "$validityDays" \
      -CA "$caCert" \
      -CAkey "$caPrivateKey" \
      -CAcreateserial \
      -out "$issuerCrtOut"
}

linkerd_dev_issuer_cert_as_pfx() {
  local issuerCrt=$1
  local issuerKey=$2
  local caCrt=$3
  local pfxOut=$4

  openssl pkcs12 -export -inkey "$issuerKey" -in "$issuerCrt" -certfile "$caCrt"  -out "$pfxOut" -passout pass:
}




