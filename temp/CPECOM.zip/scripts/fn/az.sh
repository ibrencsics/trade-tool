az_login() {
  local tenantId=$1
  local subscription=$2
  az login --use-device-code --tenant "$tenantId" &&
    az account set --subscription "$subscription"
}

az_jib_push_to_acr() {
  APP=$1
  ACR=$2
  USER_NAME=00000000-0000-0000-0000-000000000000
  CR_LOGIN_SERVER=$ACR".azurecr.io"

  echo "Pushing $APP to ACR: $ACR"
  TOKEN=$(az acr login -n "$ACR" --expose-token | jq -r '.accessToken')
  mvn -Ddocker.repository.target="$CR_LOGIN_SERVER" -P docker-image-build -f "$APP" clean compile jib:build \
    -Djib.to.auth.username=$USER_NAME \
    -Djib.to.auth.password="$TOKEN" \
    -Djib.httpTimeout=0
}

az_docker_build_push_to_acr() {
  DOCKER_FILE=$1
  IMAGE_NAME=$2
  TAG=$3
  ACR_NAME=$4
  IMAGE="test-images/$IMAGE_NAME:$TAG"

  echo "Build $DOCKER_FILE. Push to $IMAGE to $ACR_NAME"
  az acr build \
    -f "$DOCKER_FILE" \
    -t "$IMAGE" \
    -r "$ACR_NAME" .
}

az_kv_purge() {
  kvName=$1
  az keyvault purge -n "$kvName" || echo "Delete/Purge of $kvName Failed. Already deleted?" && echo "$kvName PURGED"
}

az_aks_configure_kubectl() {
  aksName=$1
  rgName=$2
  echo "az aks get-credentials -g $rgName -n $aksName --admin" &&
    az aks get-credentials -g "$rgName" -n "$aksName" --admin &&
    kubectl config set-cluster "$aksName" --insecure-skip-tls-verify=true &&
    kubectl config set-context --current --namespace=cpecom
}

az_aks_credentials_for_lens() {
  aksName=$1
  rgName=$2
  az aks get-credentials -n "$aksName" -g "$rgName" --admin -f "$aksName.lens-credentials"
}

az_delete_rg_policy_assignments() {
  local rg_name="$1"
  local policy_assignments=$(az policy assignment list -g "$rg_name" --query '[].name' -o tsv)
  for pa_name in $policy_assignments; do
    echo "Deleting: $pa_name (scope: $rg_name)" && az policy assignment delete -n "$pa_name" -g "$rg_name"
  done
}

az_delete_resource_policy_assignments() {
  local resource_id="$1"
  local policy_assignments=$(az policy assignment list --scope "$resource_id" --query '[].name' -o tsv)
  for pa_name in $policy_assignments; do
    echo "Deleting: $pa_name (scope: $rg_name)" && az policy assignment delete -n "$pa_name" --scope "$resource_id"
  done
}

az_set_kv_secret() {
  secret_name=$1
  secret_value=$2
  kv_name=$3

  az keyvault secret set \
    --name "$secret_name" \
    --vault-name "$kv_name" \
    --value "$secret_value" \
    --output none
}

az_import_kv_cert() {
  cert_name=$1
  cert_file=$2
  kv_name=$3

  az keyvault certificate import \
    --name "$cert_name" \
    --vault-name "$kv_name" \
    --f "$cert_file" \
    --output none
}

az_vm_user_update_pwd() {
  rg=$1
  vm_name=$2
  username=$3
  pwd=$4

  az vm user update \
    --resource-group "$rg" \
    --name "$vm_name" \
    --username "$username" \
    --password "$pwd"
}

az_ad_signed_in_user_object_id() {
  az ad signed-in-user show -o tsv --query objectId
}

az_upload_file_to_sta_blob() {
  subscription=$1
  containerName=$2
  staName=$3
  destinationPath=$4
  source=$5

  az storage fs file upload --file-system "$containerName" \
    --account-name "$staName" \
    --path "$destinationPath" \
    --source "$source" \
    --subscription "$subscription" \
    --overwrite
}

az_enable_traffic_manager_endpoint() {
  local traffic_manager_rg=$1
  local traffic_manager_profile_name=$2
  local traffic_manager_endpoint_name=$3

  echo "Enable $traffic_manager_rg/$traffic_manager_profile_name/$traffic_manager_endpoint_name" &&
    az network traffic-manager endpoint update \
      -g "$traffic_manager_rg" \
      --profile-name "$traffic_manager_profile_name" \
      -n "$traffic_manager_endpoint_name" \
      --endpoint-status Enabled \
      --type azureEndpoints
}

az_disable_traffic_manager_endpoint() {
  local traffic_manager_rg=$1
  local traffic_manager_profile_name=$2
  local traffic_manager_endpoint_name=$3

  echo "Disable $traffic_manager_rg/$traffic_manager_profile_name/$traffic_manager_endpoint_name" &&
    az network traffic-manager endpoint update \
      -g "$traffic_manager_rg" \
      --profile-name "$traffic_manager_profile_name" \
      -n "$traffic_manager_endpoint_name" \
      --endpoint-status Disabled \
      --type azureEndpoints
}

az_cosmos_failover_priority_change() {
  local cosmos_rg=$1
  local cosmos_account_name=$2
  local region_1=$3
  local region_2=$4

  echo "az cosmosdb failover-priority-change --resource-group $cosmos_rg --name $cosmos_account_name --failover-policies $region_1 $region_2"
  az cosmosdb failover-priority-change \
    --resource-group "$cosmos_rg" \
    --name "$cosmos_account_name" \
    --failover-policies "$region_1" "$region_2"
}

az_sql_failover_set_primary() {
  local failover_group_name=$1
  local primary_server_rq=$2
  local primary_server_name=$3

  echo "az sql failover-group set-primary --name $failover_group_name --resource-group $primary_server_rq --server $primary_server_name"
  az sql failover-group set-primary \
    --name "$failover_group_name" \
    --resource-group "$primary_server_rq" \
    --server "$primary_server_name"
}