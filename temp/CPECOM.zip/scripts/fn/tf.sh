tf_clean_backend_config() (
  local tf_src=$1

  cd "$tf_src" &&
    rm -f ".terraform.lock.hcl" &&
    rm -rf ".terraform"
)

tf_init() (

  local tf_src=$1
  local env=$2
  local tier=$3
  local subscription_id=$4
  local resource_group_name=$5
  local storage_account_name=$6
  local container_name=$7
  local key="cpecom.$env.$tier.tfstate"

  cd "$tf_src" &&
    terraform init \
      -backend-config="subscription_id=$subscription_id" \
      -backend-config="resource_group_name=$resource_group_name" \
      -backend-config="storage_account_name=$storage_account_name" \
      -backend-config="container_name=$container_name" \
      -backend-config="key=$key"
)

tf_destroy() (
  local rnd_env=$1
  local tf_src=$2
  local tier=$3

  cd "$tf_src" &&
    terraform destroy \
      -var-file="../env/rnd/env-$rnd_env.tfvars" \
      -var-file="../env/rnd/global.tfvars" \
      -var-file="../env/rnd/$tier.tfvars"
)

tf_apply_infra() (
  local rnd_env=$1
  local tf_src=$2
  local tier=$3
  local flags=$4

  cd "$tf_src" &&
    terraform apply \
      -input=false \
      -var-file="../env/rnd/env-$rnd_env.tfvars" \
      -var-file="../env/rnd/global.tfvars" \
      -var-file="../env/rnd/$tier.tfvars" \
      "$flags"
)

tf_apply_application() (
  local tf_src=$1

  cd "$tf_src" &&
    terraform apply \
      -input=false \
      -var-file="env/rnd.tfvars"
)

tf_read_output() (
  local tf_src=$1
  local output_var_name=$2

  local output=$(cd "$tf_src" && terraform output -raw "$output_var_name") &&
    if [ -z "$output" ]; then
      echo "No output value found for $output_var_name from $tf_src"
      exit 1
    fi
  echo "$output"
)
