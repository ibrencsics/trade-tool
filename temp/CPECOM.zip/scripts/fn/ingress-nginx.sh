nginx_create_ns() {
  local namespace=$1
  cat <<EOF | kubectl apply -f -
  kind: Namespace
  apiVersion: v1
  metadata:
    name: "$namespace"
    labels:
      name: "$namespace"
EOF
}

nginx_create_cert_secret() {
    local ingress_nginx_ns=$1
    local cert_private_key_pem_file=$2
    local cert_pem_file=$3

    local private_key_base64=$(base64 -w0 "$cert_private_key_pem_file") &&
    local cert_base64=$(base64 -w0 "$cert_pem_file") &&

    cat <<EOF | kubectl apply -f -
    apiVersion: v1
    kind: Secret
    metadata:
      name: ingress-nginx-cert
      namespace: $ingress_nginx_ns
    type: kubernetes.io/tls
    data:
      tls.key: $private_key_base64
      tls.crt: $cert_base64
EOF
}

nginx_download_cert() {
  local kv_name=$1
  local kv_cert_name=$2

  local cert_pfx_out=$3
  local cert_crt_pem_out=$4
  local cert_key_pem_out=$5

  az keyvault secret download --name "$kv_cert_name" --vault-name "$kv_name" -f "$cert_pfx_out" --encoding base64 &&
  openssl pkcs12 -password pass: -in "$cert_pfx_out" -nocerts -nodes | openssl pkcs8 -nocrypt -out "$cert_key_pem_out" &&
  openssl pkcs12 -password pass: -in "$cert_pfx_out" -nokeys -nodes | openssl x509 -out "$cert_crt_pem_out"
}