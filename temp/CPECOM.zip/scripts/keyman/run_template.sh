#!/usr/bin/env bash

. ../fn/commons_docker.sh

TENANT_ID=b3b09976-7567-445d-b27a-c164bb617670
VM_IDENTITY=5c8fc532-e3cc-43db-bf06-f8d16f44bb1e
ACR_NAME=gdmsstsnonprodcr
KEY_MANAGER_IMAGE=gdmsstsnonprodcr.azurecr.io/gd/cpecom/cpecom-key-manager:1.0.0-SNAPSHOT
CONFIG_NAME=<Enter here the config yaml file name without the extension>

pull_key_manager_image "$VM_IDENTITY" "$ACR_NAME" "$KEY_MANAGER_IMAGE" &&
  run_key_manager "$TENANT_ID" "$CONFIG_NAME" "$KEY_MANAGER_IMAGE" &&
  echo "Done"