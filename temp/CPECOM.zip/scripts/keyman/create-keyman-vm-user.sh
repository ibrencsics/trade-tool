#!/bin/bash -e

. ../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="PLATFORM"

WORK_DIR="keyman-user-secrets"
KV_NAME="kv-gd-platform-keyman"

VM_RG_NAME="rg-platform-keyman"
VM_NAME="vm-platform-keyman"

usage() {
  echo "Usage: ./create-keyman-vm-user.sh <linux-user-name> <optional: AAD user object ID>. E.g. ./create-keyman-vm-user.sh daniel"
}

if [ $# -lt 1 ];
then
	usage
  exit 1
else
  LINUX_USER_NAME=$1
fi

if [ $# -eq 2 ]
then
  AAD_USER_ID=$2
else
  AAD_USER_ID=$(az_ad_signed_in_user_object_id)
fi

az_login "$TENANT_ID" "$SUBSCRIPTION" &&
rm -rf "$WORK_DIR" &&
mkdir "$WORK_DIR" &&
./fn/sync-keyman-vm-user.sh "$WORK_DIR" "$KV_NAME" "$VM_RG_NAME" "$VM_NAME" "$AAD_USER_ID" "$LINUX_USER_NAME" &&
echo "Done"