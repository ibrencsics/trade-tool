#!/usr/bin/env bash

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="PLATFORM"
STA_NAME="staplatformkeyman"
STA_BLOB_CONTAINER_NAME="keymancontainer"

upload_test_keys_to_sta() {
  subscription=$1
  containerName=$2
  staName=$3
  destinationPath=$4
  source=$5

  az storage fs file upload --file-system "$containerName"\
                                  --account-name "$staName"\
                                  --path "$destinationPath"\
                                  --source "$source"\
                                  --subscription "$subscription"\
                                  --overwrite
}

az login --tenant $TENANT_ID &&
upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/fn/commons_docker.sh" "fn/commons_docker.sh" &&
upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/run_template.sh" "run_template.sh" &&

upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/generic/ca/ca_template.json" "generic/ca/ca_template.json" &&
upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/generic/cert/csr_template.json" "generic/cert/csr_template.json" &&
upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/generic/config/create_ca_template.yaml" "generic/config/create_ca_template.yaml" &&
upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/generic/config/create_kw_template.yaml" "generic/config/create_kw_template.yaml" &&
upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/generic/config/sign_cert_template.yaml" "generic/config/sign_cert_template.yaml" &&
upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/generic/keyman/kw_template.json" "generic/keyman/kw_template.json" &&

upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/product/cpecom/config/import_key_template.yaml" "product/cpecom/config/import_key_template.yaml" &&
upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "/keyman/product/cpecom/key/key_template.json" "product/cpecom/key/key_template.json" &&

echo "DONE"