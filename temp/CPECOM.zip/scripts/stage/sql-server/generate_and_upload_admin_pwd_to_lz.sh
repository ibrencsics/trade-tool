#!/usr/bin/env bash

. ../../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
KV_LZ_NAME="kv-gd-cpecstage-367c0b55"
SQL_SERVER_ADMIN_PWD="cpecom-sql-server-admin-pwd"

random_pwd() {
  pwd=$(openssl rand -base64 20)
  echo "$pwd"
}

generate_and_upload_pwd() {
  kv_secret_name=$1
  password=$(random_pwd) &&
    az_set_kv_secret "$kv_secret_name" "$password" "$KV_LZ_NAME"
}

echo "Run pwd gen. ${KV_LZ_NAME}.."
az login --tenant $TENANT_ID &&
  generate_and_upload_pwd $SQL_SERVER_ADMIN_PWD &&
  echo "SQL SERVER ADMIN PWD UPLOADED"