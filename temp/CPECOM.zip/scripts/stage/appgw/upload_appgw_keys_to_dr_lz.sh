#!/usr/bin/env bash

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
KV_LZ_NAME_STAGE="kv-gd-cpecstage-dr-6eddd"

APPGW_CERT_API="appgw-cert-api"
APPGW_CERT_ADMIN="appgw-cert-admin"

APPGW_CERT_API_STAGE_PATH="./cp-ecom-stage.pfx"
APPGW_CERT_ADMIN_STAGE_PATH="./cp-ecom-admin-stage.pfx"

import_kv_cert() {
  cert_name=$1
  cert_file=$2
  kv_name=$3

  az keyvault certificate import \
    --name "$cert_name" \
    --vault-name "$kv_name" \
    --f "$cert_file" \
    --password "<copy here from KeePass>" \
    --output none
}

echo "Run cert upload..."
az login --tenant $TENANT_ID &&
  import_kv_cert "$APPGW_CERT_API" "$APPGW_CERT_API_STAGE_PATH" "$KV_LZ_NAME_STAGE" &&
  echo "STAGE API CERT UPLOADED" &&
  import_kv_cert "$APPGW_CERT_ADMIN" "$APPGW_CERT_ADMIN_STAGE_PATH" "$KV_LZ_NAME_STAGE" &&
  echo "STAGE ADMIN CERT UPLOADED"