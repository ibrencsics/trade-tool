#!/usr/bin/env bash

. ../../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
KV_CERTS_NAME="kv-gd-cpecstage-367c0b55"

AKS_INGRESS_CERT="aks-ingress-cert"
AKS_INGRESS_CERT_PATH="./out/stage-ingress-cpecom-local.pfx"

az login --tenant $TENANT_ID &&
  az_import_kv_cert "$AKS_INGRESS_CERT" "$AKS_INGRESS_CERT_PATH" "$KV_CERTS_NAME" &&
  echo "INGRESS CERT UPLOADED"