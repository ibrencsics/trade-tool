#!/usr/bin/env bash

. ../../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
KV_LZ_NAME="kv-gd-cpecstage-367c0b55"

AKS_INGRESS_ROOT_CA="aks-ingress-rootca"
AKS_INGRESS_ROOT_CA_PATH="./out/stage-rootca.crt"

WORK_DIR="./tmp"

create_work_dir() {
  mkdir -p $WORK_DIR
}

clean_work_dir() {
  rm -rf $WORK_DIR
}

upload_root_ca() {
  secret_name=$1
  secret_file=$2
  kv_name=$3
  base64enc_file="$WORK_DIR/$secret_name"base64

  base64 "$secret_file" >"$base64enc_file" &&
    secret_value=$(cat "$base64enc_file") &&
    az_set_kv_secret "$secret_name" "$secret_value" "$kv_name"
}

az login --tenant $TENANT_ID &&
  create_work_dir &&
  upload_root_ca "$AKS_INGRESS_ROOT_CA" "$AKS_INGRESS_ROOT_CA_PATH" "$KV_LZ_NAME" &&
  echo "INGRESS ROOT CA UPLOADED" &&
  clean_work_dir