#!/bin/bash -e

. ../../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="CPECOM-STAGE"

WORK_DIR="devops-user-secrets"
KV_NAME="kv-gd-cpecstage-367c0b55"

VM_RG_NAME="rg-cpecom-stage-canadacentral-001"
VM_NAME="vm-devops-cpecom-stage-canadacentral-001"

usage() {
  echo "Usage: ./create-devops-vm-user.sh <linux-user-name>. E.g. ./create-devops-vm-user.sh jp"
}

if [ $# -lt 1 ];
then
	usage
  exit 1
else
  LINUX_USER_NAME=$1
fi

az_login "$TENANT_ID" "$SUBSCRIPTION" &&
AAD_USER_ID=$(az_ad_signed_in_user_object_id) &&
rm -rf "$WORK_DIR" &&
mkdir "$WORK_DIR" &&
../../fn/sync-devops-vm-user.sh "$WORK_DIR" "$KV_NAME" "$VM_RG_NAME" "$VM_NAME" "$AAD_USER_ID" "$LINUX_USER_NAME" &&
echo "Done"


