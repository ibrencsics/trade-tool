#!/usr/bin/env bash

. ../../fn/az.sh

RG="rg-cpecom-stage-canadacentral-001"
VM_NAME="vm-devops-cpecom-stage-canadacentral-001"
USER_NAME="devopsadmin"
KV_NAME="kv-gd-cpecstage-367c0b55"

pwd=$(openssl rand -base64 12) &&
az_vm_user_update_pwd "$RG" "$VM_NAME" "$USER_NAME" "$pwd" &&
echo "#### PWD Updated. New pwd $pwd" &&
az_set_kv_secret "devopsvm-devopsadmin-pwd" "$pwd"  "$KV_NAME" &&
echo "#### PWD Stored to Kv"