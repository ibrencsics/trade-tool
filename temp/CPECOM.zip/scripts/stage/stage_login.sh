#!/usr/bin/env bash

. ../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="CPECOM-STAGE"

az_login "$TENANT_ID" "$SUBSCRIPTION"

