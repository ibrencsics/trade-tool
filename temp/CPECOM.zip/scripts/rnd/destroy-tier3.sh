## Src
. ../fn/az.sh
. ../fn/tf.sh

TF_SRC_ROOT="../../terraform/01_infra"

# RnD env
TENANT_ID=ef7739ac-965f-48a7-aa0c-7712934800b7
SUBSCRIPTION=mssts-rnd-cpecom-001

clean_aks_cluster() {
  ../pipelines/clean-aks-cluster.sh
}

clean_tier3_arm_deployments() {
  local tf_src="$TF_SRC_ROOT/tier3"
  local appi_linked_storage_arm_deployment_name=$(tf_read_output "$tf_src" "appi_linked_storage_arm_deployment_name")
  local appi_linked_storage_arm_deployment_rg_name=$(tf_read_output "$tf_src" "tier3_arm_deployments_rg")
  ../pipelines/clean-arm-deployment.sh "$appi_linked_storage_arm_deployment_name" "$appi_linked_storage_arm_deployment_rg_name"
}

destroy_tier() {
  local rnd_env=$1
  local tier=$2
  local tf_src="$TF_SRC_ROOT/$tier"

  echo "#### Tf Destroy tier: $tf_src" &&
    tf_destroy "$rnd_env" "$tf_src" "$tier"
}

# >>> Note: Replace shortcut 'rnd' for  personalized RnD environment (1 occurrence)
RND_ENV="rnd"

#az_login "$TENANT_ID" "$SUBSCRIPTION" &&
clean_aks_cluster
clean_tier3_arm_deployments &&
destroy_tier "$RND_ENV" "tier3"


