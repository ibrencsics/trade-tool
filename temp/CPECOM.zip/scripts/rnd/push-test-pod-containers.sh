#!/bin/bash -e

## Sourced FNs
. ../fn/az.sh
. ../fn/tf.sh

TF_SRC="../../terraform/01_infra_rnd"
TF_OUTPUT_ACR_NAME="acr_name"
TEST_POD_DOCKER_FILE="test-deployments/test-pod/Dockerfile"

CR_NAME=$(tf_read_output "$TF_SRC" "$TF_OUTPUT_ACR_NAME") &&
az_docker_build_push_to_acr "$TEST_POD_DOCKER_FILE" "test-pod" "1.1.0" "$CR_NAME"
