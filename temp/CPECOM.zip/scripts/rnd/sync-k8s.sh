#!/bin/bash -e

. ../fn/k8s.sh
. ../fn/tf.sh

WORK_DIR="tmp"

TF_SRC="../../terraform/"
TF_SRC_AKS="../../terraform/02_aks"
SCRIPT_SRC="../pipelines"
INFRA_OUTPUT_TFVARS_FILE="$TF_SRC_AKS/infra-output.auto.tfvars.json"

TF_STATE_SUBSCRIPTION_ID=b9670b91-6bce-4811-a33a-4bc4d8be3da9
TF_STATE_RG_NAME="rg-cpecom-rnd-terraform"
TF_STATE_STA_NAME="stacpecomterrastor01"
TF_STATE_CONTAINER_NAME="terraformstate"

sync_linkerd_secrets() {
  local lzKvName=$(tf_read_output "$TF_SRC/01_infra/rnd-lz" "kv_lz_name") &&
  local linkerdIssuerCertName="identity-gd-cpecom-rnd-linkerd-cluster-local" &&
  echo "#### Sync linkerd secrets: $lzKvName/$linkerdIssuerCertName" &&
  mkdir -p "$WORK_DIR" &&
    ../pipelines/sync-linkerd-secrets.sh "$WORK_DIR" "$lzKvName" "$linkerdIssuerCertName" "$TF_SRC_AKS"
  syncOk=$?
  rm -rf "$WORK_DIR"

  if [ "$syncOk" -ne 0 ]; then
    echo "Linkerd Secret Sync failed" &&
      exit 1
  fi
}

sync_nginx_secrets() {
  local lzKvName=$(tf_read_output "$TF_SRC/01_infra/rnd-lz" "kv_lz_name") &&
  local ingressNginxCertName="cpecom-nginx-rnd" &&
  echo "#### Sync ingress-nginx secrets: $lzKvName/$linkerdIssuerCertName" &&
  mkdir -p "$WORK_DIR" &&
    ../pipelines/sync-ingress-nginx-secrets.sh "$WORK_DIR" "$lzKvName" "$ingressNginxCertName"
  syncOk=$?
  rm -rf "$WORK_DIR"

  if [ "$syncOk" -ne 0 ]; then
    echo "Nginx Secret Sync failed" &&
      exit 1
  fi
}

generate_k8s_tfvars_file() {
  local k8s_endpoint=$(k8s_read_api_server_endpoint_ip) &&
    echo aks_k8s_api_server_ip="\"$k8s_endpoint\"" > "$TF_SRC_AKS/k8s.auto.tfvars"
}

load_infra_output() {
  local infraOutputKvSecretId=$(tf_read_output "$TF_SRC/01_infra/tier3" "pipeline_output_kv_secret_id")
  echo "#### LoadInfra output: $infraOutputKvSecretId"
  infraOutputBase64=$(az keyvault secret show --id "$infraOutputKvSecretId" --query "value") &&
    echo "$infraOutputBase64" | base64 -d -i >"$INFRA_OUTPUT_TFVARS_FILE"
}

create_cpecom_images_tfvars_file() (
  local acr_name=$(tf_read_output "$TF_SRC/01_infra/rnd-lz" "acr_name")
  cd "$SCRIPT_SRC" &&
    echo "#### Create cpecom images tfvars file with acr: $acr_name" &&
    ./create-cpecom-images-tfvars.sh \
      "$TF_SRC/02_aks" \
      "$acr_name.azurecr.io" \
      "gd/cpecom/cpecom-server-db-flyway-backend:1.1.0" \
      "gd/cpecom/cpecom-server-db-flyway-metadata:1.1.0" \
      "gd/cpecom/cpecom-server-bulk:1.1.0" \
      "gd/cpecom/cpecom-server-core:1.1.0" \
      "gd/cpecom/cpecom-server-crypto:1.1.0" \
      "gd/cpecom/cpecom-server-custgw:1.1.0" \
      "gd/cpecom/cpecom-server-metadata:1.1.0" \
      "gd/cpecom/cpecom-server-transact:1.1.0" \
      "gd/cpecom/cpecom-server-tspgw:1.1.0" \
      "gd/cpecom/cpecom-server-admin:1.1.0"
)

sync_k8s() {
  local rnd_env=$1
  local tf_src="$TF_SRC/02_aks"
  echo "#### Tf Init: $tf_src" &&
    tf_clean_backend_config "$tf_src" &&
    tf_init "$tf_src" \
      "$rnd_env" \
      "application" \
      "$TF_STATE_SUBSCRIPTION_ID" \
      "$TF_STATE_RG_NAME" \
      "$TF_STATE_STA_NAME" \
      "$TF_STATE_CONTAINER_NAME" &&
    echo "#### Tf Apply tier: $tf_src" &&
    tf_apply_application "$tf_src"
}

# >>> Note: Replace shortcut 'rnd' for  personalized RnD environment (1 occurrence)
RND_ENV="rnd"

echo "## Sync CPECOM RND Application.." &&
  echo "### Sync linkerd secrets" &&
  sync_linkerd_secrets &&
  echo "### Sync ingress nginx secrets" &&
  sync_nginx_secrets &&
  echo "### Generate K8s Tf generate_k8s_tfvars_file" &&
  generate_k8s_tfvars_file &&
  echo "### Load Infra output" &&
  load_infra_output &&
  echo "### Create cpecom images tfvars" &&
  create_cpecom_images_tfvars_file &&
  echo "### Sync 02_aks" &&
  sync_k8s "$RND_ENV" &&
  echo "Done"
