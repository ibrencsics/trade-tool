## Src
. ../fn/az.sh
. ../fn/tf.sh

SUBSCRIPTION=mssts-rnd-cpecom-001
WORK_DIR="tmp"
TEST_KEYS_PATH="../../../cpecom-testing/cpecom-testkeys/src/main/resources/key/"
KEY_MANAGER_STA_PATH="key-manager/key.zip"
TF_SRC_ROOT="../../terraform/01_infra"

upload_test_keys() (
  local staName=$(tf_read_output "$TF_SRC_ROOT/tier3" "devops_sta_name")
  local containerName=$(tf_read_output "$TF_SRC_ROOT/tier3" "devops_container_name")

  mkdir -p $WORK_DIR &&
    cp -rf "$TEST_KEYS_PATH" "$WORK_DIR/key" &&
    cd "$WORK_DIR" &&
    zip -r "key.zip" "key" &&
    echo "#### Upload $WORK_DIR/key.zip to $staName/$containerName" &&
    az_upload_file_to_sta_blob "$SUBSCRIPTION" "$containerName" "$staName" "$KEY_MANAGER_STA_PATH" "key.zip" &&
    rm -rf $WORK_DIR
)

echo "## Upload test-keys" &&
  upload_test_keys &&
  echo "## Done"
