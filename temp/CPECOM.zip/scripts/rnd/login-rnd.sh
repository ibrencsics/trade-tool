#!/bin/bash -e

. ../fn/az.sh

TENANT_ID=ef7739ac-965f-48a7-aa0c-7712934800b7
SUBSCRIPTION=mssts-rnd-cpecom-001

az_login "$TENANT_ID" "$SUBSCRIPTION"