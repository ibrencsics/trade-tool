#!/bin/bash -e

# Sourced FNs
. ../fn/az.sh
. ../fn/tf.sh

# >>> Note: Replace shortcut 'rnd' for  personalized RnD environment (1 occurrence)
RND_ENV="rnd"
INSTANCE="001"

# Env
TENANT_ID=ef7739ac-965f-48a7-aa0c-7712934800b7
SUBSCRIPTION=mssts-rnd-cpecom-001

# RGs
RG_LZ_NAME="rg-lz-cpecom-$RND_ENV-westeurope-$INSTANCE"
RG_SECRETS_NAME="rg-secrets-cpecom-$RND_ENV-westeurope-$INSTANCE"
RG_DATA_STORAGE_NAME="rg-cpecom-$RND_ENV-data-storage"
RG_NAME="rg-cpecom-$RND_ENV-westeurope-$INSTANCE"

# KVs
KV_LZ_NAME="kv-lz-cpecom-$RND_ENV"
KV_KEY_MAN="kv-keyman-cpecom-$RND_ENV"
KV_BE_NAME="kv-be-cpecom-$RND_ENV"
KV_GW_NAME="kv-gw-cpecom-$RND_ENV"
KV_CRYPTO_NAME="kv-crypto-cpecom-$RND_ENV"
KV_PIPELINE_NAME="kv-tf-cpecom-$RND_ENV-we"

purge_kvs() {
  az_kv_purge "$KV_LZ_NAME" &&
  az_kv_purge "$KV_KEY_MAN" &&
  az_kv_purge "$KV_BE_NAME" &&
  az_kv_purge "$KV_GW_NAME" &&
  az_kv_purge "$KV_CRYPTO_NAME" &&
  az_kv_purge "$KV_PIPELINE_NAME"
}

echo "## Login $SUBSCRIPTION" &&
az_login "$TENANT_ID" "$SUBSCRIPTION" &&
read -r -p "RGs: $RG_NAME, $RG_SECRETS_NAME, $RG_LZ_NAME, $RG_DATA_STORAGE_NAME in subscription $SUBSCRIPTION will be destroyed. Press enter to continue." &&
echo "## Delete policy assignments from: $RG_NAME" &&
az_delete_rg_policy_assignments "$RG_NAME" &&
echo "## Delete rg: $RG_NAME"
az group delete --yes -g "$RG_NAME" &&
echo "## Delete rg: $RG_SECRETS_NAME"
az group delete --yes -g "$RG_SECRETS_NAME" &&
echo "## Delete rg: $RG_DATA_STORAGE_NAME"
az group delete --yes -g "$RG_DATA_STORAGE_NAME" &&
echo "## Delete rg: $RG_LZ_NAME"
az group delete --yes -g "$RG_LZ_NAME" &&
echo "## Purge KeyVaults" &&
purge_kvs &&
echo "## DONE"
