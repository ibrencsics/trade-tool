#!/bin/bash -e

. ../../fn/az.sh

TENANT_ID="ef7739ac-965f-48a7-aa0c-7712934800b7"
SUBSCRIPTION="mssts-rnd-cpecom-001"

WORK_DIR="devops-user-secrets"

# >>> Note: Replace shortcut 'rnd' for  personalized RnD environment (3 occurrences)
KV_NAME="kv-infra-cpecom-rnd"
VM_RG_NAME="rg-cpecom-rnd-westeurope-001"
VM_NAME="vm-devops-cpecom-rnd-westeurope-001"

usage() {
  echo "Usage: ./create-devops-vm-user.sh <linux-user-name>. E.g. ./create-devops-vm-user.sh jp"
}

if [ $# -lt 1 ];
then
	usage
  exit 1
else
  LINUX_USER_NAME=$1
fi

az_login "$TENANT_ID" "$SUBSCRIPTION" &&
AAD_USER_ID=$(az_ad_signed_in_user_object_id) &&
rm -rf "$WORK_DIR" &&
mkdir "$WORK_DIR" &&
../../fn/sync-devops-vm-user.sh "$WORK_DIR" "$KV_NAME" "$VM_RG_NAME" "$VM_NAME" "$AAD_USER_ID" "$LINUX_USER_NAME" &&
echo "Done"


