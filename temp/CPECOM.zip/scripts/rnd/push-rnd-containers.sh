#!/bin/bash -e

## Sourced FNs
. ../fn/az.sh
. ../fn/tf.sh

SRC_PATH="../../../"
TF_SRC="../../terraform/01_infra/rnd-lz"
TF_OUTPUT_ACR_NAME="acr_name"

# Application Paths
FLYWAY_BE="$SRC_PATH"cpecom-server/cpecom-server-db/cpecom-server-db-flyway-backend
FLYWAY_METADATA="$SRC_PATH"cpecom-server/cpecom-server-db/cpecom-server-db-flyway-metadata
FLYWAY_BE_CLEAN="$SRC_PATH"cpecom-server/cpecom-server-db/cpecom-server-db-flyway-backend-clean
FLYWAY_METADATA_CLEAN="$SRC_PATH"cpecom-server/cpecom-server-db/cpecom-server-db-flyway-metadata-clean
CORE="$SRC_PATH"cpecom-server/cpecom-server-core
TSPGW="$SRC_PATH"cpecom-server/cpecom-server-tspgw
BULK="$SRC_PATH"cpecom-server/cpecom-server-bulk
METADATA="$SRC_PATH"cpecom-server/cpecom-server-metadata
CUSTGW="$SRC_PATH"cpecom-server/cpecom-server-custgw
CRYPTO="$SRC_PATH"cpecom-server/cpecom-server-crypto
TRANSACT="$SRC_PATH"cpecom-server/cpecom-server-transact
ADMIN="$SRC_PATH"cpecom-server/cpecom-server-admin

# Tester paths
LOAD_TESTER="$SRC_PATH"cpecom-testing/cpecom-azure-test
TSP_MOCK="$SRC_PATH"cpecom-testing/cpecom-mock-service
KEY_MANAGER="$SRC_PATH"cpecom-testing/cpecom-key-manager
CLOUD_TEST_RUNNER="$SRC_PATH"cpecom-testing/cpecom-cloud-test-runner

CR_NAME=$(tf_read_output "$TF_SRC" "$TF_OUTPUT_ACR_NAME")

push_db_jobs() {
  az_jib_push_to_acr $FLYWAY_BE "$CR_NAME" &&
    az_jib_push_to_acr $FLYWAY_METADATA "$CR_NAME" &&
    az_jib_push_to_acr $FLYWAY_BE_CLEAN "$CR_NAME" &&
    az_jib_push_to_acr $FLYWAY_METADATA_CLEAN "$CR_NAME" &&
    echo "db jobs pushed to $CR_NAME"
}

push_workloads() {
  az_jib_push_to_acr $CRYPTO "$CR_NAME" &&
  az_jib_push_to_acr $CORE "$CR_NAME" &&
  az_jib_push_to_acr $TSPGW "$CR_NAME" &&
  az_jib_push_to_acr $CUSTGW "$CR_NAME" &&
  az_jib_push_to_acr $METADATA "$CR_NAME" &&
  az_jib_push_to_acr $TRANSACT "$CR_NAME" &&
  az_jib_push_to_acr $BULK "$CR_NAME" &&
  az_jib_push_to_acr $ADMIN "$CR_NAME" &&
  echo "workloads pushed to $CR_NAME"
}

push_test_containers() {
  az_jib_push_to_acr $CLOUD_TEST_RUNNER "$CR_NAME" &&
  az_jib_push_to_acr $LOAD_TESTER "$CR_NAME" &&
  az_jib_push_to_acr $TSP_MOCK "$CR_NAME" &&
  az_jib_push_to_acr $KEY_MANAGER "$CR_NAME" &&
  echo "test containers pushed to $CR_NAME"
}

echo "Push container to $CR_NAME" &&
  echo "Push test containers"
  push_test_containers &&
  echo "Push db-jobs.." &&
  push_db_jobs &&
  echo "Push workloads.." &&
  push_workloads
  echo "Done"