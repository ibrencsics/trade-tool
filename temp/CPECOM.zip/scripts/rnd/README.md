## CPECOM Infra - R&D

---
**NOTE:**
These instructions are only for **R&D** environment. 
---

### Provision cpecom rnd infra

0. NOTES
   
    1. Manual step Login to Azure Portal

       If provisioning is skipped, a manual login is needed.
          ```
          $ az login --tenant ef7739ac-965f-48a7-aa0c-7712934800b7 && az account set --subscription mssts-rnd-cpecom-001 
          ```

    2. Personalized RnD environment      
       - Variable values for personalized environment are stored in ``terraform/01_infra/env/rnd/env-<env_name>.tfvars``.
       This file can (and probably should) be added to version control. 
       - When using personalized env, name of that environment must be defined to following files:
         - scripts/rnd/sync-infra.sh`: ``RND_ENV="<env_name>"`` (NOTE: <env_name> must match with ``terraform/01_infra/env/rnd/env-<env_name>.tfvars``)
         - script/rnd/sync-k8s.sh: ``RND_ENV="<env_name>"`` (NOTE: <env_name> must match with ``terraform/01_infra/env/rnd/env-<env_name>.tfvars``)
         - scripts/rnd/destroy.sh: ``RND_ENV="<env_name>"`` (NOTE: <env_name> must match with ``terraform/01_infra/env/rnd/env-<env_name>.tfvars``)
     
1. Provision / Synchronizing infra (01)
   ```
   $ cd scripts/rnd
   $ ./sync-infra.sh
   ```

2. Push containers
   ```
   $ cd scripts/rnd
   $ ./push-rnd-containers.sh
   ```

3. Upload test-keys to Storage Account
    ```
    $ cd scripts/rnd
    $ ./upload_test_keys.sh
    ```

4. Manual step - Create `DB users` and upload `test-keys` (NOTE: Only needed if infra does not yet exist)
    * Login to Azure Portal, locate newly created devops-vm and login via Bastion (ssh key from landing zone keyvault)
    * Execute create-db-users scripts (Password for db_admin can be found from landing zone keyvault)
      ```
      $ az login --tenant ef7739ac-965f-48a7-aa0c-7712934800b7 && az account set --subscription mssts-rnd-cpecom-001 
      $ cd /deployment/db-users
      $ ./create_db_users.sh db_admin     
      ```
    * Execute import_app_keys script
      ```
      $ cd /deployment/key-manager
      $ ./import_app_keys.sh
      # Complete MFA when requested by KeyManager (2 times)
      ```

5. Provision aks cluster (02)
   ```
   $ cd scripts/rnd
   $ ./sync-k8s.sh 
   ```

6. Connect lens (Optional)

   * Copy content of file provision/<aks-name>.lens-credentials
   to clip board
   * Open Lens & Add Cluster
   * Paste Kubeconfig
   * Define proxy: http://cws.accounts.intern:8081

7. Verify provisioning
   * Execute test request (appgw -> ingress-nginx -> custgw)
   ```
   # >>> Note: Replace shortcut 'rnd' for  personalized RnD environment (2 occurrences)
   APPGW_IP=$(az network public-ip show -g rg-cpecom-rnd-westeurope-001 -n pip-appgw-cpecom-rnd-westeurope-001 --query ipAddress -o tsv) && curl -i -k "https://$APPGW_IP/api/not-found"
   
   # Should return
   HTTP/1.1 200 Connection established
   HTTP/1.1 404 Not Found
   Date: Thu, 16 Dec 2021 08:02:31 GMT
   Vary: Origin
   Vary: Access-Control-Request-Method
   Vary: Access-Control-Request-Headers
   Request-Context: appId=b1d0727f-38b3-4aef-8fcf-3f8bb117a4cc
   Strict-Transport-Security: max-age=15724800; includeSubDomains
   Content-Length: 30
   Content-Type: text/plain;charset=UTF-8
   Via: 1.1 web-gate2b.accounts.intern:3128 (Cisco-WSA/11.5.3-016)
   Connection: keep-alive
   
   Path: /api/not-found not found
   ```

### Using terraform commands

After running ``./sripts/rnd/sync_infra.sh`` and ``./scripts/rnd/sync_k8s.sh`` terraform commands can be executed directly
to for each tier. In that case we have to define where ``tfvars`` files for that tier are located. E.g. for infra tier3 following
command can be user:

```
$ cd terraform/01_infra/tier1
$ terraform plan -var-file="../env/rnd/global.tfvars" -var-file="../env/rnd/tier1.tfvars"
```

For ``02_aks`` the command would be following:

```
$ cd terraform/02_aks
$ terraform plan -var-file="env/rnd.tfvars"
```

### Destroy RND Tier-3
 ```
$ cd scripts/rnd
$ ./destroy-tier3.sh 
 ```

### Destroy RND Infra gracefully
```
$ cd scripts/rnd
$ ./destroy.sh
```

### Destroy RND Infra
 ```
$ cd scripts/rnd
$ ./force-destroy.sh    
 ```

### Known issues
* When running sync scripts behind company proxy, terraform timeouts quite often when trying to download plugins. In that case re-running the script typically helps
* When using ``scripts/rnd/destroy.sh`` diagnostics settings for appgw will be left behind. For, at the moment unknown reason az cli is unable to find and delete those settings.
When new environment is created after deleting existing one, tier3 will fail because the resource already exists. Simplest solution is to navigate
to appgw with azure portal and delete the corresponding diagnostic settings before re-running the script.
* There seem to be some random startup issues with linkerd when installation is done to a fresh aks cluster. Typically, when this issue occurs,
linkerd pods remain in pending state. In this case, helm deployment will time out, but linkerd pods will remain in terminating state forever.
Workaround is to first run ``kubectl delete po <linkerd-po> --force`` for each pod which is left in linkerd namespace, and then re-run the script.