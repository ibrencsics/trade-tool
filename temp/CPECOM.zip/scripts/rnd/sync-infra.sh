#!/bin/bash -e

## Src
. ../fn/az.sh
. ../fn/tf.sh

# RnD env
TENANT_ID=ef7739ac-965f-48a7-aa0c-7712934800b7
SUBSCRIPTION=mssts-rnd-cpecom-001

# Terraform state storage
TF_STATE_SUBSCRIPTION_ID=b9670b91-6bce-4811-a33a-4bc4d8be3da9
TF_STATE_RG_NAME="rg-cpecom-rnd-terraform"
TF_STATE_STA_NAME="stacpecomterrastor01"
TF_STATE_CONTAINER_NAME="terraformstate"

# Terraform sources
TF_SRC_ROOT="../../terraform/01_infra"

# Conditional for forcing terraform output generation from rng-lz (Needed for first sync for an existing env)
GENERATE_LZ_OUTPUTS=true

sync_tier() {
  local rnd_env=$1
  local tier=$2
  local tf_flags=$3
  local tf_src="$TF_SRC_ROOT/$tier"

  echo "#### Tf Init tier: $tf_src" &&
    tf_clean_backend_config "$tf_src" &&
    tf_init "$tf_src" \
      "$rnd_env" \
      "$tier" \
      "$TF_STATE_SUBSCRIPTION_ID" \
      "$TF_STATE_RG_NAME" \
      "$TF_STATE_STA_NAME" \
      "$TF_STATE_CONTAINER_NAME" &&
    echo "#### Tf Apply tier: $tf_src" &&
    tf_apply_infra "$rnd_env" "$tf_src" "$tier" "$tf_flags"
}

connect_aks_cluster() {
  local env=$1
  local aks_name="aks-cpecom-$env-001"
  local aks_rg_name="rg-cpecom-$env-westeurope-001"
  az_aks_configure_kubectl "$aks_name" "$aks_rg_name" && az_aks_credentials_for_lens "$aks_name" "$aks_rg_name"
}

# >>> Note: Replace shortcut 'rnd' for  personalized RnD environment (1 occurrence)
RND_ENV="rnd"

echo "## Sync CPECOM RND Infra.." &&
  echo "### az login rnd" &&
  az_login "$TENANT_ID" "$SUBSCRIPTION" &&
  echo "### Sync lz rnd" &&
  sync_tier "$RND_ENV" "rnd-lz" "-var=enforce_lz_output_generate=$GENERATE_LZ_OUTPUTS" &&
  echo "### Sync tier1 rnd" &&
  sync_tier "$RND_ENV" "tier1" &&
  echo "### Sync tier2 rnd" &&
  sync_tier "$RND_ENV" "tier2" &&
  echo "### Sync tier3 rnd" &&
  sync_tier "$RND_ENV" "tier3" &&
  echo "### Connect AKS cluster" &&
  connect_aks_cluster "$RND_ENV" &&
  echo "## Ok"
