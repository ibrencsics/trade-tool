#!/usr/bin/env bash
TEST_RUN_ID="4"
VM_RG_NAME="RG-CPECOM-RND-WESTEUROPE-001"
VM_NAME="vm-test-cpecom-rnd-westeurope-001"

STA_NAME="stacpecomrndwe"
STA_CONTAINER_NAME="test-results"
OUTPUT_STA_BLOB_URI="https://$STA_NAME.blob.core.windows.net/$STA_CONTAINER_NAME/$TEST_RUN_ID-test-output.json"
ERROR_STA_BLOB_URI="https://$STA_NAME.blob.core.windows.net/$STA_CONTAINER_NAME/$TEST_RUN_ID-error-output.txt"
STA_CONTAINER_BLOB_NAME="$TEST_RUN_ID-test-output.json"
STA_CONTAINER_BLOB_ERROR_NAME="$TEST_RUN_ID-error-output.txt"

TSP_MOCK_IMAGE="gd/cpecom/cpecom-mock-service:1.1.0"
CLOUD_TEST_RUNNER_IMAGE="gd/cpecom/cpecom-cloud-test-runner:1.1.0"

TEST_PROFILE_NAME="rnd-appgw"
TEST_SUITE="SMOKE_TESTS_SUITE"
TARGET_TSP="mock"
TEST_CUSTOMER="DIRECT_MERCHANT_AZURE"
TEST_TAGS_TO_INCLUDE="cloud-test"
TEST_TAGS_TO_EXCLUDE="slow"

OUTPUT_DIR="test-results"
OUTPUT_FILE_PATH="$OUTPUT_DIR/$TEST_RUN_ID.json"
OUTPUT_FILE_ERROR_PATH="$OUTPUT_DIR/$TEST_RUN_ID-error-output.txt"

mkdir -p "$OUTPUT_DIR"

show_test_results() {
  printf "\n## Stop TspMock output:\n"
  cat "$OUTPUT_FILE_PATH" | jq -r .stopTspMockOutput | base64 --decode

  printf "\n## Start TspMock output:\n"
  cat "$OUTPUT_FILE_PATH" | jq -r .startTspMockOutput | base64 --decode

  printf "\n## Acr login output:\n"
  cat "$OUTPUT_FILE_PATH" | jq -r .acrLoginOutput | base64 --decode

  printf "\n## Pull image output:\n"
  cat "$OUTPUT_FILE_PATH" | jq -r .pullImageOutput | base64 --decode

  printf "\n## CloudTestRunner output:\n"
  cat "$OUTPUT_FILE_PATH" | jq -r .testRunnerOutput | base64 --decode
}

echo "## Run cloud test runner.."
../pipelines/run-cloud-test-runner.sh \
  "$VM_RG_NAME" \
  "$VM_NAME" \
  "$OUTPUT_STA_BLOB_URI" \
  "$ERROR_STA_BLOB_URI" \
  "$TSP_MOCK_IMAGE" \
  "$CLOUD_TEST_RUNNER_IMAGE" \
  "$TEST_PROFILE_NAME" \
  "$TEST_SUITE" \
  "$TEST_CUSTOMER" \
  "$TARGET_TSP" \
  "$TEST_TAGS_TO_INCLUDE" \
  "$TEST_TAGS_TO_EXCLUDE"

echo "## Download test results (stdout)" &&
  ../pipelines/download-cloud-test-runner-output.sh \
    "$STA_NAME" \
    "$STA_CONTAINER_NAME" \
    "$STA_CONTAINER_BLOB_NAME" \
    "$OUTPUT_FILE_PATH"

echo "## Download test results (stderr)" &&
  ../pipelines/download-cloud-test-runner-output.sh \
    "$STA_NAME" \
    "$STA_CONTAINER_NAME" \
    "$STA_CONTAINER_BLOB_ERROR_NAME" \
    "$OUTPUT_FILE_ERROR_PATH"

show_test_results