#!/usr/bin/env bash

TEST_KEYS_PATH="../../../cpecom-testing/cpecom-testkeys/src/main/resources/key/"
WORK_DIR="./tmp"

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="CPECOM-PAT"
STA_NAME="sta585e1cea9f5d3b16"
STA_BLOB_CONTAINER_NAME="devopscontainer"
KEY_MANAGER_STA_PATH="key-manager/key.zip"

create_work_dir() {
  mkdir -p $WORK_DIR
}

clean_work_dir() {
  rm -rf $WORK_DIR
}

upload_test_keys_to_sta() {
  subscription=$1
  containerName=$2
  staName=$3
  destinationPath=$4
  source=$5

  az storage fs file upload --file-system "$containerName"\
                                  --account-name "$staName"\
                                  --path "$destinationPath"\
                                  --source "$source"\
                                  --subscription "$subscription"\
                                  --overwrite
}


# Copy keys
create_work_dir
cp -rf "$TEST_KEYS_PATH" "$WORK_DIR/key"
cd $WORK_DIR &&
zip -r "key.zip" "key" &&
az login --tenant $TENANT_ID &&
upload_test_keys_to_sta "$SUBSCRIPTION" "$STA_BLOB_CONTAINER_NAME" "$STA_NAME" "$KEY_MANAGER_STA_PATH" "key.zip" &&
clean_work_dir &&
echo "DONE"