#!/bin/bash

create_ca() {
  CA_NAME=$1

  cat >out/"$CA_NAME".conf <<EOF
  [req]
  default_bits  = 4096
  distinguished_name = req_distinguished_name
  x509_extensions = v3_req
  prompt = no

  [req_distinguished_name]
  countryName = DE
  stateOrProvinceName = Bavaria
  localityName = Munich
  organizationName = Giesecke+Devrient GmbH
  organizationalUnitName = MSSTS
  commonName = "$CA_NAME".gi-de.com

  [v3_req]
  basicConstraints=CA:TRUE
EOF

  openssl genrsa -des3 -out out/"$CA_NAME".key -passout pass: 2048
  openssl req -x509 -new -key out/"$CA_NAME".key -sha256 -days 1825 -out out/"$CA_NAME".crt -config out/"$CA_NAME".conf -passin pass:
  rm out/"$CA_NAME".conf
}

create_cert() {
  CERT_NAME=$1
  CA_NAME=$2
  COMMON_NAME=$3

  cat >out/"$CERT_NAME".conf <<EOF
    [req]
    default_bits  = 4096
    distinguished_name = req_distinguished_name
    x509_extensions = v3_req
    prompt = no

    [req_distinguished_name]
    countryName = DE
    stateOrProvinceName = Bavaria
    localityName = Munich
    organizationName = Giesecke+Devrient GmbH
    commonName = $COMMON_NAME

    [v3_req]
    basicConstraints = CA:FALSE
    keyUsage = keyAgreement, keyEncipherment, digitalSignature
    extendedKeyUsage = serverAuth
EOF

  CERT=out/"$CERT_NAME".crt
  KEY_PEM=out/"$CERT_NAME".key
  CERT_PFX=out/"$CERT_NAME".pfx

  openssl req -new\
   -config out/"$CERT_NAME".conf\
   -keyout out/"$CERT_NAME".key\
   -out out/"$CERT_NAME".csr

  openssl x509 -req\
   -extensions v3_req -extfile out/"$CERT_NAME".conf\
   -in out/"$CERT_NAME".csr\
   -CA out/"$CA_NAME".crt\
   -CAkey out/"$CA_NAME".key\
   -CAcreateserial -out out/"$CERT_NAME".crt\
   -days 3650\
   -sha256\
   -passin pass:

  openssl pkcs12 -export -in "$CERT" -inkey "$KEY_PEM" -out "$CERT_PFX" &&

  echo "ALL DONE"
}

CA_NAME=pat-rootca

# Ingress NGINX PAT
CERT_NAME_NGINX=pat-ingress-cpecom-local
COMMON_NAME_NGINX=pat.ingress.cpecom.local

mkdir -p out

# Generate root CA
create_ca "$CA_NAME"

# Generate Cert for NGINX
create_cert "$CERT_NAME_NGINX" "$CA_NAME" "$COMMON_NAME_NGINX"