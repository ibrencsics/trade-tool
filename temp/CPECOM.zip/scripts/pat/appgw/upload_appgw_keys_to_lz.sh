#!/usr/bin/env bash

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"

KV_LZ_NAME_PAT="kv-gd-cpecpat-a6ed1eb5"

APPGW_CERT_API="appgw-cert-api"
APPGW_CERT_ADMIN="appgw-cert-admin"

APPGW_CERT_API_PAT_PATH="./cp-ecom-pat.pfx"
APPGW_CERT_ADMIN_PAT_PATH="./cp-ecom-admin-pat.pfx"

import_kv_cert() {
  cert_name=$1
  cert_file=$2
  kv_name=$3

  az keyvault certificate import \
    --name "$cert_name" \
    --vault-name "$kv_name" \
    --f "$cert_file" \
    --password "<copy here from KeePass>" \
    --output none
}

echo "Run cert upload..."
az login --tenant $TENANT_ID &&
  import_kv_cert "$APPGW_CERT_API" "$APPGW_CERT_API_PAT_PATH" "$KV_LZ_NAME_PAT" &&
  echo "PAT API CERT UPLOADED" &&
  import_kv_cert "$APPGW_CERT_ADMIN" "$APPGW_CERT_ADMIN_PAT_PATH" "$KV_LZ_NAME_PAT" &&
  echo "PAT ADMIN CERT UPLOADED"