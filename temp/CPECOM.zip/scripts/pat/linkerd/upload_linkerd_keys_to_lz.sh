#!/bin/bash

# Sourced FNs
. ../../fn/linkerd-dev.sh
. ../../fn/az.sh

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="CPECOM-PAT"
KV_NAME="kv-gd-cpecpat-a6ed1eb5"
ISSUER_PFX="linkerd-certs/issuer.pfx"

az_login "$TENANT_ID" "$SUBSCRIPTION" &&
  az_import_kv_cert identity-gd-cpecom-pat-linkerd-cluster-local "$ISSUER_PFX" $KV_NAME &&
  echo "### Done"