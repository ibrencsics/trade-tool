#!/usr/bin/env bash

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
KV_LZ_NAME="kv-gd-cpecdev-fbe15923"

APPGW_CERT_API="appgw-cert-api"
APPGW_CERT_ADMIN="appgw-cert-admin"

APPGW_CERT_API_DEV_PATH="./cp-ecom-dev.pfx"
APPGW_CERT_ADMIN_DEV_PATH="./cp-ecom-admin-dev.pfx"

import_kv_cert() {
  cert_name=$1
  cert_file=$2
  kv_name=$3

  az keyvault certificate import \
    --name "$cert_name" \
    --vault-name "$kv_name" \
    --f "$cert_file" \
    --password "<copy here from KeePass>" \
    --output none
}

echo "Run cert upload..."
az login --tenant $TENANT_ID &&
  import_kv_cert "$APPGW_CERT_API" "$APPGW_CERT_API_DEV_PATH" "$KV_LZ_NAME" &&
  echo "DEV API CERT UPLOADED" &&
  import_kv_cert "$APPGW_CERT_ADMIN" "$APPGW_CERT_ADMIN_DEV_PATH" "$KV_LZ_NAME" &&
  echo "DEV ADMIN CERT UPLOADED"