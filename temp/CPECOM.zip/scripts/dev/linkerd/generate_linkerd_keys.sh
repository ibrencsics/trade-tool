#!/bin/bash

. ../../fn/linkerd-dev.sh

OUTPUT="linkerd-certs"

CA_PRIVATE_KEY="$OUTPUT/ca-private.pem"
CA_PUBLIC_KEY="$OUTPUT/ca-public.pem"
CA_CRT="$OUTPUT/ca.crt"
OPEN_SSL_CONF="$OUTPUT/open-ssl.conf"
CA_CONF="$OUTPUT/ca.conf"
ISSUER_CONF="$OUTPUT/issuer.conf"
ISSUER_PRIVATE_KEY="$OUTPUT/issuer-private.pem"
ISSUER_PUBLIC_KEY="$OUTPUT/issuer-public.pem"
ISSUER_CSR="$OUTPUT/issuer.csr"
ISSUER_CRT="$OUTPUT/issuer.crt"
ISSUER_PFX="$OUTPUT/issuer.pfx"

mkdir -p $OUTPUT &&
echo "#### Generate CA Certs" &&
linkerd_dev_create_open_ssl_conf "$OPEN_SSL_CONF" &&
linkerd_dev_create_ca_conf "root.gd.cpecom.dev.linkerd.cluster.local" "$CA_CONF" &&
linkerd_dev_create_ca_key_and_cert 365 "$CA_CONF" $CA_PRIVATE_KEY $CA_PUBLIC_KEY $CA_CRT &&
echo "#### Generate Issuer Certs" &&
linkerd_dev_create_issuer_conf "identity.gd.cpecom.dev.linkerd.cluster.local" "$ISSUER_CONF" &&
linkerd_dev_create_issuer_key_and_cert 180 "$OPEN_SSL_CONF" "$ISSUER_CONF" "$CA_PRIVATE_KEY" "$CA_CRT" "$ISSUER_PRIVATE_KEY" "$ISSUER_PUBLIC_KEY" "$ISSUER_CSR" "$ISSUER_CRT" &&
echo "#### Create Issuer pfx" &&
linkerd_dev_issuer_cert_as_pfx "$ISSUER_CRT" "$ISSUER_PRIVATE_KEY" "$CA_CRT" "$ISSUER_PFX" &&
echo "#### Done"

