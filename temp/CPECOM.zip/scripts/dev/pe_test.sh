# script to test Private Endpoint NSG rules
# does not work properly for SQL and Cosmos from peered networks. only when using IP addresses.

echo -e "\n\n--- Test LZ Key Vault"
curl -k --connect-timeout 3 https://kv-gd-cpecdev-fbe15923.vault.azure.net

echo -e "\n\n--- Test Crypto Key Vault"
curl -k --connect-timeout 3 https://kv-crypto-cpecom-dev.vault.azure.net

echo -e "\n\n--- Test GW Key Vault"
curl -k --connect-timeout 3 https://kv-crypto-cpecom-dev.vault.azure.net

echo -e "\n\n--- Test BE Key Vault"
curl -k --connect-timeout 3 https://kv-crypto-cpecom-dev.vault.azure.net

echo -e "\n\n--- Test SQL"
curl -k --connect-timeout 3 https://sql-cpecom-dev-canadacentral-001.database.windows.net

echo -e "\n\n--- Test EH"
curl -k --connect-timeout 3 https://evhns-gd-platform-splunk.servicebus.windows.net

echo -e "\n\n--- Test Redis"
curl -k --connect-timeout 3 https://redis-cpecom-dev-canadacentral-001.redis.cache.windows.net #:6380

echo -e "\n\n--- Test STA blob"
curl -k --connect-timeout 3 https://stacpecomdevcc.blob.core.windows.net

echo -e "\n\n--- Test STA queue"
curl -k --connect-timeout 3 https://stacpecomdevcc.queue.core.windows.net

echo -e "\n\n--- Test Cosmos"
curl -k --connect-timeout 3 https://cosmos-cpecom-dev-canadacentral-001.documents.azure.com

echo -e "\n\n--- Test Cosmos"
curl -k --connect-timeout 3 https://cosmos-cpecom-dev-canadacentral-001-canadacentral.documents.azure.com

echo -e "\n\n--- ACR non PROD"
curl -k --connect-timeout 3 https://gdmsstsnonprodcr.azurecr.io

echo -e "\n\n--- ACR non PROD"
curl -k --connect-timeout 3 https://gdmsstsnonprodcr.canadacentral.data.azurecr.io