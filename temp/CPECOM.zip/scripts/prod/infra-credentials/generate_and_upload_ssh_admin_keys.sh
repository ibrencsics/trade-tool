#!/usr/bin/env bash

KV_LZ_NAME="kv-gd-cpecprod-e3652f7e"

WORK_DIR="./tmp"

AKS_ADMIN_SSH="aks-admin-ssh"
DEVOPS_ADMIN_SSH="devops-admin-ssh"

create_work_dir() {
  mkdir -p $WORK_DIR
}

clean_work_dir() {
  rm -rf $WORK_DIR
}

rsa_key_pair() {
  key_name=$1

  ssh-keygen \
    -t rsa \
    -b 4096 \
    -C "$key_name" \
    -f "$WORK_DIR/$key_name" \
    -N "$SSH_KEY_PASSWORD"
}

az_set_kv_secret() {
  secret_name=$1
  secret_value=$2
  kv_name=$3

  az keyvault secret set \
    --name "$secret_name" \
    --vault-name "$kv_name" \
    --value "$secret_value" \
    --output none
}

generate_and_upload_ssh_keys() {
  kv_secret_name=$1 &&
    rsa_key_pair "$kv_secret_name" &&
    base64 "$WORK_DIR/$kv_secret_name".pub >"$WORK_DIR"/"$kv_secret_name"-public-key &&
    public_key=$(cat "$WORK_DIR/$kv_secret_name-public-key") &&
    private_key=$(cat "$WORK_DIR/$kv_secret_name") &&
    az_set_kv_secret "$kv_secret_name-public-key" "$public_key" "$KV_LZ_NAME" &&
    az_set_kv_secret "$kv_secret_name-private-key" "$private_key" "$KV_LZ_NAME"
}

echo "Run pwd gen. ${KV_LZ_NAME}.."
create_work_dir &&
generate_and_upload_ssh_keys $AKS_ADMIN_SSH &&
echo "AKS SSH Admin key uploaded" &&
generate_and_upload_ssh_keys $DEVOPS_ADMIN_SSH &&
echo "DEVOPS VM SSH Admin key uploaded" &&
clean_work_dir