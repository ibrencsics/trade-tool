#!/usr/bin/env bash

KV_LZ_NAME="kv-gd-cpecprod-e3652f7e"
SQL_SERVER_ADMIN_PWD="cpecom-sql-server-admin-pwd"

random_pwd() {
  pwd=$(openssl rand -base64 20)
  echo "$pwd"
}

az_set_kv_secret() {
  secret_name=$1
  secret_value=$2
  kv_name=$3

  az keyvault secret set \
    --name "$secret_name" \
    --vault-name "$kv_name" \
    --value "$secret_value" \
    --output none
}

generate_and_upload_pwd() {
  kv_secret_name=$1
  password=$(random_pwd) &&
    az_set_kv_secret "$kv_secret_name" "$password" "$KV_LZ_NAME"
}

echo "Run pwd gen. ${KV_LZ_NAME}.."
create_work_dir &&
generate_and_upload_pwd $SQL_SERVER_ADMIN_PWD &&
echo "SQL Server Admin password uploaded"