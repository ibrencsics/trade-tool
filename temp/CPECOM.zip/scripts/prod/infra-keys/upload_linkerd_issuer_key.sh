#!/bin/bash

KV_NAME="kv-gd-cpecprod-e3652f7e"
ISSUER_PFX="./linkerd-issuer-cert.pfx"

az_import_kv_cert() {
  cert_name=$1
  cert_file=$2
  kv_name=$3

  az keyvault certificate import \
    --name "$cert_name" \
    --vault-name "$kv_name" \
    --f "$cert_file" \
    --password "<enter the password here>" \
    --output none
}

echo "Run cert upload..."
az_import_kv_cert linkerd-issuer-cert "$ISSUER_PFX" $KV_NAME &&
echo "Linkerd issuer key uploaded"