#!/usr/bin/env bash

KV_LZ_NAME="kv-gd-cpecprod-e3652f7e"

APPGW_CERT_API="appgw-cert-api"
APPGW_CERT_ADMIN="appgw-cert-admin"

APPGW_CERT_API_PATH="./cp-ecom-prod.pfx"
APPGW_CERT_ADMIN_PATH="./cp-ecom-admin-prod.pfx"

import_kv_cert() {
  cert_name=$1
  cert_file=$2
  kv_name=$3

  az keyvault certificate import \
    --name "$cert_name" \
    --vault-name "$kv_name" \
    --f "$cert_file" \
    --password "<enter the password here>" \
    --output none
}

echo "Run cert upload..."
import_kv_cert "$APPGW_CERT_API" "$APPGW_CERT_API_PATH" "$KV_LZ_NAME" &&
echo "Appgw API TLS key uploaded" &&
import_kv_cert "$APPGW_CERT_ADMIN" "$APPGW_CERT_ADMIN_PATH" "$KV_LZ_NAME" &&
echo "Appgw Admin TLS key uploaded"