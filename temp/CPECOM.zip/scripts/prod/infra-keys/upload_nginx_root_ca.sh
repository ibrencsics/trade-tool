#!/usr/bin/env bash

KV_LZ_NAME="kv-gd-cpecprod-e3652f7e"

AKS_INGRESS_ROOT_CA="aks-ingress-rootca"
AKS_INGRESS_ROOT_CA_PATH="./gd-sts-prod-rootca-cert-001.crt"

WORK_DIR="./tmp"

create_work_dir() {
  mkdir -p $WORK_DIR
}

clean_work_dir() {
  rm -rf $WORK_DIR
}

az_set_kv_secret() {
  secret_name=$1
  secret_value=$2
  kv_name=$3

  az keyvault secret set \
    --name "$secret_name" \
    --vault-name "$kv_name" \
    --value "$secret_value" \
    --output none
}

upload_root_ca() {
  secret_name=$1
  secret_file=$2
  kv_name=$3
  base64enc_file="$WORK_DIR/$secret_name"base64

  base64 "$secret_file" >"$base64enc_file" &&
    secret_value=$(cat "$base64enc_file") &&
    az_set_kv_secret "$secret_name" "$secret_value" "$kv_name"
}

echo "Run cert upload..."
create_work_dir &&
upload_root_ca "$AKS_INGRESS_ROOT_CA" "$AKS_INGRESS_ROOT_CA_PATH" "$KV_LZ_NAME" &&
echo "Nginx Root CA cert uploaded" &&
clean_work_dir