#!/usr/bin/env bash

KV_LZ_NAME="kv-gd-cpecprod-e3652f7e"

AKS_INGRESS_CERT="aks-ingress-cert"
AKS_INGRESS_CERT_PATH="./prod-ingress-cpecom-local.pfx"

az_import_kv_cert() {
  cert_name=$1
  cert_file=$2
  kv_name=$3

  az keyvault certificate import \
    --name "$cert_name" \
    --vault-name "$kv_name" \
    --f "$cert_file" \
    --password "<enter the password here>" \
    --output none
}

echo "Run cert upload..."
az_import_kv_cert "$AKS_INGRESS_CERT" "$AKS_INGRESS_CERT_PATH" "$KV_LZ_NAME" &&
echo "Nginx TLS key uploaded"