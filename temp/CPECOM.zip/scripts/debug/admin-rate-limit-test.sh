#!/usr/bin/env bash

REQUEST_PATH="https://20.76.198.26/admin/api/customer/9dc393d7-97a3-4c5e-ab1e-06be71ce2012"
#ADMIN_AUTHORIZATION="<ADMIN ACCESS TOKEN HERE>"
NUMBER_OF_REQUESTS=40
NUMBER_OF_PARALLEL_REQUESTS=10

request() {
  local request_path=$1
  local auth=$2
  curl -Is -k -H "Authorization: Bearer $auth" "$request_path"
}

export -f request

parallel -j$NUMBER_OF_PARALLEL_REQUESTS -n0 request "$REQUEST_PATH" "$ADMIN_AUTHORIZATION" ::: $(seq 1 $NUMBER_OF_REQUESTS)