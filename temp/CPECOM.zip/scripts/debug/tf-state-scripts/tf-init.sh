#
# NOTE:
# This is example script for running terraform init locally against remote state.
# Before running the script, this file must be copied to the same folder with terraform sources.
#

APP="cpecom"
ENV="stage"
STA_ACCESS_KEY="" # PUT ACCESS KEY of STA here
PLATFORM_SUBSCRIPTION_ID="31e6e7b1-445e-491c-8b4d-109fa9461a95"

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
SUBSCRIPTION="" # DEFINE TARGET SUBSCRIPTION NAME HERE. E.G. CPECOM-DEV

az_login() {
  local tenantId=$1
  local subscription=$2
  az login --use-device-code --tenant "$tenantId" &&
  az account set --subscription "$subscription"
}

terraform init \
  -backend-config="key=ecom_dashboard.dev_stage.tfstate" \
  -backend-config="storage_account_name=gdplatformterrastor01" \
  -backend-config="container_name=terraformstate-cpecom-stage" \
  -backend-config="access_key=$STA_ACCESS_KEY" \
  -backend-config="subscription_id=$PLATFORM_SUBSCRIPTION_ID"