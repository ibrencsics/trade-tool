#
# NOTE:
# This is an example script for running terraform import commands.
# Before import commands can be ran, tf-init.sh must be executed first.
#

ENV="dev_stage"

tf_import() {
  local tfAddr=$1
  local armId=$2
  terraform import -var-file=./env/$ENV.tfvars "$tfAddr" "$armId"
}

# Example for tf_import:
# tf_import "<terraform address>" "<azure resource id>"