#!/usr/bin/env bash

SRC_DASHBOARD_EXPORT_JSON="ecom-tokenizer-dev-dashboard-template.json"
OUT_TF_TEMPLATE_FILE="ecom-tokenizer-dev-dashboard.tpl"

## Env specific resource IDs and names to be replaced with tf-template variables
SRC_APPGW_ID="/subscriptions/67532a3a-a6ee-4e9c-a151-954f2006c51c/resourceGroups/rg-cpecom-dev-canadacentral-001/providers/Microsoft.Network/applicationGateways/appgw-cpecom-dev-canadacentral-001"
SRC_APPGW_NAME="appgw-cpecom-dev-canadacentral-001"
SRC_LOG_ANALYTICS_WP_ID="/subscriptions/67532a3a-a6ee-4e9c-a151-954f2006c51c/resourcegroups/rg-cpecom-dev-canadacentral-001/providers/microsoft.operationalinsights/workspaces/analytics-wp-cpecom-dev-canadacentral-001"
SRC_LOG_ANALYTICS_WP_NAME="analytics-wp-cpecom-prod-canadacentral-001"
SRC_VTS_TARGET_FQDN="cert.api.visa.com"
SRC_MC_TARGET_FQDN="sandbox.api.mastercard.com"



declare -A REPLACEMENTS=(
  ["$SRC_APPGW_ID"]="\${app_gw_id}"
  ["$SRC_APPGW_NAME"]="\${appgw_name}"
  ["$SRC_LOG_ANALYTICS_WP_ID"]="\${log_analytics_wp_id}"
  ["$SRC_LOG_ANALYTICS_WP_NAME"]="\${log_analytics_wp_name}"
  ["$SRC_VTS_TARGET_FQDN"]="\${vts_target_fqdn}"
  ["$SRC_MC_TARGET_FQDN"]="\${mc_target_fqdn}"
)

replace() {
  original=$1
  sed "s|$original|${REPLACEMENTS[$original]}|gI"
}

cat "$SRC_DASHBOARD_EXPORT_JSON" |
jq '.properties'|
replace "$SRC_APPGW_ID" |
replace "$SRC_LOG_ANALYTICS_WP_ID" |
replace "$SRC_VTS_TARGET_FQDN" |
replace "$SRC_MC_TARGET_FQDN" |
replace "$SRC_APPGW_NAME" |
replace "$SRC_LOG_ANALYTICS_WP_NAME" > "$OUT_TF_TEMPLATE_FILE"