#!/usr/bin/env bash

SRC_DB_CONN_DASHBOARD_EXPORT_JSON="ecom-tokenizer-db-conn-dashboard-template.json"
SRC_REACTOR_NETTY_DASHBOARD_EXPORT_JSON="ecom-tokenizer-reactor-netty-dashboard-template.json"
OUT_TF_TEMPLATE_FILE_DB_CONN_DASHBOARD="../db-connections/ecom-tokenizer-db-conn-dashboard.tpl"
OUT_TF_TEMPLATE_FILE_REACTOR_NETTY_DASHBOARD="../reactor-netty/ecom-tokenizer-reactor-netty-dashboard.tpl"

## Env specific resource IDs and names to be replaced with tf-template variables
SRC_LOG_ANALYTICS_WP_ID="\/subscriptions\/.*\/resourcegroups\/rg-cpecom-.*-canadacentral-001\/providers\/microsoft\.operationalinsights\/workspaces\/analytics-wp-cpecom-.*-canadacentral-001"
SRC_LOG_ANALYTICS_WP_NAME="analytics-wp-cpecom-.*-canadacentral-001"
SRC_VTS_TARGET_SBX_FQDN="cert.api.visa.com:443"
SRC_VTS_TARGET_PROD_FQDN="api.visa.com:443"
SRC_MC_TARGET_SBX_FQDN="sandbox.api.mastercard.com:443"
SRC_MC_TARGET_PROD_FQDN="api.mastercard.com:443"

declare -A REPLACEMENTS=(
  ["$SRC_LOG_ANALYTICS_WP_ID"]="\${log_analytics_wp_id}"
  ["$SRC_LOG_ANALYTICS_WP_NAME"]="\${log_analytics_wp_name}"
  ["$SRC_VTS_TARGET_SBX_FQDN"]="\${vts_target_fqdn}:443"
  ["$SRC_VTS_TARGET_PROD_FQDN"]="\${vts_target_fqdn}:443"
  ["$SRC_MC_TARGET_SBX_FQDN"]="\${mc_target_fqdn}:443"
  ["$SRC_MC_TARGET_PROD_FQDN"]="\${mc_target_fqdn}:443"
)

replace() {
  original=$1
  sed "s|$original|${REPLACEMENTS[$original]}|gI"
}

cat "$SRC_DB_CONN_DASHBOARD_EXPORT_JSON" |
jq '.properties'|
replace "$SRC_LOG_ANALYTICS_WP_ID" |
replace "$SRC_VTS_TARGET_SBX_FQDN" |
replace "$SRC_VTS_TARGET_PROD_FQDN" |
replace "$SRC_MC_TARGET_SBX_FQDN" |
replace "$SRC_MC_TARGET_PROD_FQDN" |
replace "$SRC_LOG_ANALYTICS_WP_NAME" > "$OUT_TF_TEMPLATE_FILE_DB_CONN_DASHBOARD"

cat "$SRC_REACTOR_NETTY_DASHBOARD_EXPORT_JSON" |
jq '.properties'|
replace "$SRC_LOG_ANALYTICS_WP_ID" |
replace "$SRC_VTS_TARGET_SBX_FQDN" |
replace "$SRC_VTS_TARGET_PROD_FQDN" |
replace "$SRC_MC_TARGET_SBX_FQDN" |
replace "$SRC_MC_TARGET_PROD_FQDN" |
replace "$SRC_LOG_ANALYTICS_WP_NAME" > "$OUT_TF_TEMPLATE_FILE_REACTOR_NETTY_DASHBOARD"