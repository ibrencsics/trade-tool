#!/usr/bin/env bash

SRC_DASHBOARD_EXPORT_JSON="ecom-tokenizer-app-dashboard-template.json"
OUT_TF_TEMPLATE_FILE="ecom-tokenizer-app-dashboard.tpl"

## Env specific resource IDs and names to be replaced with tf-template variables
SRC_APPGW_ID="\/subscriptions\/.*\/resourceGroups\/rg-cpecom-.*-canadacentral-001\/providers\/Microsoft\.Network\/applicationGateways\/appgw-cpecom-.*-canadacentral-001"
SRC_APPGW_NAME="appgw-cpecom-.*-canadacentral-001"
SRC_LOG_ANALYTICS_WP_ID="\/subscriptions\/.*\/resourcegroups\/rg-cpecom-.*-canadacentral-001\/providers\/microsoft\.operationalinsights\/workspaces\/analytics-wp-cpecom-.*-canadacentral-001"
SRC_LOG_ANALYTICS_WP_NAME="analytics-wp-cpecom-.*-canadacentral-001"
SRC_AI_ID="\/subscriptions\/.*\/resourceGroups\/rg-cpecom-.*-canadacentral-001/providers/Microsoft.Insights/components/appi-cpecom-.*-canadacentral-001"
SRC_AI_NAME="appi-cpecom-.*-canadacentral-001"
SRC_VTS_TARGET_SBX_FQDN="cert.api.visa.com"
SRC_VTS_TARGET_PROD_FQDN="api.visa.com"
SRC_MC_TARGET_SBX_FQDN="sandbox.api.mastercard.com"
SRC_MC_TARGET_PROD_FQDN="api.mastercard.com"
SRC_INGRESS_FQDN_PROD="prod.ingress.cpecom.local"
SRC_INGRESS_FQDN_DEV="dev.ingress.cpecom.local"

declare -A REPLACEMENTS=(
  ["$SRC_APPGW_ID"]="\${app_gw_id}"
  ["$SRC_APPGW_NAME"]="\${appgw_name}"
  ["$SRC_LOG_ANALYTICS_WP_ID"]="\${log_analytics_wp_id}"
  ["$SRC_LOG_ANALYTICS_WP_NAME"]="\${log_analytics_wp_name}"
  ["$SRC_AI_ID"]="\${appi_id}"
  ["$SRC_AI_NAME"]="\${appi_name}"
  ["$SRC_VTS_TARGET_SBX_FQDN"]="\${vts_target_fqdn}"
  ["$SRC_VTS_TARGET_PROD_FQDN"]="\${vts_target_fqdn}"
  ["$SRC_MC_TARGET_SBX_FQDN"]="\${mc_target_fqdn}"
  ["$SRC_MC_TARGET_PROD_FQDN"]="\${mc_target_fqdn}"
  ["$SRC_INGRESS_FQDN_PROD"]="\${ingress_fqdn}"
  ["$SRC_INGRESS_FQDN_DEV"]="\${ingress_fqdn}"
)

replace() {
  original=$1
  sed "s|$original|${REPLACEMENTS[$original]}|gI"
}

cat "$SRC_DASHBOARD_EXPORT_JSON" |
jq '.properties'|
replace "$SRC_APPGW_ID" |
replace "$SRC_LOG_ANALYTICS_WP_ID" |
replace "$SRC_AI_ID" |
replace "$SRC_AI_NAME" |
replace "$SRC_VTS_TARGET_SBX_FQDN" |
replace "$SRC_VTS_TARGET_PROD_FQDN" |
replace "$SRC_MC_TARGET_SBX_FQDN" |
replace "$SRC_MC_TARGET_PROD_FQDN" |
replace "$SRC_APPGW_NAME" |
replace "$SRC_INGRESS_FQDN_PROD" |
replace "$SRC_INGRESS_FQDN_DEV" |
replace "$SRC_LOG_ANALYTICS_WP_NAME" > "$OUT_TF_TEMPLATE_FILE"