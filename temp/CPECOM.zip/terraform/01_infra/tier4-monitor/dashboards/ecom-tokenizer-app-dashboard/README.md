# Module for ecom-tokenizer-app dashboard

## Modifying and updating dashboard

1. Open [dashboard-application-cpecom-dev-canadacentral](https://portal.azure.com/#@gdmsstsprodna.onmicrosoft.com/dashboard/arm/subscriptions/67532a3a-a6ee-4e9c-a151-954f2006c51c/resourceGroups/rg-cpecom-dev-alerts-canadacentral/providers/Microsoft.Portal/dashboards/dashboard--cpecom-dev-canadacentral)
in azure portal
2. Click ``Clone``
3. Click ``Save``
4. Complete the edits with cloned dashboard and ``Save`` changes
5. Click ``Export->Download``
6. Save chart file to ``CPECOM/terraform/01_infra/tier4-monitor/dashboards/ecom-tokenizer-app-dashboard/template`` with
file name ``ecom-tokenizer-app-dashboard-template.json``
7. Verify the template for updated resources and replace the subscription patterns in `tf-template-gen.sh` to the ones needed for the environment
8. Execute ``./tf-template-gen``

> **_NOTE:_**  If new environment dependent variables were added to the chart, update ``tf-template.gen``
> and terraform variable bindings accordingly