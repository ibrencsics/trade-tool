CREATE USER $(db_user) WITH PASSWORD = '$(db_user_pwd)';
EXEC sp_addrolemember N'db_owner', N'$(db_user)'
GO