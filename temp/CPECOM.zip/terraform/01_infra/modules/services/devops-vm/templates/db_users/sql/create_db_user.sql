CREATE USER $(db_user) FOR LOGIN $(db_user);
EXEC sp_addrolemember N'db_owner', N'$(db_user)'
GO