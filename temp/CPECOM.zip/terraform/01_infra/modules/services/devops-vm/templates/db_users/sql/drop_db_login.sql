IF EXISTS(SELECT name FROM sys.sql_logins WHERE name = '$(db_user)')
BEGIN
    DROP LOGIN $(db_user);
END
GO
