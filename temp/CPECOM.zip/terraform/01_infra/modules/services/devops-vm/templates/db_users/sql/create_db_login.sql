CREATE LOGIN $(db_user) with PASSWORD='$(db_user_pwd)';
GO