# Env
export DB_SERVER_FQDN=${mssql_server_fqdn}
export KV_BE_NAME=${kv_be_name}
export KV_GW_NAME=${kv_gw_name}

export DB_BE_NAME=${mssql_db_be_name}
export DB_BE_USER=${mssql_db_be_user}

export DB_METADATA_NAME=${mssql_db_metadata_name}
export DB_METADATA_USER=${mssql_db_metadata_user}