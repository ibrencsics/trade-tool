#!/usr/bin/env bash

source "./support/env.sh"
source "./support/output.sh"

drop_db_login() {
  local aad_admin_username=$1
  local aad_admin_pwd=$2
  local db_user=$3

  sqlcmd -S "$DB_SERVER_FQDN" -b -i sql/drop_db_login.sql -v db_user="$db_user" -U "$aad_admin_username" -P "$aad_admin_pwd"

  return $?
}

usage() {
  echo "Usage: ./drop_db_login.sh <ad_user_name> <db_user_to_drop>"
  echo "e.g. : ./drop_db_login.sh example@gi-de.com db-metadata db-metadata-user"
}

if [ "$1" == "" ]; then
  echo "Missing argument ad_user"
  usage
  exit 1
elif [ "$2" == "" ]; then
  echo "Missing argument db_user"
  usage
  exit 1
fi

ad_user=$1
db_user_to_drop=$2
read -r -p "Type password for $ad_user: " -s ad_user_pwd

begin "DROP LOGIN ($db_user_to_drop) FROM: $DB_SERVER_FQDN" &&
  next "DROP LOGIN: $db_user_to_drop" &&
  drop_db_login "$ad_user" "$ad_user_pwd" "$db_user_to_drop" &&
  ok