#!/usr/bin/env bash

source "./support/env.sh"
source "./support/output.sh"

drop_db_user() {
  local aad_admin_username=$1
  local aad_admin_pwd=$2
  local db=$3
  local db_user=$4

  sqlcmd -S "$DB_SERVER_FQDN" -d "$db" -b -i sql/drop_db_user.sql -v db_user="$db_user" -U "$aad_admin_username" -P "$aad_admin_pwd"

  return $?
}

usage() {
  echo "Usage: ./drop_db_user.sh <ad_user_name> <db_name> <db_user_to_drop>"
  echo "e.g. : ./drop_db_user.sh example@gi-de.com db-metadata db-metadata-user"
}

if [ "$1" == "" ]; then
  echo "Missing argument ad_user"
  usage
  exit 1
elif [ "$2" == "" ]; then
  echo "Missing argument db_name"
  usage
  exit 1
elif [ "$3" == "" ]; then
  echo "Missing argument db_user"
  usage
  exit 1
fi

ad_user=$1
db=$2
db_user_to_drop=$3
read -r -p "Type password for $ad_user: " -s ad_user_pwd

begin "DROP LOGIN & USER ($db_user_to_drop) FROM: $db" &&
  next "DROP DB USER: $db_user_to_drop" &&
  drop_db_user "$ad_user" "$ad_user_pwd" "$db" "$db_user_to_drop" &&
  ok