#!/usr/bin/env bash

pull_key_manager_image() {
  vmIdentity=$1
  acrName=$2
  keyManagerImage=$3
  az login --identity --username "$vmIdentity" &&
    az acr login -n "$acrName" &&
    docker pull "$keyManagerImage"
}

run_key_manager() {
  tenantId=$1
  springConfigName=$2
  keyManagerImage=$3
  docker run --name key_manager\
    -v "$(pwd)"/config:/config\
    -v "$(pwd)"/key:/key\
    --env TENANT_ID="$tenantId"\
    --env SPRING_CONFIG_NAME="$springConfigName"\
    "$keyManagerImage"
  docker container rm key_manager
}
