#!/usr/bin/env bash

begin() {
  local action=$1
  printf -- "\n----------\n%s\n" "$action"
}

next() {
  local next=$1
  printf -- "--> %s\n" "$next"
}

ok() {
  printf -- "[%s]\n" "OK"
}