#!/usr/bin/env bash

. ./commons_docker.sh

TENANT_ID=${tenant_id}
VM_IDENTITY=${devops_vm_identity_object_id}
ACR_NAME=${acr_name}
KEY_MANAGER_IMAGE=${key_manager_image}
GW_CONFIG_NAME=${spring_config_name_gw}
CRYPTO_CONFIG_NAME=${spring_config_name_crypto}

pull_key_manager_image "$VM_IDENTITY" "$ACR_NAME" "$KEY_MANAGER_IMAGE" &&
  unzip key.zip &&
  run_key_manager "$TENANT_ID" "$GW_CONFIG_NAME" "$KEY_MANAGER_IMAGE" &&
  run_key_manager "$TENANT_ID" "$CRYPTO_CONFIG_NAME" "$KEY_MANAGER_IMAGE" &&
  echo "Done"