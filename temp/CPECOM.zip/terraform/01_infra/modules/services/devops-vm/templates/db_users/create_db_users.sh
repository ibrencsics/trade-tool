#!/usr/bin/env bash

source "./support/env.sh"
source "./support/output.sh"

verify_kv_access() {
  local kv=$1

  az keyvault secret set --vault-name "$kv" --name "test-secret-label" --value "test-secret-value" --output none

  return $?
}

store_db_credentials() {
  local kv=$1
  local db_user=$2
  local db_user_pwd=$3

  local db_user_secret_label="$db_user-label"
  local db_user_pwd_secret_label="$db_user-pwd-label"

  az keyvault secret set --vault-name "$kv" --name "$db_user_secret_label" --value "$db_user" --output none &&
    az keyvault secret set --vault-name "$kv" --name "$db_user_pwd_secret_label" --value "$db_user_pwd" --output none

  return $?
}

verify_db_access() {
  local aad_admin_username=$1
  local aad_admin_pwd=$2
  local db=$3

  sqlcmd -S "$DB_SERVER_FQDN" -d "$db" -b -i sql/select_version.sql -U "$aad_admin_username" -P "$aad_admin_pwd"

  return $?
}

create_contained_db_user() {
  local aad_admin_username=$1
  local aad_admin_pwd=$2
  local db=$3
  local db_user=$4
  local db_user_pwd=$5

  sqlcmd -S "$DB_SERVER_FQDN" -d "$db" -b -i sql/create_contained_db_user.sql -v db_user="$db_user" db_user_pwd="$db_user_pwd" -U "$aad_admin_username" -P "$aad_admin_pwd"

  return $?
}

usage() {
  echo "Usage: ./create_db_users.sh <ad_user_name>"
  echo "e.g. : ./create_db_users.sh example@gi-de.com"
}

create_db_be_user() {
  local aad_admin=$1
  local aad_admin_pwd=$2

  db_be_user_pwd=$(openssl rand -base64 12) &&
    next "Verify $KV_BE_NAME access" &&
    verify_kv_access "$KV_BE_NAME" &&
    ok && next "VERIFY $DB_BE_NAME access" &&
    verify_db_access "$aad_admin" "$aad_admin_pwd" "$DB_BE_NAME" &&
    ok && next "CREATE Contained DB User: $DB_BE_USER" &&
    create_contained_db_user "$aad_admin" "$aad_admin_pwd" "$DB_BE_NAME" "$DB_BE_USER" "$db_be_user_pwd" &&
    ok && next "STORE CREDENTIALS TO $KV_BE_NAME" &&
    store_db_credentials "$KV_BE_NAME" "$DB_BE_USER" "$db_be_user_pwd" &&

  return $?
}

create_db_metadata_user() {
  local aad_admin=$1
  local aad_admin_pwd=$2

  db_metadata_user_pwd=$(openssl rand -base64 12) &&
    next "Verify $KV_BE_NAME access" &&
    verify_kv_access "$KV_BE_NAME" &&
    ok && next "VERIFY $DB_METADATA_NAME access" &&
    verify_db_access "$ad_user" "$ad_user_pwd" "$DB_METADATA_NAME" &&
    ok && next "CREATE Contained DB User: $DB_METADATA_USER" &&
    create_contained_db_user "$aad_admin" "$aad_admin_pwd" "$DB_METADATA_NAME" "$DB_METADATA_USER" "$db_metadata_user_pwd" &&
    ok && next "STORE CREDENTIALS TO $KV_BE_NAME" &&
    store_db_credentials "$KV_BE_NAME" "$DB_METADATA_USER" "$db_metadata_user_pwd" &&

  return $?
}

if [ "$1" == "" ]; then
  echo "Missing argument ad_user"
  usage
  exit 1
fi

# Get Credentials for AAD Admin
ad_user=$1
read -r -p "Type password for $ad_user: " -s ad_user_pwd

# Create DB Login & User for BE
begin "Create DB_USER: $DB_BE_USER. FOR DB: $DB_BE_NAME" &&
  create_db_be_user "$ad_user" "$ad_user_pwd" &&
  ok

# Create DB Login & User for METADATA
begin "Create DB_USER: $DB_METADATA_USER. FOR DB: $DB_METADATA_NAME" &&
  create_db_metadata_user "$ad_user" "$ad_user_pwd" &&
  ok