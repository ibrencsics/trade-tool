#!/bin/bash
devops_admin=${DEVOPS_ADMIN}
sta_name=${STA_NAME}
sta_container_name=${STA_CONTAINER_NAME}
identity_object_id=${IDENTITY_OBJECT_ID}

# datadog
devops_vm_name=${DEVOPS_VM_NAME}

blob_st_mount_dir="/deployment"
group_deployer="deployer"

# Create exec log
EXEC_LOG_FILE=/tmp/exec.log
rm -f $EXEC_LOG_FILE
touch $EXEC_LOG_FILE
echo 'Running' >> $EXEC_LOG_FILE

# Update yum
sudo yum -y update --exclude WALinuxAgent
sudo yum install -y yum-utils &&
echo 'Yum updated' >> $EXEC_LOG_FILE

# install az cli & aks tools (kubectl, kubelogin)
sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc &&
echo -e "[azure-cli]
name=Azure CLI
baseurl=https://packages.microsoft.com/yumrepos/azure-cli
enabled=1
gpgcheck=1
gpgkey=https://packages.microsoft.com/keys/microsoft.asc" | sudo tee /etc/yum.repos.d/azure-cli.repo &&
sudo yum install -y azure-cli &&
echo 'Az-cli installed' >> $EXEC_LOG_FILE &&
sudo az aks install-cli &&
echo 'kubectl & kubelogin installed' >> $EXEC_LOG_FILE &&

# Install Java
sudo yum install -y java-11-openjdk-devel &&
echo 'Java installed' >> $EXEC_LOG_FILE

# install docker
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y docker-ce docker-ce-cli containerd.io
sudo usermod -aG docker "$devops_admin" &&
echo 'Docker installed' >> $EXEC_LOG_FILE
sudo systemctl start docker &&
echo 'Docker started' >> $EXEC_LOG_FILE

# install helm
curl -o helm.tar.gz https://get.helm.sh/helm-v3.3.4-linux-amd64.tar.gz &&
tar zxvf helm.tar.gz &&
sudo mv linux-amd64/helm /usr/local/bin/helm &&
rm -rf linux-amd64 &&
rm -f helm.tar.gz &&
echo 'Helm installed' >> $EXEC_LOG_FILE

# Install Unzip
sudo yum install -y unzip &&
echo 'Unzip installed' >> $EXEC_LOG_FILE

# Install JQ
sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
sudo yum install -y jq &&
echo 'JQ installed' >> $EXEC_LOG_FILE

# Install Linkerd
sudo curl --proto '=https' --tlsv1.2 -sSfL https://run.linkerd.io/install | sh &&
sudo mv /root/.linkerd2/ /usr/local/bin/.linkerd2 &&
sudo chmod -R a+rwx /usr/local/bin/.linkerd2 &&
sudo ln -sf /usr/local/bin/.linkerd2/bin/linkerd-stable-2.11.1 /usr/local/bin/.linkerd2/bin/linkerd &&
echo 'Linkerd Cli installed'

# Install ZSH and extensions
sudo yum install -y zsh &&
sudo yum install -y wget git &&
sudo wget https://github.com/robbyrussell/oh-my-zsh/raw/master/tools/install.sh -O - | zsh &&
echo 'ZSH installed' >> $EXEC_LOG_FILE

# Add MS Repos
sudo rpm -Uvh https://packages.microsoft.com/config/rhel/7/packages-microsoft-prod.rpm &&
# Install MSSQL Tools
#curl https://packages.microsoft.com/config/rhel/7/prod.repo > /etc/yum.repos.d/msprod.repo
sudo ACCEPT_EULA=Y yum install -y mssql-tools unixODBC-devel &&
sudo ln -s /opt/mssql-tools/bin/sqlcmd /usr/bin/sqlcmd &&
echo 'mssql-tools installed' >> $EXEC_LOG_FILE

# Install blobfuse
sudo yum -y install blobfuse
sudo mkdir -p /mnt/ramdisk
sudo mount -t tmpfs -o size=16g tmpfs /mnt/ramdisk
sudo mkdir -p /mnt/ramdisk/blobfusetmp
sudo mkdir -p /mnt/resource/blobfusetmp
rm -f ~/fuse_connection.cfg
fuse_cfg_file=~/fuse_connection.cfg
touch "$fuse_cfg_file"
{
  echo "accountName $sta_name"
  echo "authType MSI"
  echo "identityObjectId $identity_object_id"
  echo "containerName $sta_container_name"
} >>$fuse_cfg_file
chmod 600 "$fuse_cfg_file" &&
echo 'blob fuse installed' >> $EXEC_LOG_FILE

# Mount blob storage
sudo mkdir -p "$blob_st_mount_dir"
sudo blobfuse "$blob_st_mount_dir" --tmp-path=/mnt/resource/blobfusetmp --config-file="/root/fuse_connection.cfg" -o attr_timeout=240 -o entry_timeout=240 -o negative_timeout=120 -o allow_other || echo "Already mounted" &&
echo 'blob fuse mounted' >> $EXEC_LOG_FILE

# Create deployer group
sudo getent group "$group_deployer" || groupadd "$group_deployer" && usermod -aG "$group_deployer" "$devops_admin"

# Define ownership of mount directories
sudo chown "$devops_admin:$group_deployer" /mnt/resource/blobfusetmp
sudo chown "$devops_admin:$group_deployer" /mnt/ramdisk/blobfusetmp
sudo chown "$devops_admin:$group_deployer" "$blob_st_mount_dir"

echo 'Done' >> $EXEC_LOG_FILE &&
exit 0