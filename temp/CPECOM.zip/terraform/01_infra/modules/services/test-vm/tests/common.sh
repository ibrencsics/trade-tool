export ACR_NAME=${acr_name}
export CR_LOGIN_SERVER="${acr_name}.azurecr.io"
export IDENTITY_OBJECT_ID=${identity_object_id}
export AKS_ENTRY_POINT=${aks_entry_point}
export TSP_MOCK_PORT=${tsp_mock_port}
export LOAD_TESTER_PORT=${load_tester_port}
export TEST_TOOLS_NETWORK="test-network"
export TSP_MOCK_CONTAINER_NAME="tsp-mock"
export LOAD_TESTER_CONTAINER_NAME="load-tester"

acr_login(){
  echo "#### Acr login. $ACR_NAME ($IDENTITY_OBJECT_ID)"
  az login --identity --username "$IDENTITY_OBJECT_ID" &&
  az acr login -n "$ACR_NAME"
}

docker_network_create() {
  echo "## docker_network_create $TEST_TOOLS_NETWORK"
  docker network create "$TEST_TOOLS_NETWORK" || echo "Already created"
}