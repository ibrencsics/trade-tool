#!/bin/bash

source "/tests/common.sh"

start_tsp_mock() {
  local cr_login_url=$1
  local tsp_mock_image=$2
  local tsp_mock=$3
  local tsp_mock_port=$4
  local tspgw_url=$5
  local network=$6

  docker pull "$cr_login_url/$tsp_mock_image" &&
  docker run -d --name "$tsp_mock" -p "$tsp_mock_port:$tsp_mock_port" \
    --env SPRING_PROFILES_ACTIVE=cloud \
    --env SERVER_PORT="$tsp_mock_port" \
    --env MOCK_CONFIG_TSPGW_BASE_URL="$tspgw_url" \
    --env MOCK_CONFIG_MCSCOF_NOTIFICATION_STATIC_DELAY_MS=500 \
    --net "$network" \
    "$cr_login_url/$tsp_mock_image"
}

usage() {
  echo "Usage: start-tsp-mock.sh <tsp_mock_image>"
}

if [ $# -lt 1 ];
then
	usage
  exit 1
else
  tsp_mock_image=$1
fi

acr_login &&
docker_network_create &&
echo "## start_tsp_mock $CR_LOGIN_SERVER $tsp_mock_image $TSP_MOCK_CONTAINER_NAME $TSP_MOCK_PORT $AKS_ENTRY_POINT" &&
start_tsp_mock "$CR_LOGIN_SERVER" "$tsp_mock_image" "$TSP_MOCK_CONTAINER_NAME" "$TSP_MOCK_PORT" "$AKS_ENTRY_POINT" "$TEST_TOOLS_NETWORK"
