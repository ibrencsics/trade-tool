#!/bin/bash

source "/tests/common.sh"

docker_network_rm() {
  local network=$1
  echo "### docker network rm $network"
  docker network rm "$network" || echo "Network: $network not found"
}

stop_tsp_mock() {
  local tsp_mock=$1

  echo "### docker stop $tsp_mock"
  docker stop "$tsp_mock"
  echo "### docker container rm $tsp_mock"
  docker container rm "$tsp_mock" || echo "Container: $tsp_mock not found"
}

stop_tsp_mock "$TSP_MOCK_CONTAINER_NAME"
docker_network_rm "$TEST_TOOLS_NETWORK"
