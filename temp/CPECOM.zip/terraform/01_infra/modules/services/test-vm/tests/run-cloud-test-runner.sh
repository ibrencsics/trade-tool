#!/usr/bin/env bash

source "/tests/common.sh"

pull_cloud_tester_image() {
  local cloud_test_runner_image=$1

  echo "#### docker pull $cloud_test_runner_image"
  docker pull "$cloud_test_runner_image"
}

run_cloud_test_runner() {
  local cloud_test_runner_image=$1
  local test_profile_name=$2
  local test_customer=$3
  local target_tsp=$4
  local test_suite=$5
  local test_tags_to_include=$6
  local test_tags_to_exclude=$7
  local tsp_mock_url=$8
  local network=$9

  echo "#### docker run $cloud_test_runner_image"
  docker run \
      --rm \
      --name cloud-test-runner \
      --env WEB_CLIENT_CONF_PROXY_CONF_ENABLED=false \
      --env CLOUD_TEST_RUNNER_SETTINGS_ENABLE_ANSI_OUTPUT=true \
      --env SPRING_PROFILES_ACTIVE="$test_profile_name" \
      --env TEST_CONF_CLOUD_TEST_CUSTOMER="$test_customer" \
      --env TEST_CONF_TARGET_TSP="$target_tsp" \
      --env TEST_CONF_MOCK_URL="$tsp_mock_url" \
      --env TEST_CONF_TSPGW_URL="$AKS_ENTRY_POINT" \
      --env CLOUD_TEST_RUNNER_SETTINGS_TEST_SUITE_NAME="$test_suite" \
      --env CLOUD_TEST_RUNNER_SETTINGS_TEST_TAG_INCLUDE_FILTER="$test_tags_to_include" \
      --env CLOUD_TEST_RUNNER_SETTINGS_TEST_TAG_EXCLUDE_FILTER="$test_tags_to_exclude" \
      --net "$network" \
      "$cloud_test_runner_image"
}

create_output_json() {
  local stop_tsp_mock_output=$1
  local start_tsp_mock_output=$2
  local acr_login_output=$3
  local pull_image_output=$4
  local test_runner_output=$5
  local exit_code=$6

  echo "{\"stopTspMockOutput\": \"$stop_tsp_mock_output\",\"startTspMockOutput\": \"$start_tsp_mock_output\", \"acrLoginOutput\": \"$acr_login_output\", \"pullImageOutput\": \"$pull_image_output\", \"testRunnerOutput\": \"$test_runner_output\", \"exitCode\": $exit_code}"
}

usage() {
  echo "Usage: run-cloud-test-runner.sh <tsp_mock_image> <cloud_test_runner_image> <test_profile_name> <test_suite> <test_customer> <test_tags_to_include> <test_tags_to_exclude>"
}

if [ $# -lt 8 ];
then
	usage
  exit 1
else
  tsp_mock_image=$1
  cloud_test_runner_image=$2
  test_profile_name=$3
  test_suite=$4
  test_customer=$5
  target_tsp=$6
  test_tags_to_include=$7
  test_tags_to_exclude=$8
fi

set -o pipefail
# Restart tsp-mock
stop_tsp_mock_output=$(/tests/stop-tsp-mock.sh | base64 -w 0) &&
start_tsp_mock_output=$(/tests/start-tsp-mock.sh "$tsp_mock_image" | base64 -w 0) &&
# Run cloud-test-runner
acr_login_output=$(acr_login | base64 -w 0) &&
image_pull_output=$(pull_cloud_tester_image "$CR_LOGIN_SERVER/$cloud_test_runner_image" | base64 -w 0) &&
cloud_test_runner_output=$(run_cloud_test_runner \
  "$CR_LOGIN_SERVER/$cloud_test_runner_image" \
  "$test_profile_name" \
  "$test_customer" \
  "$target_tsp" \
  "$test_suite" \
  "$test_tags_to_include"\
  "$test_tags_to_exclude" \
  "http://$TSP_MOCK_CONTAINER_NAME:$TSP_MOCK_PORT" \
   "$TEST_TOOLS_NETWORK" | base64 -w 0)
exit_code=$?

output_json=$(create_output_json "$stop_tsp_mock_output" "$start_tsp_mock_output" "$acr_login_output" "$image_pull_output" "$cloud_test_runner_output" "$exit_code") &&
echo "$output_json"