#!/bin/bash

source "/tests/common.sh"

docker stop "$LOAD_TESTER_CONTAINER_NAME"
docker container rm "$LOAD_TESTER_CONTAINER_NAME"