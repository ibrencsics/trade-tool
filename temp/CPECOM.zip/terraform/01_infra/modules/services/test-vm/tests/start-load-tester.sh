#!/bin/bash

source "/tests/common.sh"

usage() {
  echo "Usage: start-load-tester.sh <load_tester_image>"
}

start_load_tester() {
  local cr_login_url=$1
  local load_tester_image=$2
  local load_tester_port=$3
  local load_tester_container_name=$4
  local aks_entry_point=$5

  docker pull "$cr_login_url/$load_tester_image"
  docker run -d --name "$load_tester_container_name" \
    --env MOCK_URL=https://localhost:443 \
    --env SERVER_PORT="$load_tester_port" \
    --env AKS_ILB_URL="$aks_entry_point" \
    -p "$load_tester_port:$load_tester_port" \
    "$cr_login_url/$load_tester_image"
}

if [ $# -lt 1 ];
then
	usage
  exit 1
else
  load_tester_image=$1
fi

acr_login &&
docker_network_create &&
echo "## start_load_tester $CR_LOGIN_SERVER $load_tester_image $LOAD_TESTER_PORT $LOAD_TESTER_CONTAINER_NAME" "$AKS_ENTRY_POINT" &&
start_load_tester "$CR_LOGIN_SERVER" "$load_tester_image" "$LOAD_TESTER_PORT" "$LOAD_TESTER_CONTAINER_NAME" "$AKS_ENTRY_POINT"