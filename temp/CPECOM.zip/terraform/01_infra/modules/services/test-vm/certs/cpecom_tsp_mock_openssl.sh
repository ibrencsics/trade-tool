#!/bin/bash
openssl req -x509 -nodes -days 3650 -newkey rsa:2048 -keyout cpecom_tsp_mock_key.pem -out cpecom_tsp_mock_cert.crt -config cpecom_tsp_mock_openssl.conf