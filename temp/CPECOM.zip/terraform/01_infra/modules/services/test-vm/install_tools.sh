#!/bin/bash

test_admin=${TEST_ADMIN}

# Nginx
ssl_cert=${SSL_CERT}
ssl_cert_key=${SSL_CERT_KEY}
tsp_mock_port=${TSP_MOCK_PORT}

# Built-in test scripts
common_sh=${COMMON_SH}
run_cloud_test_runner_sh=${RUN_CLOUD_TEST_RUNNER_SH}
start_tsp_mock_sh=${START_TSP_MOCK_SH}
stop_tsp_mock_sh=${STOP_TSP_MOCK_SH}
start_load_tester_sh=${START_LOAD_TESTER_SH}
stop_load_tester_sh=${STOP_LOAD_TESTER_SH}

# datadog
test_vm_name=${TEST_VM_NAME}

# Create exec log
EXEC_LOG_FILE=/tmp/exec.log
rm -f $EXEC_LOG_FILE
touch $EXEC_LOG_FILE
echo 'Running' >> $EXEC_LOG_FILE

# Update yum
sudo yum -y update --exclude WALinuxAgent
sudo yum install -y yum-utils
echo 'yum updated' >> $EXEC_LOG_FILE

# install az cli
sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc &&
echo -e "[azure-cli]
name=Azure CLI
baseurl=https://packages.microsoft.com/yumrepos/azure-cli
enabled=1
gpgcheck=1
gpgkey=https://packages.microsoft.com/keys/microsoft.asc" | sudo tee /etc/yum.repos.d/azure-cli.repo &&
sudo yum install -y azure-cli
echo 'az cli installed' >> $EXEC_LOG_FILE

# install docker
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y docker-ce docker-ce-cli containerd.io
sudo usermod -aG docker "$test_admin"
sudo systemctl start docker
echo 'docker installed' >> $EXEC_LOG_FILE

# Install JQ
sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
sudo yum install -y jq &&
echo 'JQ installed' >> $EXEC_LOG_FILE

# Install zsh, wget and git
sudo yum install -y zsh wget git
echo 'zsh installed' >> $EXEC_LOG_FILE

#
# Built-in test scripts
#
build_in_test_script() {
  local script_base64=$1
  local script_path=$2
  echo "$script_base64" | base64 --decode >> "$script_path" &&
  chmod +x "$script_path"
}

test_scripts_location="/tests" &&
rm -rf "$test_scripts_location" &&
mkdir "$test_scripts_location" &&
build_in_test_script "$common_sh" "$test_scripts_location/common.sh" &&
build_in_test_script "$run_cloud_test_runner_sh" "$test_scripts_location/run-cloud-test-runner.sh" &&
build_in_test_script "$start_tsp_mock_sh" "$test_scripts_location/start-tsp-mock.sh" &&
build_in_test_script "$stop_tsp_mock_sh" "$test_scripts_location/stop-tsp-mock.sh" &&
build_in_test_script "$start_load_tester_sh" "$test_scripts_location/start-load-tester.sh" &&
build_in_test_script "$stop_load_tester_sh" "$test_scripts_location/stop-load-tester.sh" &&
echo 'built-in test scripts created' >> $EXEC_LOG_FILE

#
# NGINX
#
sudo yum install -y epel-release
sudo yum install -y nginx

echo 'nginx installed' >> $EXEC_LOG_FILE

# iptables:
# Enable access to ports 80 & 443
sudo /sbin/iptables -C INPUT -p tcp -m tcp --dport 80 -j ACCEPT || sudo /sbin/iptables -I INPUT -p tcp -m tcp --dport 80 -j ACCEPT
sudo /sbin/iptables -C INPUT -p tcp -m tcp --dport 443 -j ACCEPT || sudo /sbin/iptables -I INPUT -p tcp -m tcp --dport 443 -j ACCEPT
sudo /sbin/service iptables save

echo 'ip tables configured' >> $EXEC_LOG_FILE

# SELinux:
# Allow NGINX to forward traffic to localhost ports
setsebool -P httpd_can_network_relay 1
semanage port -a -t http_port_t -p tcp $tsp_mock_port

echo 'selinux configured' >> $EXEC_LOG_FILE

# SSL CERTS
sudo mkdir -p /etc/ssl/private
sudo mkdir -p /etc/nginx/snippets

echo "$ssl_cert" | base64 --decode | sudo tee /etc/ssl/certs/nginx-selfsigned.crt;
echo "$ssl_cert_key" | base64 --decode | sudo tee /etc/ssl/private/nginx-selfsigned.key;

echo 'ssl certs created' >> $EXEC_LOG_FILE

cat <<EOT | sudo tee /etc/nginx/snippets/self-signed.conf
ssl_certificate /etc/ssl/certs/nginx-selfsigned.crt;
ssl_certificate_key /etc/ssl/private/nginx-selfsigned.key;
EOT

sudo openssl dhparam -out /etc/ssl/certs/dhparam.pem 2048

# NGINX SSL PARAMS
cat <<EOT | sudo tee /etc/nginx/snippets/ssl-params.conf

# NGINX SSL Config
# From https://cipherli.st/, https://raymii.org/s/tutorials/Strong_SSL_Security_On_nginx.html
# and https://www.digitalocean.com/community/tutorials/how-to-create-a-self-signed-ssl-certificate-for-nginx-in-ubuntu-16-04

ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
ssl_prefer_server_ciphers on;
ssl_ciphers "EECDH+AESGCM:EDH+AESGCM:AES256+EECDH:AES256+EDH";
ssl_ecdh_curve secp384r1;
ssl_session_cache shared:SSL:10m;
ssl_session_tickets off;
ssl_session_timeout  10m;
ssl_stapling on;
ssl_stapling_verify on;
add_header Strict-Transport-Security "max-age=63072000; includeSubdomains";
add_header X-Frame-Options DENY;
add_header X-Content-Type-Options nosniff;
ssl_dhparam /etc/ssl/certs/dhparam.pem;

EOT

echo 'ssl params configured' >> $EXEC_LOG_FILE

## NGINX Proxy Config

# Remove default
sudo rm /etc/nginx/nginx.conf
cat <<EOT | sudo tee /etc/nginx/nginx.conf

user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

# Load dynamic modules. See /usr/share/doc/nginx/README.dynamic.
include /usr/share/nginx/modules/*.conf;

events {
    worker_connections 1024;
}

http {

  sendfile            on;
  tcp_nopush          on;
  tcp_nodelay         on;
  keepalive_timeout   65;
  types_hash_max_size 2048;

  include             /etc/nginx/mime.types;
  default_type        application/octet-stream;

  gzip on;

  server {
        listen 80;
        listen [::]:80;
        listen 443 ssl http2;
        listen [::]:443 ssl http2;

        server_name server_domain_or_IP;
        include snippets/self-signed.conf;
        include snippets/ssl-params.conf;

        access_log /var/log/nginx/reverse-access.log;
        error_log /var/log/nginx/reverse-error.log;

        location / {
            proxy_set_header X-Real-IP \$remote_addr;
            proxy_set_header Host \$host;
            proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;

            proxy_pass "http://localhost:$tsp_mock_port";
		    }
  }
}
EOT

echo 'nginx configured' >> $EXEC_LOG_FILE

# Start by default
sudo systemctl enable nginx &&

echo 'nginx enabled' >> $EXEC_LOG_FILE &&

# ReStart nginx
sudo systemctl restart nginx &&
echo 'nginx re-started' >> $EXEC_LOG_FILE

echo 'Done' >> $EXEC_LOG_FILE &&
exit 0