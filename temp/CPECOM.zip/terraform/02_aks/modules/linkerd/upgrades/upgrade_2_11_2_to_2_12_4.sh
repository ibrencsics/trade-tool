#!/bin/bash

LINKERD_NS=linkerd
LINKERD_CONTROL_PLANE_RELEASE_NAME=linkerd-control-plane-release
LINKERD_CRD_RELEASE_NAME=linkerd-crds-release

migrate_linkerd_crd_resources() {
  crd_release_name=$1
  linkerd_ns=$2
  crd_name=$3

  kubectl annotate --overwrite "crd/$crd_name" \
    "meta.helm.sh/release-name=$crd_release_name" \
    "meta.helm.sh/release-namespace=$linkerd_ns"
}

migrate_name_spaced_linkerd_resources() {
  linkerd_control_plane_release_name=$1
  resource_ns=$2
  resource_type=$3
  resource_name=$4

  kubectl annotate --overwrite -n "$resource_ns" "$resource_type/$resource_name"  \
    "meta.helm.sh/release-name=$linkerd_control_plane_release_name" \
    "meta.helm.sh/release-namespace=$resource_ns"
}

migrate_global_linkerd_resources() {
  linkerd_control_plane_release_name=$1
  linkerd_ns=$2
  resource_type=$3
  resource_name=$4

  kubectl annotate --overwrite "$resource_type/$resource_name"  \
      "meta.helm.sh/release-name=$linkerd_control_plane_release_name" \
      "meta.helm.sh/release-namespace=$linkerd_ns"
}

# Migrate CRDs
migrate_linkerd_crd_resources "$LINKERD_CRD_RELEASE_NAME" "$LINKERD_NS" "servers.policy.linkerd.io" &&
migrate_linkerd_crd_resources "$LINKERD_CRD_RELEASE_NAME" "$LINKERD_NS" "serverauthorizations.policy.linkerd.io" &&
migrate_linkerd_crd_resources "$LINKERD_CRD_RELEASE_NAME" "$LINKERD_NS" "serviceprofiles.linkerd.io" &&
migrate_linkerd_crd_resources "$LINKERD_CRD_RELEASE_NAME" "$LINKERD_NS" "trafficsplits.split.smi-spec.io" &&

# Migrate name spaced resources
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ServiceAccount" "linkerd-destination" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ServiceAccount" "linkerd-heartbeat" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ServiceAccount" "linkerd-identity" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ServiceAccount" "linkerd-proxy-injector" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Secret" "linkerd-sp-validator-k8s-tls" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Secret" "linkerd-policy-validator-k8s-tls" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Secret" "linkerd-proxy-injector-k8s-tls" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ConfigMap" "linkerd-config" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ConfigMap" "linkerd-identity-trust-roots" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Role" "linkerd-heartbeat" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "RoleBinding" "linkerd-heartbeat" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Service" "linkerd-dst" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Service" "linkerd-dst-headless" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Service" "linkerd-sp-validator" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Service" "linkerd-policy" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Service" "linkerd-policy-validator" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Service" "linkerd-identity" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Service" "linkerd-identity-headless" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Service" "linkerd-proxy-injector" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Deployment" "linkerd-destination" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Deployment" "linkerd-identity" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "Deployment" "linkerd-proxy-injector" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "CronJob" "linkerd-heartbeat" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "PodDisruptionBudget" "linkerd-dst" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "PodDisruptionBudget" "linkerd-identity" &&
migrate_name_spaced_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "PodDisruptionBudget" "linkerd-proxy-injector" &&

# Migrate global resources
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRole" "linkerd-linkerd-destination" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRole" "linkerd-policy" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRole" "linkerd-heartbeat" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRole" "linkerd-linkerd-identity" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRole" "linkerd-linkerd-proxy-injector" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRoleBinding" "linkerd-linkerd-destination" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRoleBinding" "linkerd-destination-policy" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRoleBinding" "linkerd-heartbeat" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRoleBinding" "linkerd-linkerd-identity" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ClusterRoleBinding" "linkerd-linkerd-proxy-injector" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ValidatingWebhookConfiguration" "linkerd-sp-validator-webhook-config" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "ValidatingWebhookConfiguration" "linkerd-policy-validator-webhook-config" &&
migrate_global_linkerd_resources "$LINKERD_CONTROL_PLANE_RELEASE_NAME" "$LINKERD_NS" "MutatingWebhookConfiguration" "linkerd-proxy-injector-webhook-config" &&

echo "Migrate script completed !"