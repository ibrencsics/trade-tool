#!/bin/bash

LINKERD_NS=linkerd
OLD_LINKERD_RELEASE_NAME=linkerd-release

clean_linkerd_state() {
  linkerd_ns=$1
  release_name=$2
  kubectl delete secret -n "$linkerd_ns" -l "name=$release_name"
}

clean_linkerd_state "$LINKERD_NS" "$OLD_LINKERD_RELEASE_NAME"
