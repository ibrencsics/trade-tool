## Create Admin AD applications

---
NOTE:
* This step has to be executed once for each environment.
* Person who is executing the script will need Administrator privileges with
for the underlying Tenant.
---

* Verify that ``TENANT_ID`` and ``TF_ENV`` environment variables in ``create-ad-apps.sh`` are correct for 
the environment where AD apps should be created

* Run create-ad-apps script

```
cd ad-apps
./create-ad-apps.sh
```
