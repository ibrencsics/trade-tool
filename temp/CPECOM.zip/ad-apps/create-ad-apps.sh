#!/usr/bin/env bash

TENANT_ID="b3b09976-7567-445d-b27a-c164bb617670"
TF_SRC="tf"
TF_ENV="env/dev.tf"

az login --tenant $TENANT_ID &&
cd $TF_SRC &&
terraform init &&
terraform plan -var-file="$TF_ENV" -out="ad-apps.tfplan" &&
terraform apply "ad-apps.tfplan" &&
echo "Done"
