# Introduction 
Helm charts definition to be used for CPECOM deployments.

# Getting Started
Currently a single pipeline is defined to upload the current version of all helm chars to the ACR. 

# Build and Test
Run _cpecom-helm-charts_ in branch _application/CPECOM_.